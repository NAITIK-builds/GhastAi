# 👻 Ghost AI Copilot — Screen-Share Invisible AI Assistant for Windows

An AI assistant desktop application for Windows that solves questions, multiple-choice exams, coding challenges, and interview queries in real-time, while remaining **100% invisible to anyone watching your screen share** (Zoom, Discord, Google Meet, Microsoft Teams, OBS, Slack, Snipping Tool).

---

## 🛡️ How the Invisibility Feature Works

Ghost AI hooks directly into the Windows Desktop Window Manager (DWM) using the official Windows API:
```c
SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE); // 0x00000011
```
- **What this does**: Instructs the Windows operating system to render the assistant on your physical monitor, but **completely omit and exclude** the window from all capture sessions (`BitBlt`, DXGI Desktop Duplication, Windows Graphics Capture, Discord, Zoom, Teams, Google Meet, OBS).
- **Result**: You see Ghost AI floating cleanly on your desktop, but anyone watching your screen share only sees what is **behind** it!

---

## ⚡ Global Keyboard Shortcuts

These shortcuts work globally from anywhere in Windows (even while inside a browser, code editor, or full-screen app):

| Shortcut | Action | Description |
|---|---|---|
| **`Alt + Shift + C`**| ⚡ **Instant Quick Copy**| Copies clean code (or full answer) to clipboard from anywhere in Windows with visual toast notification. |
| **`Alt + L`** | 🎙️ **Live Listen** | Real-time speech-to-text question detection from system audio or microphone. |
| **`Alt + S`** | 📸 **Snip Question** | Spawns an invisible snipping crosshair to drag a box over any question on your screen. Solves with AI Vision instantly. |
| **`Alt + C`** | 📋 **Solve Clipboard** | Solves question or code currently copied to your clipboard. |
| **`Alt + A`** | 💬 **Ask Question** | Opens a stealth input bar to type or paste a question. |
| **`Alt + H`** | 🚨 **Panic Key / Hide-Show** | Instantly hides or shows the assistant window. |
| **`Alt + M`** | 👻 **Minimize to Bubble** | Collapses overlay into a compact floating ghost bubble. |
| **`Alt + X`** | 🧹 **Clear** | Clears current answer and output. |
| **`Alt + K`** | ⚙️ **Settings** | Opens Settings to configure API Key & response preferences. |

---

## 🚀 How to Run

### Desktop App
- **Method 1: One-Click Launcher**: Double-click [run_ghost_ai.bat](file:///c:/Users/naiti/Desktop/ghost-ai-assistant/run_ghost_ai.bat) or [run_stealth.vbs](file:///c:/Users/naiti/Desktop/ghost-ai-assistant/run_stealth.vbs).
- **Method 2: Command Line**:
  ```powershell
  python main.py
  ```

### Showcase Website
Open `website/index.html` in any web browser to explore the interactive Screen-Share Invisibility Simulator and Desktop Overlay playground:
- Double-click `website/index.html` or open `file:///.../website/index.html`.

---

## 📁 Project Structure

```
ghost-ai-assistant/
├── src/                             # Source code
│   ├── core/                        # Low-level stealth, Windows DWM hooks & audio
│   │   ├── stealth_core.py          # WDA_EXCLUDEFROMCAPTURE, WS_EX_NOACTIVATE, taskbar strip
│   │   ├── invisibility_verifier.py # Screenshot comparison verifier
│   │   └── audio_listener.py        # WASAPI loopback & microphone listener
│   ├── engine/                      # AI logic & code parsing
│   │   ├── ai_engine.py             # Gemini API worker & prompts
│   │   ├── code_formatter.py        # LeetCode syntax extraction & layout parser
│   │   └── cv_manager.py            # Resume parser & personalized session memory
│   └── ui/                          # PyQt6 user interface components
│       ├── overlay_ui.py            # Super header, response hub, draggable overlay
│       ├── floating_icon.py         # Collapsed floating bubble icon
│       ├── snipper.py               # Stealth snipping tool overlay
│       ├── cv_dialog.py             # Resume upload and manager dialog
│       └── settings_dialog.py       # API keys and audio configuration dialog
├── tests/                           # Automated test suites
│   ├── test_clean_output_layout_structure.py
│   ├── test_stealth_typing_logic.py
│   ├── test_stealth.py
│   ├── test_user_fixes.py
│   ├── test_leetcode_multilang.py
│   ├── test_stealth_context_menu.py
│   ├── test_stealth_focus_and_anti_proctor.py
│   ├── test_dynamic_refine_pills_and_mcq_note.py
│   ├── test_responsive_and_solution_extraction.py
│   └── verify_all.py
├── scripts/                         # Helper and launcher scripts
│   ├── run_ghost_ai.bat
│   ├── run_stealth.vbs
│   └── run_tests.py
├── website/                         # Modern product showcase website
│   ├── index.html                   # Semantic HTML layout
│   ├── styles.css                   # Glassmorphic dark cyber theme
│   ├── script.js                    # Invisibility simulator & interactive overlay
│   └── assets/                      # SVG icons and visual assets
├── main.py                          # Main entry point
├── main.pyw                         # Windowed entry point (zero console)
├── run_ghost_ai.bat                 # Root launcher
├── run_stealth.vbs                  # Stealth launcher
├── config.json                      # Local user configuration
├── requirements.txt                 # Dependencies
└── README.md                        # Project documentation
```

---

## 🔑 Getting a Free Gemini API Key
1. Go to [Google AI Studio](https://aistudio.google.com/) (free).
2. Click **Get API Key** and copy your key.
3. In Ghost AI, click **⚙️** (or press `Alt + K`), paste your key, and click **Save Settings**.
   *(Your API key is saved locally in `config.json` on your computer and never transmitted anywhere else).*

---

## 🎯 Response Modes & Multi-Language LeetCode Engine
- **⚡ Fast / MCQ**: Detects Multiple-Choice questions and outputs high-contrast **Option Verdict Cards** with 1-click **📋 Copy Option**.
- **💻 LeetCode & Coding Mode**: Generates 100% pre-made runnable code inside standard LeetCode class templates:
  - **C++**: `class Solution { public: ... }` with standard headers (`<vector>`, `<unordered_map>`, `using namespace std;`).
  - **Java**: `class Solution { public ... }` with `import java.util.*;`.
  - **Python**: `class Solution: def methodName(self, ...):` with typing support.
  - **JavaScript / TypeScript**: Standard function templates.
  - **⚡ LEETCODE READY Badge**: Direct 1-click **📋 Copy [LANG] Code** button without markdown backticks or commentary.
  - **⌨️ Human Typer Simulation**: Automatically types code character-by-character into LeetCode/CoderPad to bypass paste-detection.
- **🎙️ Interview Mode**: First-person articulate candidate delivery with talking points and trade-offs.
- **📖 Detailed**: Step-by-step reasoning and full theoretical explanation.

---

## 🎨 Modern Elite UI & Responsiveness (GirGit & Interview Coder Style)
- **Unified Super Header (44px)**: Single streamlined row containing Brand pulse, Stealth radar, Mode pills, Language switcher (`Python`, `C++`, `Java`, `JS`, `TS`), Capture tools, and Window controls.
- **Collapsible History Drawer**: Hidden by default via `[ 🕒 History ]`, unlocking 100% of the horizontal window width for expansive code reading without horizontal scrolling.
- **Segmented Solution Hub**: Switch views instantly between `All`, `Code Only`, `Approach`, and `Complexity`.
- **Animated Toast Notifications**: Instant, non-intrusive feedback when copying solutions or switching settings.

---

## 🧪 Built-in Verification Tool
Click the **🧪 Test Invisibility** button on the UI:
- It takes a live capture of your screen using Windows screen capture.
- It displays the captured image side-by-side with an indicator showing where Ghost AI is on your screen.
- You will see that the Ghost AI window is completely missing from the capture!
