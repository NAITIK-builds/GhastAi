"""
wallet_manager.py - Ghost AI Assistant Server-Side Authentication & Licensing Engine
Communicates with backend licensing server (http://127.0.0.1:5173/api/software/...).
Enforces server-side time validation, anti-multi-session licensing, and real-time synchronization.
"""

import os
import json
import logging
import uuid
import socket
import hashlib
import urllib.request
import urllib.error
from datetime import datetime

logger = logging.getLogger(__name__)

API_BASE_URL = "http://127.0.0.1:5173/api"
DB_FILE = os.path.join(os.path.dirname(__file__), "users_db.json")
SESSION_FILE = os.path.join(os.path.dirname(__file__), "user_session.json")
INSTANCE_FILE = os.path.join(os.path.dirname(__file__), "software_instance.json")
RATE_PER_MINUTE = 2.5


def get_software_instance_id():
    """Generates or loads a persistent hardware/machine instance identifier."""
    if os.path.exists(INSTANCE_FILE):
        try:
            with open(INSTANCE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("instance_id"):
                    return data["instance_id"]
        except Exception:
            pass

    hostname = socket.gethostname()
    instance_id = f"inst_{hostname}_{uuid.uuid4().hex[:8]}"
    try:
        with open(INSTANCE_FILE, "w", encoding="utf-8") as f:
            json.dump({"instance_id": instance_id, "created_at": datetime.now().isoformat()}, f, indent=2)
    except Exception:
        pass
    return instance_id


def format_seconds_hms(total_seconds):
    """Formats seconds into standard HH:MM:SS format (e.g., 02:45:30)."""
    secs = max(0, int(total_seconds or 0))
    hrs = secs // 3600
    mins = (secs % 3600) // 60
    rem_secs = secs % 60
    return f"{hrs:02d}:{mins:02d}:{rem_secs:02d}"


def hash_password(password):
    """SHA-256 password hasher matching the server standard."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


# ──────────────────────────────────────────────────────────
# Database Fallback Operations (if API offline)
# ──────────────────────────────────────────────────────────
def load_users_db():
    if not os.path.exists(DB_FILE):
        return []
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception as exc:
        logger.error(f"Failed to load users DB file: {exc}")
        return []


def save_users_db(users):
    try:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(users, f, indent=2)
        return True
    except Exception as exc:
        logger.error(f"Failed to save users DB file: {exc}")
        return False


def get_user_by_id(user_id):
    users = load_users_db()
    for u in users:
        if u.get("id") == user_id:
            return u
    return None


def get_user_by_email(email):
    if not email:
        return None
    users = load_users_db()
    norm = email.strip().lower()
    for u in users:
        if u.get("email", "").strip().lower() == norm:
            return u
    return None


def update_user(user):
    """Updates a user record in users_db.json and active session if matched."""
    if not user or not user.get("id"):
        return False
    users = load_users_db()
    for i, u in enumerate(users):
        if u.get("id") == user["id"]:
            users[i] = {**u, **user}
            save_users_db(users)
            session = get_active_session()
            if session and session.get("id") == user["id"]:
                session.update(users[i])
                save_active_session(session)
            return True
    return False


# ──────────────────────────────────────────────────────────
# Server-Side Authentication & Multi-Session Protection
# ──────────────────────────────────────────────────────────
def authenticate_user(email, password):
    """
    Authenticates candidate credentials against backend server.
    Enforces server-side license verification and anti-multi-session rules.
    Returns (success: bool, user_dict: dict | None, message: str)
    """
    if not email or not password:
        return False, None, "Email and password are required."

    instance_id = get_software_instance_id()
    payload = json.dumps({
        "email": email.strip(),
        "password": password,
        "software_instance_id": instance_id
    }).encode("utf-8")

    # Attempt Server-Side Authentication
    try:
        req = urllib.request.Request(
            f"{API_BASE_URL}/software/login",
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=5) as res:
            data = json.loads(res.read().decode("utf-8"))
            if data.get("authenticated"):
                user_info = data.get("user", {})
                rem_seconds = data.get("remaining_seconds", 0)
                user_info["remaining_seconds"] = rem_seconds
                user_info["minutesRemaining"] = rem_seconds // 60
                user_info["balanceRupees"] = round((rem_seconds / 60) * RATE_PER_MINUTE, 2)
                user_info["allowedByAdmin"] = True
                user_info["status"] = data.get("status", "active")
                user_info["software_instance_id"] = instance_id

                save_active_session(user_info)
                return True, user_info, f"Welcome, {user_info.get('name', 'Candidate')}!"
    except urllib.error.HTTPError as http_err:
        try:
            err_body = json.loads(http_err.read().decode("utf-8"))
            err_msg = err_body.get("error", "Authentication error")
            if http_err.code == 409:
                return False, None, f"⚠️ Session Conflict: {err_msg}"
            return False, None, err_msg
        except Exception:
            return False, None, f"Server error ({http_err.code})"
    except Exception as exc:
        logger.warning(f"Backend API offline ({exc}), falling back to local database...")

    # Fallback to local users_db.json
    local_user = get_user_by_email(email)
    if not local_user:
        return False, None, f"Account '{email}' not found. Please register on the website."

    hashed = hash_password(password)
    if local_user.get("password_hash") != hashed and local_user.get("password") != password:
        return False, None, "Incorrect password. Please verify your credentials."

    rem_seconds = local_user.get("remaining_seconds", 0)
    local_user["minutesRemaining"] = rem_seconds // 60
    local_user["balanceRupees"] = round((rem_seconds / 60) * RATE_PER_MINUTE, 2)
    local_user["allowedByAdmin"] = True
    local_user["software_instance_id"] = instance_id
    save_active_session(local_user)
    return True, local_user, f"Welcome back, {local_user.get('name')} (Local Offline Mode)!"


# ──────────────────────────────────────────────────────────
# Server-Side Time Synchronization Heartbeat
# ──────────────────────────────────────────────────────────
def sync_with_server(user_id=None, elapsed_seconds=0):
    """
    Periodic heartbeat sent to the server.
    Deducts active elapsed seconds on server and synchronizes remaining balance.
    If Admin added minutes on the website, balance updates immediately.
    Returns (success: bool, remaining_seconds: int, status: str)
    """
    session = get_active_session()
    uid = user_id or (session.get("id") if session else None)
    if not uid:
        return False, 0, "no_session"

    instance_id = session.get("software_instance_id") or get_software_instance_id()
    payload = json.dumps({
        "userId": uid,
        "software_instance_id": instance_id,
        "elapsed_seconds": int(elapsed_seconds)
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            f"{API_BASE_URL}/software/sync",
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=4) as res:
            data = json.loads(res.read().decode("utf-8"))
            new_seconds = data.get("remaining_seconds", 0)
            status = data.get("status", "active")

            if session:
                session["remaining_seconds"] = new_seconds
                session["minutesRemaining"] = new_seconds // 60
                session["balanceRupees"] = round((new_seconds / 60) * RATE_PER_MINUTE, 2)
                session["status"] = status
                save_active_session(session)

            return True, new_seconds, status
    except Exception as exc:
        # If server offline, sync locally from DB
        db_user = get_user_by_id(uid)
        if db_user:
            cur_sec = db_user.get("remaining_seconds", 0)
            if elapsed_seconds > 0:
                cur_sec = max(0, cur_sec - elapsed_seconds)
                db_user["remaining_seconds"] = cur_sec
                save_users_db(load_users_db())
            if session:
                session["remaining_seconds"] = cur_sec
                session["minutesRemaining"] = cur_sec // 60
                session["balanceRupees"] = round((cur_sec / 60) * RATE_PER_MINUTE, 2)
                save_active_session(session)
            return True, cur_sec, ("active" if cur_sec > 0 else "expired")

    return False, 0, "error"


def logout_software_session():
    """Notifies server on software exit to terminate active session immediately."""
    session = get_active_session()
    if not session:
        return
    try:
        payload = json.dumps({
            "userId": session.get("id"),
            "software_instance_id": session.get("software_instance_id")
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{API_BASE_URL}/software/logout",
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass
    clear_active_session()


# ──────────────────────────────────────────────────────────
# Session State Helpers
# ──────────────────────────────────────────────────────────
def save_active_session(user):
    try:
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            json.dump(user, f, indent=2)
    except Exception as exc:
        logger.error(f"Failed to save session: {exc}")


def get_active_session():
    if not os.path.exists(SESSION_FILE):
        return None
    try:
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def clear_active_session():
    if os.path.exists(SESSION_FILE):
        try:
            os.remove(SESSION_FILE)
        except Exception:
            pass


def admin_add_balance(user_id, amount_rupees):
    """
    Admin credits rupees/minutes to user. Updates remaining_seconds.
    """
    added_mins = int(amount_rupees / RATE_PER_MINUTE)
    users = load_users_db()
    for u in users:
        if u.get("id") == user_id:
            added_secs = added_mins * 60
            u["remaining_seconds"] = (u.get("remaining_seconds", 0) or 0) + added_secs
            u["minutesRemaining"] = u["remaining_seconds"] // 60
            u["balanceRupees"] = round(amount_rupees, 2)
            u["allowedByAdmin"] = True
            u["status"] = "Active"
            save_users_db(users)
            session = get_active_session()
            if session and session.get("id") == user_id:
                session.update(u)
                save_active_session(session)
            return u
    return None


def can_user_run(user_id=None):
    """
    Validates if user is authorized and has remaining runtime seconds > 0.
    Returns (can_run: bool, reason: str, minutes_remaining: int, balance: float)
    """
    user = get_active_session()
    if user_id and (not user or user.get("id") != user_id):
        user = get_user_by_id(user_id) or user

    if not user:
        return False, "No active user session found. Please login.", 0, 0.0

    rem_seconds = user.get("remaining_seconds", 0)
    mins = rem_seconds // 60
    bal = user.get("balanceRupees", 0.0)

    if rem_seconds <= 0:
        return False, "Your available time has ended. Please contact the administrator to extend your access.", 0, 0.0

    return True, "Session Active", mins, bal


def can_run_app():
    """Alias used across overlay UI to gate AI requests."""
    return can_user_run()


def deduct_user_minute(user_id=None):
    """
    Deducts 60 seconds from active session and synchronizes with server.
    Returns (success: bool, minutes_remaining: int, balance_rupees: float)
    """
    ok, new_seconds, status = sync_with_server(user_id=user_id, elapsed_seconds=60)
    mins = new_seconds // 60
    bal = round((new_seconds / 60) * RATE_PER_MINUTE, 2)
    return (new_seconds > 0), mins, bal


def load_wallet():
    """Provides compatibility wallet dict for UI pills."""
    session = get_active_session()
    if not session:
        return {"minutes_remaining": 0, "balance_rupees": 0.0, "allowed_by_admin": False}
    rem_sec = session.get("remaining_seconds", 0)
    return {
        "minutes_remaining": rem_sec // 60,
        "remaining_seconds": rem_sec,
        "formatted_time": format_seconds_hms(rem_sec),
        "balance_rupees": round((rem_sec / 60) * RATE_PER_MINUTE, 2),
        "allowed_by_admin": rem_sec > 0
    }
