"""
cv_dialog.py - Candidate CV / Resume Upload & Session Profile Dialog
Provides a glassmorphic interface for uploading, previewing, and managing
candidate resumes (PDF, DOCX, TXT) with WDA screen-share exclusion.
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth
from cv_manager import cv_session, extract_text_from_file


class CVDialog(QtWidgets.QDialog):
    cv_updated = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ghost AI - Candidate Resume & Profile")
        self.setFixedSize(540, 560)
        self.setWindowFlags(QtCore.Qt.WindowType.Dialog | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        enable_stealth(int(self.winId()))

    def init_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f172a;
                color: #e2e8f0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 13px;
            }
            QPlainTextEdit {
                background-color: #1e293b;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 10px;
                color: #f8fafc;
                font-size: 12px;
                line-height: 1.5;
            }
            QPlainTextEdit:focus {
                border: 1px solid #6366f1;
            }
            QPushButton {
                background-color: #4f46e5;
                color: white;
                border: none;
                border-radius: 7px;
                padding: 8px 16px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4338ca;
            }
            QPushButton#secondaryBtn {
                background-color: #1e293b;
                color: #cbd5e1;
                border: 1px solid #334155;
            }
            QPushButton#secondaryBtn:hover {
                background-color: #334155;
                color: white;
            }
            QPushButton#dangerBtn {
                background-color: rgba(239, 68, 68, 0.15);
                color: #fca5a5;
                border: 1px solid rgba(239, 68, 68, 0.35);
            }
            QPushButton#dangerBtn:hover {
                background-color: #ef4444;
                color: white;
            }
            QCheckBox {
                color: #cbd5e1;
                font-size: 12px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 1px solid #475569;
                background-color: #1e293b;
            }
            QCheckBox::indicator:checked {
                background-color: #6366f1;
                border-color: #6366f1;
            }
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(22, 20, 22, 20)

        # Title & Subtitle
        title = QtWidgets.QLabel("📄 Candidate Profile & CV Memory")
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #f8fafc;")
        layout.addWidget(title)

        subtitle = QtWidgets.QLabel(
            "Upload your resume so Ghost AI remembers your projects, experience, and skills "
            "to personalize interview answers in the first person (\"I\")."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color: #94a3b8; font-size: 11px; line-height: 1.4;")
        layout.addWidget(subtitle)

        # Status Card (Displays active resume info)
        self.status_card = QtWidgets.QFrame()
        self.status_card.setStyleSheet("""
            QFrame {
                background-color: #1e1b4b;
                border: 1px solid #6366f1;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        status_layout = QtWidgets.QHBoxLayout(self.status_card)
        status_layout.setContentsMargins(10, 8, 10, 8)

        self.status_icon = QtWidgets.QLabel("📄")
        self.status_icon.setStyleSheet("font-size: 20px;")
        status_layout.addWidget(self.status_icon)

        status_text_layout = QtWidgets.QVBoxLayout()
        self.status_title = QtWidgets.QLabel("No CV Loaded")
        self.status_title.setStyleSheet("font-weight: 700; font-size: 13px; color: #a5b4fc;")
        self.status_sub = QtWidgets.QLabel("Upload a PDF/DOCX or paste your resume below.")
        self.status_sub.setStyleSheet("font-size: 11px; color: #94a3b8;")
        status_text_layout.addWidget(self.status_title)
        status_text_layout.addWidget(self.status_sub)
        status_layout.addLayout(status_text_layout)

        status_layout.addStretch()

        self.clear_btn = QtWidgets.QPushButton("Clear")
        self.clear_btn.setObjectName("dangerBtn")
        self.clear_btn.setToolTip("Remove CV context from this session")
        self.clear_btn.clicked.connect(self.clear_cv)
        status_layout.addWidget(self.clear_btn)

        layout.addWidget(self.status_card)

        # Upload Button Row
        upload_row = QtWidgets.QHBoxLayout()
        self.browse_btn = QtWidgets.QPushButton("📁 Browse File (PDF, DOCX, TXT)")
        self.browse_btn.setObjectName("secondaryBtn")
        self.browse_btn.clicked.connect(self.browse_file)
        upload_row.addWidget(self.browse_btn)

        self.file_label = QtWidgets.QLabel("")
        self.file_label.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: 600;")
        upload_row.addWidget(self.file_label)
        upload_row.addStretch()
        layout.addLayout(upload_row)

        # Resume Text Preview / Editor
        paste_label = QtWidgets.QLabel("Resume / Profile Content (Editable):")
        paste_label.setStyleSheet("font-size: 12px; font-weight: 600; color: #e2e8f0;")
        layout.addWidget(paste_label)

        self.text_editor = QtWidgets.QPlainTextEdit()
        self.text_editor.setPlaceholderText(
            "Paste your resume text here (experience, projects, skills, education) or browse a PDF/DOCX file above..."
        )
        layout.addWidget(self.text_editor)

        # Word count & Enable checkbox
        bottom_row = QtWidgets.QHBoxLayout()
        self.enable_check = QtWidgets.QCheckBox("Include my resume context in AI responses")
        self.enable_check.setChecked(cv_session.is_enabled)
        bottom_row.addWidget(self.enable_check)

        bottom_row.addStretch()
        self.word_count_label = QtWidgets.QLabel("0 words")
        self.word_count_label.setStyleSheet("color: #64748b; font-size: 11px;")
        bottom_row.addWidget(self.word_count_label)
        layout.addLayout(bottom_row)

        # Footer Actions
        btn_row = QtWidgets.QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QtWidgets.QPushButton("Close")
        cancel_btn.setObjectName("secondaryBtn")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        save_btn = QtWidgets.QPushButton("✓ Save to Session")
        save_btn.clicked.connect(self.save_and_close)
        btn_row.addWidget(save_btn)

        layout.addLayout(btn_row)

        self.text_editor.textChanged.connect(self._on_text_changed)
        self.refresh_ui()

    def refresh_ui(self):
        """Refreshes the dialog with current session memory."""
        if cv_session.has_cv():
            self.status_title.setText(f"Active: {cv_session.filename or 'Pasted Resume'}")
            self.status_sub.setText(f"{cv_session.word_count} words loaded in session memory")
            self.status_card.setStyleSheet("""
                QFrame {
                    background-color: rgba(99, 102, 241, 0.15);
                    border: 1px solid #6366f1;
                    border-radius: 8px;
                    padding: 10px;
                }
            """)
            self.text_editor.setPlainText(cv_session.raw_text)
            self.clear_btn.setVisible(True)
        else:
            self.status_title.setText("No Resume Loaded")
            self.status_sub.setText("Upload a PDF/DOCX or paste text below.")
            self.status_card.setStyleSheet("""
                QFrame {
                    background-color: #1e293b;
                    border: 1px solid #334155;
                    border-radius: 8px;
                    padding: 10px;
                }
            """)
            self.clear_btn.setVisible(False)

        self._update_word_count()

    def _on_text_changed(self):
        self._update_word_count()

    def _update_word_count(self):
        txt = self.text_editor.toPlainText().strip()
        words = len(txt.split()) if txt else 0
        self.word_count_label.setText(f"{words} words")

    def browse_file(self):
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select Resume Document",
            "",
            "Documents (*.pdf *.docx *.txt *.md);;PDF Files (*.pdf);;Word Documents (*.docx);;Text Files (*.txt *.md)"
        )
        if not file_path:
            return

        text, err = extract_text_from_file(file_path)
        if err:
            QtWidgets.QMessageBox.warning(self, "Document Parsing", f"Could not extract resume text:\n{err}")
            return

        filename = QtCore.QFileInfo(file_path).fileName()
        self.file_label.setText(f"✓ Loaded: {filename}")
        self.text_editor.setPlainText(text)
        self.status_title.setText(f"Loaded: {filename}")
        self.status_sub.setText(f"{len(text.split())} words ready to save to session")

    def clear_cv(self):
        cv_session.clear_cv()
        self.text_editor.clear()
        self.file_label.setText("")
        self.refresh_ui()
        self.cv_updated.emit()

    def save_and_close(self):
        txt = self.text_editor.toPlainText().strip()
        if txt:
            filename = self.file_label.text().replace("✓ Loaded: ", "").strip() or cv_session.filename or "My_Resume.txt"
            cv_session.set_cv(filename, txt)
            cv_session.is_enabled = self.enable_check.isChecked()
        else:
            cv_session.clear_cv()

        self.cv_updated.emit()
        self.accept()
