"""
main.pyw - Pure Windowed Entry Point for Ghost AI Assistant (Zero Console Window)
Double-clicking this file on Windows launches Ghost AI directly with pythonw.
"""
from main import main

if __name__ == "__main__":
    main()
