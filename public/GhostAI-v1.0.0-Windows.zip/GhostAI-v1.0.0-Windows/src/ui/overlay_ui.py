"""
overlay_ui.py - Ghost AI Assistant — Elite Stealth Copilot UI
Stolen from the best designs (GirGit AI, Interview Coder, Raycast, Cursor).
Unified single-row super header, multi-language selector (C++, Java, Python, JS) for
direct runnable LeetCode class Solution generation, collapsible history drawer,
high-contrast MCQ verdict cards, LeetCode 1-click copy & human auto-typer simulation,
floating toast notifications, and WDA_EXCLUDEFROMCAPTURE screen-share invisibility.
"""

import sys
import os
import json
import datetime
import threading
import time
import random
from PyQt6 import QtCore, QtGui, QtWidgets
from pynput import keyboard
from pynput.keyboard import Controller as PynputController, Key as PynputKey

import stealth_core
from stealth_core import enable_stealth, get_stealth_status, install_global_stealth_filter
from snipper import ScreenSnipper
from ai_engine import AISolveWorker, load_config, save_config
from settings_dialog import SettingsDialog
from invisibility_verifier import InvisibilityVerifierDialog
from code_formatter import format_full_response, ResponseResult
from floating_icon import FloatingGhostIcon
from audio_listener import AudioListener
from cv_dialog import CVDialog
from cv_manager import cv_session
import wallet_manager
from recharge_dialog import RechargeDialog
from access_expired_dialog import AccessExpiredDialog


# ─────────────────────────────────────────────
#  Elite Modern Color Palette (Obsidian Glass)
# ─────────────────────────────────────────────
C = {
    "bg":        "#090b10",   # Pure deep space obsidian
    "surface":   "#0e1422",   # Card surface
    "surface2":  "#151c2e",   # Secondary card surface
    "surface3":  "#1c263c",   # Interactive hover surface
    "border":    "#1e293d",   # Clean slate border
    "border2":   "#2d3c58",   # Highlight border
    "muted":     "#64748b",   # Slate-500
    "text":      "#cbd5e1",   # Slate-300 readable text
    "bright":    "#f8fafc",   # Pure high-contrast white
    "accent":    "#38bdf8",   # Radiant electric cyan
    "accent2":   "#2563eb",   # Primary royal blue
    "accent_bg": "#0c1a30",
    "success":   "#10b981",   # Emerald-500 LeetCode green
    "success_bg":"#064e3b",
    "danger":    "#f43f5e",   # Rose-500
    "danger_bg": "#4c0519",
    "warn":      "#f59e0b",   # Amber-500
    "purple":    "#a855f7",   # Vibrant AI Purple
}

# ─────────────────────────────────────────────
#  Inline SVG strings
# ─────────────────────────────────────────────
SVG = {
    "ghost": (
        '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M12 2C7.03 2 3 6.03 3 11v9l3-3 3 3 3-3 3 3 3-3v-9c0-4.97-4.03-9-9-9z" '
        'fill="#38bdf8" fill-opacity="0.95"/>'
        '<circle cx="9" cy="11" r="1.5" fill="#090b10"/>'
        '<circle cx="15" cy="11" r="1.5" fill="#090b10"/>'
        '</svg>'
    ),
    "camera": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M5.5 2L4 4H2a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-2l-1.5-2h-5z" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<circle cx="8" cy="8" r="2.5" stroke="#cbd5e1" stroke-width="1.2"/>'
        '</svg>'
    ),
    "clipboard": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="4" y="2" width="8" height="12" rx="1" stroke="#cbd5e1" stroke-width="1.2"/>'
        '<path d="M6 2v0a2 2 0 0 1 4 0" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<path d="M6 7h4M6 10h3" stroke="#cbd5e1" stroke-width="1" stroke-linecap="round"/>'
        '</svg>'
    ),
    "mic": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="5.5" y="1" width="5" height="8" rx="2.5" stroke="#cbd5e1" stroke-width="1.2"/>'
        '<path d="M3 8a5 5 0 0 0 10 0" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '<line x1="8" y1="13" x2="8" y2="15" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '<line x1="6" y1="15" x2="10" y2="15" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '</svg>'
    ),
    "mic_active": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="5.5" y="1" width="5" height="8" rx="2.5" fill="#f43f5e" fill-opacity="0.3" stroke="#f43f5e" stroke-width="1.2"/>'
        '<path d="M3 8a5 5 0 0 0 10 0" stroke="#f43f5e" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '<line x1="8" y1="13" x2="8" y2="15" stroke="#f43f5e" stroke-width="1.2" stroke-linecap="round"/>'
        '<circle cx="13" cy="3" r="2.5" fill="#f43f5e"/>'
        '</svg>'
    ),
    "chat": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M2 3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H5l-3 3V3z" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '</svg>'
    ),
    "file": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M3 2h7l3 3v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<path d="M10 2v4h4" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<line x1="5" y1="9" x2="11" y2="9" stroke="#cbd5e1" stroke-width="1" stroke-linecap="round"/>'
        '</svg>'
    ),
    "shield": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M8 1L2 4v4c0 3.3 2.5 6.4 6 7 3.5-.6 6-3.7 6-7V4L8 1z" stroke="#10b981" stroke-width="1.2" fill="none"/>'
        '<path d="M5.5 8l2 2 3-3" stroke="#10b981" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'
        '</svg>'
    ),
    "settings": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<circle cx="8" cy="8" r="2.5" stroke="#cbd5e1" stroke-width="1.2"/>'
        '<path d="M8 1v2M8 13v2M1 8h2M13 8h2M2.9 2.9l1.4 1.4M11.7 11.7l1.4 1.4M2.9 13.1l1.4-1.4M11.7 4.3l1.4-1.4" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '</svg>'
    ),
    "flask": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M6 1h4M7 1v5l-4 8a1 1 0 0 0 .9 1.5h8.2A1 1 0 0 0 13 14L9 6V1" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '<circle cx="7" cy="11" r="1" fill="#cbd5e1"/>'
        '</svg>'
    ),
    "pin": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M9 1l6 6-1.5 1.5-2-2-3 3 1 3-1.5 1.5L5 11l-4 4-1.5-1.5 4-4-3-3 1.5-1.5 3 1 3-3-2-2L9 1z" stroke="#cbd5e1" stroke-width="1.1" fill="none"/>'
        '</svg>'
    ),
    "pin_active": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M9 1l6 6-1.5 1.5-2-2-3 3 1 3-1.5 1.5L5 11l-4 4-1.5-1.5 4-4-3-3 1.5-1.5 3 1 3-3-2-2L9 1z" stroke="#38bdf8" stroke-width="1.1" fill="#38bdf8" fill-opacity="0.25"/>'
        '</svg>'
    ),
    "minimize": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<line x1="3" y1="8" x2="13" y2="8" stroke="#cbd5e1" stroke-width="1.4" stroke-linecap="round"/>'
        '</svg>'
    ),
    "maximize": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="3" y="3" width="10" height="10" rx="1" stroke="#cbd5e1" stroke-width="1.3" fill="none"/>'
        '</svg>'
    ),
    "restore": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="5" y="1" width="9" height="9" rx="1" stroke="#cbd5e1" stroke-width="1.3" fill="none"/>'
        '<path d="M2 6v7a1 1 0 0 0 1 1h7" stroke="#cbd5e1" stroke-width="1.3" fill="none"/>'
        '</svg>'
    ),
    "close": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<line x1="3" y1="3" x2="13" y2="13" stroke="#f43f5e" stroke-width="1.5" stroke-linecap="round"/>'
        '<line x1="13" y1="3" x2="3" y2="13" stroke="#f43f5e" stroke-width="1.5" stroke-linecap="round"/>'
        '</svg>'
    ),
    "copy": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="5" y="5" width="9" height="9" rx="1" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<path d="M3 11V3a1 1 0 0 1 1-1h8" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '</svg>'
    ),
    "code": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M5 4L1 8l4 4M11 4l4 4-4 4" stroke="#cbd5e1" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
        '<line x1="9.5" y1="3" x2="6.5" y2="13" stroke="#cbd5e1" stroke-width="1.3" stroke-linecap="round"/>'
        '</svg>'
    ),
    "keyboard": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="2" y="3" width="12" height="10" rx="1.5" stroke="#cbd5e1" stroke-width="1.2" fill="none"/>'
        '<line x1="4.5" y1="6" x2="5.5" y2="6" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '<line x1="7.5" y1="6" x2="8.5" y2="6" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '<line x1="10.5" y1="6" x2="11.5" y2="6" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '<line x1="5" y1="10" x2="11" y2="10" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '</svg>'
    ),
    "history": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M2 8a6 6 0 1 1 1.5 4" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '<path d="M2 4v4h4" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
        '<path d="M8 5.5V8l2 1.5" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '</svg>'
    ),
    "check": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M2.5 8.5l4 4 7-7" stroke="#10b981" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'
        '</svg>'
    ),
    "lightning": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M10 1L4 9h5l-3 6 8-8H9l1-6z" fill="#38bdf8" fill-opacity="0.9" stroke="#38bdf8" stroke-width="0.5"/>'
        '</svg>'
    ),
    "send": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M14 2L2 7l5 2 2 5 5-12z" fill="#38bdf8" fill-opacity="0.9"/>'
        '<line x1="7" y1="9" x2="14" y2="2" stroke="#38bdf8" stroke-width="1.1"/>'
        '</svg>'
    ),
    "trash": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<line x1="2" y1="4" x2="14" y2="4" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round"/>'
        '<path d="M5 4V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1M6 7v5M10 7v5M4 4l1 10h6l1-10" stroke="#cbd5e1" stroke-width="1.2" stroke-linecap="round" fill="none"/>'
        '</svg>'
    ),
    "refresh": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M13.5 6A6 6 0 1 0 12 11.5" stroke="#cbd5e1" stroke-width="1.3" stroke-linecap="round" fill="none"/>'
        '<path d="M13.5 2v4h-4" stroke="#cbd5e1" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
        '</svg>'
    ),
    "discard": (
        '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        '<line x1="3" y1="3" x2="13" y2="13" stroke="#cbd5e1" stroke-width="1.5" stroke-linecap="round"/>'
        '<line x1="13" y1="3" x2="3" y2="13" stroke="#cbd5e1" stroke-width="1.5" stroke-linecap="round"/>'
        '</svg>'
    ),
}

try:
    from PyQt6.QtSvg import QSvgRenderer
    _HAS_SVG = True
except ImportError:
    _HAS_SVG = False


def svg_to_pixmap(svg_str: str, size: int = 16, color_override: str = None) -> QtGui.QPixmap:
    if color_override:
        svg_str = svg_str.replace("#cbd5e1", color_override).replace("#c9d1d9", color_override)
    if _HAS_SVG:
        renderer = QSvgRenderer(svg_str.encode("utf-8"))
        pixmap = QtGui.QPixmap(size, size)
        pixmap.fill(QtCore.Qt.GlobalColor.transparent)
        painter = QtGui.QPainter(pixmap)
        renderer.render(painter)
        painter.end()
        return pixmap
    px = QtGui.QPixmap(size, size)
    px.fill(QtCore.Qt.GlobalColor.transparent)
    return px


def svg_icon(key: str, size: int = 16, color: str = None) -> QtGui.QIcon:
    return QtGui.QIcon(svg_to_pixmap(SVG.get(key, SVG["ghost"]), size, color))


# ─────────────────────────────────────────────
#  Edge enum
# ─────────────────────────────────────────────
class Edge:
    NONE = 0; LEFT = 1; RIGHT = 2; TOP = 4; BOTTOM = 8
    TOP_LEFT = 5; TOP_RIGHT = 6; BOTTOM_LEFT = 9; BOTTOM_RIGHT = 10


# ─────────────────────────────────────────────
#  Snip Guard — blocks Win+Shift+S at kernel level
# ─────────────────────────────────────────────
class SnipGuardThread(QtCore.QThread):
    """
    Permanent low-level Win32 keyboard hook that intercepts Win+Shift+S
    BEFORE it reaches Windows Snipping Tool.

    When Win+Shift+S is pressed:
    - The keystrokes are SUPPRESSED at kernel level (return False) so
      Windows Snipping Tool never receives them and never launches.
    - snip_intercepted signal is emitted so Ghost's own built-in snip
      tool (which never steals focus) launches instead.
    """
    snip_intercepted = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._listener = None
        self._running = False

    def stop(self):
        self._running = False
        if self._listener:
            try:
                self._listener.stop()
            except Exception:
                pass

    def run(self):
        self._running = True
        # Track modifier state (Win key VK=0x5B/0x5C, Shift VK=0x10/0xA0/0xA1)
        win_down = False
        shift_down = False

        WIN_VKS = {0x5B, 0x5C}  # VK_LWIN, VK_RWIN
        SHIFT_VKS = {0x10, 0xA0, 0xA1}  # VK_SHIFT, VK_LSHIFT, VK_RSHIFT
        S_VK = 0x53  # VK_S

        def _filter(msg, data):
            nonlocal win_down, shift_down
            if not self._running:
                return True
            vk = data.vkCode
            # WM_KEYDOWN / WM_SYSKEYDOWN
            if msg in (0x0100, 0x0104):
                if vk in WIN_VKS:
                    win_down = True
                elif vk in SHIFT_VKS:
                    shift_down = True
                elif vk == S_VK and win_down and shift_down:
                    # Win+Shift+S detected! Block it and redirect to our snip.
                    self.snip_intercepted.emit()
                    return False  # Suppress: Windows Snipping Tool never launches
            # WM_KEYUP / WM_SYSKEYUP
            elif msg in (0x0101, 0x0105):
                if vk in WIN_VKS:
                    win_down = False
                elif vk in SHIFT_VKS:
                    shift_down = False
            return True

        try:
            self._listener = keyboard.Listener(win32_event_filter=_filter)
            self._listener.daemon = True
            self._listener.start()
            self._listener.join()  # Block thread until stopped
        except Exception as e:
            print(f"[SnipGuardThread] {e}")


# ─────────────────────────────────────────────
#  Global hotkey thread
# ─────────────────────────────────────────────
class GlobalHotkeyThread(QtCore.QThread):
    snip_triggered = QtCore.pyqtSignal()
    clipboard_triggered = QtCore.pyqtSignal()
    toggle_visible_triggered = QtCore.pyqtSignal()
    minimize_triggered = QtCore.pyqtSignal()
    clear_triggered = QtCore.pyqtSignal()
    settings_triggered = QtCore.pyqtSignal()
    ask_triggered = QtCore.pyqtSignal()
    listen_triggered = QtCore.pyqtSignal()
    quick_copy_triggered = QtCore.pyqtSignal()
    note_triggered = QtCore.pyqtSignal()
    quit_triggered = QtCore.pyqtSignal()
    # Emitted when Win+Shift+S (Windows Snipping Tool) is detected — hide overlay briefly
    snip_screen_triggered = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._listener = None

    def stop(self):
        if self._listener:
            try:
                self._listener.stop()
            except Exception:
                pass
        self.quit()

    def run(self):
        hotkeys = {
            '<alt>+s': lambda: self.snip_triggered.emit(),
            '<alt>+c': lambda: self.clipboard_triggered.emit(),
            '<alt>+h': lambda: self.toggle_visible_triggered.emit(),
            '<alt>+m': lambda: self.minimize_triggered.emit(),
            '<alt>+x': lambda: self.clear_triggered.emit(),
            '<alt>+k': lambda: self.settings_triggered.emit(),
            '<alt>+a': lambda: self.ask_triggered.emit(),
            '<alt>+l': lambda: self.listen_triggered.emit(),
            '<alt>+<shift>+c': lambda: self.quick_copy_triggered.emit(),
            '<alt>+e': lambda: self.note_triggered.emit(),
            '<alt>+q': lambda: self.quit_triggered.emit(),
            # Detect Windows Snipping Tool (Win+Shift+S) to auto-hide overlay
            '<cmd>+<shift>+s': lambda: self.snip_screen_triggered.emit(),
        }
        try:
            with keyboard.GlobalHotKeys(hotkeys) as h:
                self._listener = h
                h.join()
        except Exception as e:
            print(f"[GlobalHotkeyThread] {e}")


# ─────────────────────────────────────────────
#  Stealth Typing Manager (Zero-Blur Keyboard Interceptor)
# ─────────────────────────────────────────────
class StealthTypingManager(QtCore.QObject):
    """
    Stealth Typing Manager:
    When typing notes or prompts, intercepts physical keystrokes and injects
    them directly into the assistant's input field while keeping the proctored
    browser 100% active in Windows. Suppresses keys from reaching the browser
    so zero blur events or leaked keystrokes occur.

    KEY FIX: Characters are emitted from INSIDE the win32_event_filter BEFORE
    returning False (suppression). This is critical because pynput's on_press
    does NOT fire for suppressed events, so we must emit key_typed ourselves
    using ctypes MapVirtualKeyW + ToUnicode to resolve VK codes to characters.
    """
    key_typed = QtCore.pyqtSignal(str)
    backspace_pressed = QtCore.pyqtSignal()
    submit_pressed = QtCore.pyqtSignal()
    cancel_pressed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._listener = None
        self.is_active = False
        self.active_line_edit = None
        self.target_browser_hwnd = 0
        # Pre-load ctypes for VK->char translation
        try:
            import ctypes
            self._user32 = ctypes.windll.user32
            self._kernel32 = ctypes.windll.kernel32
        except Exception:
            self._user32 = None
            self._kernel32 = None

    def _vk_to_char(self, vk_code: int, scan_code: int) -> str:
        """
        Translates a Win32 virtual key code to its actual typed character,
        respecting shift/caps lock state. Returns empty string if not printable.
        """
        if not self._user32:
            return ""
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(8)
            # Get current keyboard state (256 bytes)
            key_state = (ctypes.c_ubyte * 256)()
            self._user32.GetKeyboardState(key_state)
            # ToUnicode: translates VK + scan + key state to unicode char
            result = self._user32.ToUnicode(vk_code, scan_code, key_state, buf, 8, 0)
            if result > 0:
                ch = buf.value
                # Only emit printable characters
                if ch and ch.isprintable() and ch not in ('\x00', '\r', '\n', '\x1b', '\t'):
                    return ch
        except Exception:
            pass
        return ""

    def start_typing(self, line_edit: QtWidgets.QLineEdit, browser_hwnd: int = 0):
        self.stop_typing()
        self.active_line_edit = line_edit
        self.target_browser_hwnd = browser_hwnd or stealth_core.get_foreground_window()
        self.is_active = True

        if self.target_browser_hwnd:
            stealth_core.restore_foreground_window(self.target_browser_hwnd)

        def _win32_filter(msg, data):
            if not self.is_active:
                return True
            # WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104
            if msg in (0x0100, 0x0104):
                vk = data.vkCode
                scan = data.scanCode

                if vk == 0x0D:  # Enter — submit
                    self.submit_pressed.emit()
                    return False
                if vk == 0x1B:  # Escape — cancel
                    self.cancel_pressed.emit()
                    return False
                if vk == 0x08:  # Backspace
                    self.backspace_pressed.emit()
                    return False
                if vk == 0x20:  # Space
                    self.key_typed.emit(" ")
                    return False
                if vk == 0x09:  # Tab
                    self.key_typed.emit("    ")
                    return False

                # Alphanumeric, numpad, and punctuation: translate VK -> char THEN suppress
                if (0x30 <= vk <= 0x5A) or (0xBA <= vk <= 0xE2) or (0x60 <= vk <= 0x6F):
                    ch = self._vk_to_char(vk, scan)
                    if ch:
                        self.key_typed.emit(ch)
                    return False

            # Suppress WM_KEYUP too for all intercepted keys (prevent browser receiving them)
            if msg in (0x0101, 0x0105):  # WM_KEYUP / WM_SYSKEYUP
                vk = data.vkCode
                if vk in (0x0D, 0x1B, 0x08, 0x20, 0x09) or (0x30 <= vk <= 0x5A) or (0xBA <= vk <= 0xE2) or (0x60 <= vk <= 0x6F):
                    return False

            return True

        try:
            self._listener = keyboard.Listener(
                win32_event_filter=_win32_filter
            )
            self._listener.daemon = True
            self._listener.start()
        except Exception as e:
            print(f"[StealthTypingManager] error: {e}")

    def stop_typing(self):
        self.is_active = False
        if self._listener:
            try:
                self._listener.stop()
            except Exception:
                pass
            self._listener = None
        if self.target_browser_hwnd:
            stealth_core.restore_foreground_window(self.target_browser_hwnd)
        self.active_line_edit = None


# ─────────────────────────────────────────────
#  Auto-Typer Thread (Human Typing Simulator)
# ─────────────────────────────────────────────
class AutoTyperThread(QtCore.QThread):
    countdown_tick = QtCore.pyqtSignal(int)
    typing_started = QtCore.pyqtSignal()
    typing_progress = QtCore.pyqtSignal(int, int)
    typing_finished = QtCore.pyqtSignal()
    typing_cancelled = QtCore.pyqtSignal()

    def __init__(self, text_to_type: str, countdown_secs: int = 3, clean_replace: bool = True, parent=None):
        super().__init__(parent)
        self.text_to_type = text_to_type
        self.countdown_secs = countdown_secs
        self.clean_replace = clean_replace
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def run(self):
        for s in range(self.countdown_secs, 0, -1):
            if self._is_cancelled:
                self.typing_cancelled.emit()
                return
            self.countdown_tick.emit(s)
            time.sleep(1.0)

        if self._is_cancelled:
            self.typing_cancelled.emit()
            return

        self.typing_started.emit()
        kb = PynputController()

        if self.clean_replace:
            # Clear pre-existing code in the text box (Ctrl+A -> Backspace) to prevent leftover braces or duplicated code
            try:
                with kb.pressed(PynputKey.ctrl):
                    kb.tap('a')
                time.sleep(0.06)
                kb.tap(PynputKey.backspace)
                time.sleep(0.08)
            except Exception:
                pass

        # Clean and normalize text
        raw_text = self.text_to_type.replace('\r\n', '\n').replace('\r', '\n')
        raw_text = raw_text.replace('\t', '    ')
        lines = raw_text.split('\n')

        # Sanitize Brackets: If close braces exceed open braces (dangling }), trim trailing closing braces
        open_count = raw_text.count('{')
        close_count = raw_text.count('}')
        while close_count > open_count and lines:
            last = lines[-1].strip()
            if last in ('}', '};', '})', '},'):
                lines.pop()
                close_count -= 1
            elif not last:
                lines.pop()
            else:
                break

        total_chars = max(1, sum(len(l) + 1 for l in lines))
        chars_typed = 0

        for line_idx, line in enumerate(lines):
            if self._is_cancelled:
                self.typing_cancelled.emit()
                return

            stripped = line.strip()

            if line_idx > 0:
                # Move to next line
                kb.tap(PynputKey.enter)
                time.sleep(random.uniform(0.035, 0.055))
                chars_typed += 1

                # Reset editor auto-indentation: Shift+Home selects back to column 0, Backspace clears it
                try:
                    with kb.pressed(PynputKey.shift):
                        kb.tap(PynputKey.home)
                    time.sleep(0.015)
                    kb.tap(PynputKey.backspace)
                    time.sleep(0.015)
                except Exception:
                    pass

            # If empty line, already reset to column 0, continue
            if not stripped:
                continue

            # Type the exact line content (with exact source indentation)
            for ch in line:
                if self._is_cancelled:
                    self.typing_cancelled.emit()
                    return

                try:
                    kb.type(ch)
                    delay = random.uniform(0.010, 0.024)
                    if ch in ('.', ',', ';', '(', ')', '{', '}', ':', '='):
                        delay += random.uniform(0.015, 0.035)
                    time.sleep(delay)
                except Exception:
                    try:
                        kb.type(ch)
                    except Exception:
                        pass
                chars_typed += 1
                if chars_typed % 15 == 0:
                    self.typing_progress.emit(chars_typed, total_chars)

        self.typing_finished.emit()


# ─────────────────────────────────────────────
#  Floating Toast Notification Pill
# ─────────────────────────────────────────────
class ToastOverlay(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("toastOverlay")
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.hide()

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(14, 7, 16, 7)
        layout.setSpacing(8)

        self.icon_lbl = QtWidgets.QLabel()
        self.icon_lbl.setFixedSize(16, 16)
        layout.addWidget(self.icon_lbl)

        self.msg_lbl = QtWidgets.QLabel()
        self.msg_lbl.setStyleSheet("color: #f8fafc; font-size: 11px; font-weight: 700; background: transparent; border: none;")
        layout.addWidget(self.msg_lbl)

        self.setStyleSheet(f"""
            QFrame#toastOverlay {{
                background-color: rgba(14, 20, 34, 0.96);
                border: 1px solid {C['accent']};
                border-radius: 17px;
            }}
        """)

        self._timer = QtCore.QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)

    def show_toast(self, message: str, icon_key: str = "check", duration_ms: int = 1800, icon_color: str = None):
        self.msg_lbl.setText(message)
        self.icon_lbl.setPixmap(svg_to_pixmap(SVG.get(icon_key, SVG["check"]), 14, icon_color or C["success"]))
        self.adjustSize()
        self.reposition()
        self.show()
        self.raise_()
        self._timer.stop()
        self._timer.start(duration_ms)

    def reposition(self):
        if self.parentWidget():
            pw = self.parentWidget().width()
            ph = self.parentWidget().height()
            w = self.width()
            x = (pw - w) // 2
            y = ph - self.height() - 44
            self.move(max(10, x), max(10, y))


# ─────────────────────────────────────────────
#  Size Grip
# ─────────────────────────────────────────────
class ModernSizeGrip(QtWidgets.QSizeGrip):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(14, 14)
        # Always use standard ArrowCursor so resizing cannot be detected
        self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
        self.setStyleSheet("background: transparent;")

    def enterEvent(self, event):
        super().enterEvent(event)
        self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        painter.setBrush(QtGui.QColor(C["border2"]))
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        w, h = self.width(), self.height()
        positions = [(w-3, h-3), (w-7, h-3), (w-11, h-3),
                     (w-3, h-7), (w-7, h-7), (w-3, h-11)]
        for x, y in positions:
            painter.drawEllipse(x, y, 2, 2)


# ─────────────────────────────────────────────
#  Draggable Header Frame
# ─────────────────────────────────────────────
class DraggableFrame(QtWidgets.QFrame):
    def __init__(self, overlay_window, parent=None):
        super().__init__(parent)
        self.overlay_window = overlay_window
        self.drag_position = None

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.overlay_window.pos()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if event.buttons() & QtCore.Qt.MouseButton.LeftButton and self.drag_position is not None:
            if self.overlay_window.is_maximized_custom:
                self.overlay_window.toggle_maximize()
                self.drag_position = QtCore.QPoint(self.overlay_window.width() // 2, 20)
            self.overlay_window.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self.drag_position = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.overlay_window.toggle_maximize()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)


# ─────────────────────────────────────────────
#  Custom Question Editor
# ─────────────────────────────────────────────
class QuestionInputEdit(QtWidgets.QPlainTextEdit):
    submit_requested = QtCore.pyqtSignal()
    cancel_requested = QtCore.pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key.Key_Return, QtCore.Qt.Key.Key_Enter):
            if event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
            else:
                self.submit_requested.emit()
                event.accept()
        elif event.key() == QtCore.Qt.Key.Key_Escape:
            self.cancel_requested.emit()
            event.accept()
        else:
            super().keyPressEvent(event)


# ─────────────────────────────────────────────
#  Response history item
# ─────────────────────────────────────────────
class HistoryItem:
    def __init__(self, question: str, answer: str, source: str, mode: str, result_obj=None):
        self.question = question
        self.answer = answer
        self.source = source
        self.mode = mode
        self.result_obj = result_obj
        self.timestamp = datetime.datetime.now().strftime("%H:%M")


SOURCE_ICONS = {"audio": "mic", "snip": "camera", "clipboard": "clipboard", "ask": "chat"}
MODE_LABELS = {"mcq": "MCQ", "code": "Code", "interview": "Interview", "detailed": "Detail"}


class HistoryEntryWidget(QtWidgets.QFrame):
    clicked = QtCore.pyqtSignal(object)

    def __init__(self, item: HistoryItem, parent=None):
        super().__init__(parent)
        self.item = item
        self.setFixedHeight(54)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self._selected = False
        self._build_ui()
        self._apply_style()

    def _build_ui(self):
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(8, 5, 8, 5)
        layout.setSpacing(7)
        ico = QtWidgets.QLabel()
        key = SOURCE_ICONS.get(self.item.source, "chat")
        ico.setPixmap(svg_to_pixmap(SVG[key], 12, C["muted"]))
        ico.setFixedSize(13, 13)
        layout.addWidget(ico)
        text_col = QtWidgets.QVBoxLayout()
        text_col.setSpacing(1)
        q = self.item.question
        q_short = (q[:35] + "…") if len(q) > 35 else q
        q_lbl = QtWidgets.QLabel(q_short or "(image / audio)")
        q_lbl.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-weight: 600;")
        text_col.addWidget(q_lbl)
        meta_lbl = QtWidgets.QLabel(f"{self.item.timestamp}  ·  {MODE_LABELS.get(self.item.mode,'')}")
        meta_lbl.setStyleSheet(f"color: {C['muted']}; font-size: 10px;")
        text_col.addWidget(meta_lbl)
        layout.addLayout(text_col, stretch=1)

    def set_selected(self, val: bool):
        self._selected = val
        self._apply_style()

    def _apply_style(self):
        if self._selected:
            self.setStyleSheet(f"""
                HistoryEntryWidget {{
                    background: {C['surface2']};
                    border-left: 2px solid {C['accent']};
                    border-radius: 5px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                HistoryEntryWidget {{
                    background: transparent;
                    border-left: 2px solid transparent;
                    border-radius: 5px;
                }}
                HistoryEntryWidget:hover {{ background: {C['surface2']}; }}
            """)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.clicked.emit(self.item)
        super().mousePressEvent(event)


# ─────────────────────────────────────────────
#  Minimal Audio Level Indicator
# ─────────────────────────────────────────────
class AudioLevelWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.level = 0.0
        self.setFixedSize(60, 16)
        self.setToolTip("Audio signal level")

    def set_level(self, lvl: float):
        new_lvl = max(0.0, min(1.0, lvl))
        if abs(new_lvl - self.level) > 0.02:
            self.level = new_lvl
            self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        segments = 6
        gap = 3
        seg_w = (w - (segments - 1) * gap) // segments
        seg_h = 7
        y = (h - seg_h) // 2
        active_count = int(self.level * segments * 2.2)
        active_count = max(0, min(segments, active_count))
        for i in range(segments):
            x = i * (seg_w + gap)
            color = QtGui.QColor(C["accent"]) if i < active_count else QtGui.QColor(C["border2"])
            painter.setBrush(color)
            painter.setPen(QtCore.Qt.PenStyle.NoPen)
            painter.drawRoundedRect(x, y, seg_w, seg_h, 2, 2)


# ─────────────────────────────────────────────
#  GhostOverlay - Main Assistant Window
# ─────────────────────────────────────────────
class GhostOverlay(QtWidgets.QWidget):
    RESIZE_MARGIN = 8

    def __init__(self, active_user=None):
        super().__init__()
        self.active_user = active_user or wallet_manager.get_active_session()
        self.config = load_config()
        self.worker = None
        self.pending_wav_bytes = None
        self.pending_question_text = ""
        self.is_pinned = self.config.get("always_on_top", True)
        self.current_mode = self.config.get("default_mode", "mcq")
        self.current_language = self.config.get("code_language", "python")
        self.current_font_size = 13
        self.is_maximized_custom = False
        self.normal_geom = None
        self.extracted_codes = []
        self.current_response_result = None
        self.active_tab = "all"
        self.auto_typer_thread = None

        # Dynamic Thinking Animation Engine
        self._thinking_timer = QtCore.QTimer(self)
        self._thinking_timer.setInterval(320)
        self._thinking_timer.timeout.connect(self._on_thinking_tick)
        self._thinking_step = 0
        self._thinking_detail = ""

        self.floating_icon = None
        self._hidden_from_floating = False
        self._floating_icon_pos = None
        self.last_normal_pos = None
        self.last_normal_size = None
        self.audio_listener = None
        self.current_stream_text = ""
        self._history = []
        self._current_question_source = "ask"
        self._current_question_text = ""
        self._active_history_widget = None
        self.resizing_edge = Edge.NONE
        self.resize_start_pos = None
        self.resize_start_geom = None

        # Zero-Blur Stealth Typing Manager
        self.stealth_typer = StealthTypingManager(self)
        self.stealth_typer.key_typed.connect(self._on_stealth_key_typed)
        self.stealth_typer.backspace_pressed.connect(self._on_stealth_backspace)
        self.stealth_typer.submit_pressed.connect(self._on_stealth_submit)
        self.stealth_typer.cancel_pressed.connect(self._on_stealth_cancel)

        self.init_window_flags()
        self.init_floating_icon()
        self.init_ui()
        self.init_snipper()
        self.init_audio_listener()
        self.init_hotkeys()
        install_global_stealth_filter()
        self.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)

        # Real-time UI Clock Countdown & Server Sync Engine
        self._unsynced_elapsed_seconds = 0
        self._access_expired_dlg = None

        # 1-second smooth local countdown
        self.ui_clock_timer = QtCore.QTimer(self)
        self.ui_clock_timer.setInterval(1000)
        self.ui_clock_timer.timeout.connect(self._on_ui_clock_tick)
        self.ui_clock_timer.start()

        # 5-second Server Reconciliation & Heartbeat Timer
        self.db_sync_timer = QtCore.QTimer(self)
        self.db_sync_timer.setInterval(5000)
        self.db_sync_timer.timeout.connect(self._on_db_sync_tick)
        self.db_sync_timer.start()

        # Check initial runtime balance on startup
        can_run, reason, mins, bal = wallet_manager.can_user_run(self.active_user.get("id") if self.active_user else None)
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            QtCore.QTimer.singleShot(600, lambda: self.open_recharge_dialog(reason))

    def init_window_flags(self):
        flags = (
            QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.Tool
            | QtCore.Qt.WindowType.WindowDoesNotAcceptFocus
        )
        if self.is_pinned:
            flags |= QtCore.Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setMouseTracking(True)
        w = self.config.get("window_width", 820)
        h = self.config.get("window_height", 560)
        self.setMinimumSize(480, 320)
        self.resize(w, h)

    def _update_copy_code_btn_text(self):
        """Sets copy_code_btn text responsively according to current language and window width."""
        if not hasattr(self, 'copy_code_btn'):
            return
        if not self.copy_code_btn.isEnabled():
            self.copy_code_btn.setText("Copy Code")
            return
        lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()
        if self.width() >= 560:
            self.copy_code_btn.setText(f"Copy {lang_disp} Code")
        else:
            self.copy_code_btn.setText("Copy Code")

    def _update_responsive_layout(self, width: int = None):
        """Intelligently adapts the header and action bars to prevent squishing or text truncation."""
        if width is None:
            width = self.width()

        self._update_copy_code_btn_text()

        # ── Level 1: Full Desktop (width >= 860) ──
        if width >= 860:
            if hasattr(self, 'brand_title'):
                self.brand_title.setVisible(True)
            if hasattr(self, 'lang_label'):
                self.lang_label.setVisible(True)
            if hasattr(self, 'opacity_slider'):
                self.opacity_slider.setVisible(True)
                self.opacity_slider.setFixedWidth(54)
            if hasattr(self, '_tool_btns') and hasattr(self, '_tool_labels'):
                for btn in self._tool_btns:
                    btn.setText(self._tool_labels.get(btn, ""))
                    btn.setMinimumWidth(0)
                    btn.setMaximumWidth(16777215)
                    btn.setFixedSize(QtCore.QSize(QtWidgets.QWIDGETSIZE_MAX, QtWidgets.QWIDGETSIZE_MAX))
            if hasattr(self, 'mode_buttons'):
                mode_labels = {"mcq": "MCQ", "code": "Code", "interview": "Interview"}
                for mid, btn in self.mode_buttons.items():
                    btn.setText(mode_labels.get(mid, mid))
            if hasattr(self, 'auto_type_btn'):
                self.auto_type_btn.setText("Auto-Type")
            if hasattr(self, 'copy_btn'):
                self.copy_btn.setText("Copy All")
            if hasattr(self, 'edit_note_btn'):
                self.edit_note_btn.setText("Edit Note")
                self.edit_note_btn.setMinimumWidth(0)
                self.edit_note_btn.setMaximumWidth(16777215)
                self.edit_note_btn.setFixedSize(QtCore.QSize(QtWidgets.QWIDGETSIZE_MAX, QtWidgets.QWIDGETSIZE_MAX))

        # ── Level 2: Compact Tools (700 <= width < 860) ──
        elif width >= 700:
            if hasattr(self, 'brand_title'):
                self.brand_title.setVisible(True)
            if hasattr(self, 'lang_label'):
                self.lang_label.setVisible(False)  # Save space; combo already shows language
            if hasattr(self, 'opacity_slider'):
                self.opacity_slider.setVisible(True)
                self.opacity_slider.setFixedWidth(44)
            if hasattr(self, '_tool_btns'):
                for btn in self._tool_btns:
                    btn.setText("")  # Icon only mode
                    btn.setFixedSize(26, 26)
            if hasattr(self, 'mode_buttons'):
                mode_labels = {"mcq": "MCQ", "code": "Code", "interview": "Int"}
                for mid, btn in self.mode_buttons.items():
                    btn.setText(mode_labels.get(mid, mid))
            if hasattr(self, 'auto_type_btn'):
                self.auto_type_btn.setText("Auto-Type")
            if hasattr(self, 'copy_btn'):
                self.copy_btn.setText("Copy All")
            if hasattr(self, 'edit_note_btn'):
                self.edit_note_btn.setText("Note")
                self.edit_note_btn.setMinimumWidth(0)
                self.edit_note_btn.setMaximumWidth(16777215)
                self.edit_note_btn.setFixedSize(QtCore.QSize(QtWidgets.QWIDGETSIZE_MAX, QtWidgets.QWIDGETSIZE_MAX))

        # ── Level 3: Super-Compact (560 <= width < 700) ──
        elif width >= 560:
            if hasattr(self, 'brand_title'):
                self.brand_title.setVisible(False)  # Ghost icon only
            if hasattr(self, 'lang_label'):
                self.lang_label.setVisible(False)
            if hasattr(self, 'opacity_slider'):
                self.opacity_slider.setVisible(True)
                self.opacity_slider.setFixedWidth(36)
            if hasattr(self, '_tool_btns'):
                for btn in self._tool_btns:
                    btn.setText("")  # Icon only
                    btn.setFixedSize(24, 24)
            if hasattr(self, 'mode_buttons'):
                mode_labels = {"mcq": "MCQ", "code": "Code", "interview": "Int"}
                for mid, btn in self.mode_buttons.items():
                    btn.setText(mode_labels.get(mid, mid))
            if hasattr(self, 'auto_type_btn'):
                self.auto_type_btn.setText("Type")
            if hasattr(self, 'copy_btn'):
                self.copy_btn.setText("Copy")
            if hasattr(self, 'edit_note_btn'):
                self.edit_note_btn.setText("Note")
                self.edit_note_btn.setMinimumWidth(0)
                self.edit_note_btn.setMaximumWidth(16777215)
                self.edit_note_btn.setFixedSize(QtCore.QSize(QtWidgets.QWIDGETSIZE_MAX, QtWidgets.QWIDGETSIZE_MAX))

        # ── Level 4: Ultra-Compact Minimal (width < 560) ──
        else:
            if hasattr(self, 'brand_title'):
                self.brand_title.setVisible(False)
            if hasattr(self, 'lang_label'):
                self.lang_label.setVisible(False)
            if hasattr(self, 'opacity_slider'):
                self.opacity_slider.setVisible(False)
            if hasattr(self, '_tool_btns'):
                for btn in self._tool_btns:
                    btn.setText("")
                    btn.setFixedSize(22, 22)
            if hasattr(self, 'mode_buttons'):
                mode_labels = {"mcq": "M", "code": "C", "interview": "I"}
                for mid, btn in self.mode_buttons.items():
                    btn.setText(mode_labels.get(mid, mid))
            if hasattr(self, 'auto_type_btn'):
                self.auto_type_btn.setText("Type")
            if hasattr(self, 'copy_btn'):
                self.copy_btn.setText("All")
            if hasattr(self, 'edit_note_btn'):
                self.edit_note_btn.setText("")
                self.edit_note_btn.setFixedSize(22, 22)

        if hasattr(self, '_update_wallet_pill'):
            self._update_wallet_pill()

    def moveEvent(self, event):
        super().moveEvent(event)
        p = self.pos()
        if p.x() > -10000 and not self.isMinimized():
            self.last_normal_pos = p

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.isMinimized() and self.pos().x() > -10000:
            self.last_normal_size = self.size()
        if hasattr(self, 'toast') and self.toast:
            self.toast.reposition()
        self._update_responsive_layout(event.size().width())
        self.save_window_size()

    def showEvent(self, event):
        super().showEvent(event)
        # Enable DWM screen capture exclusion invisibly without any frontend badge
        enable_stealth(int(self.winId()))
        self._update_responsive_layout(self.width())

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QtCore.QEvent.Type.WindowStateChange:
            enable_stealth(int(self.winId()))
            if self.isMinimized():
                self.setWindowState(self.windowState() & ~QtCore.Qt.WindowState.WindowMinimized)
                QtCore.QTimer.singleShot(0, self.minimize_to_floating_icon)
                event.accept()
                return

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        if event.key() == QtCore.Qt.Key.Key_Escape:
            if hasattr(self, 'edit_note_frame') and self.edit_note_frame.isVisible():
                self.edit_note_frame.setVisible(False)
                event.accept()
                return
            if self.auto_typer_thread and self.auto_typer_thread.isRunning():
                self.auto_typer_thread.cancel()
                self.show_toast("Auto-typing cancelled.", icon_key="discard")
                event.accept()
                return
        elif event.modifiers() == QtCore.Qt.KeyboardModifier.AltModifier and event.key() == QtCore.Qt.Key.Key_E:
            self.toggle_edit_note_bar()
            event.accept()
            return
        super().keyPressEvent(event)

    def contextMenuEvent(self, event):
        # Suppress context menu so right-clicking never spawns popups visible on screen share
        event.accept()

    def _on_stealth_key_typed(self, text: str):
        if hasattr(self, 'stealth_typer') and self.stealth_typer.active_line_edit:
            self.stealth_typer.active_line_edit.insert(text)

    def _on_stealth_backspace(self):
        if hasattr(self, 'stealth_typer') and self.stealth_typer.active_line_edit:
            self.stealth_typer.active_line_edit.backspace()

    def _on_stealth_submit(self):
        if not hasattr(self, 'stealth_typer'):
            return
        active = self.stealth_typer.active_line_edit
        self.stealth_typer.stop_typing()
        if active == getattr(self, 'ask_input', None):
            self.solve_custom_text()
        elif active == getattr(self, 'note_input', None):
            self.submit_custom_refine_note()

    def _on_stealth_cancel(self):
        if not hasattr(self, 'stealth_typer'):
            return
        active = self.stealth_typer.active_line_edit
        self.stealth_typer.stop_typing()
        if active == getattr(self, 'ask_input', None):
            self.ask_container.setVisible(False)
        elif active == getattr(self, 'note_input', None):
            self.edit_note_frame.setVisible(False)

    def get_edge(self, global_pt):
        pt = self.mapFromGlobal(global_pt)
        w, h = self.width(), self.height()
        edge = Edge.NONE
        m = self.RESIZE_MARGIN
        if pt.x() <= m: edge |= Edge.LEFT
        elif pt.x() >= w - m: edge |= Edge.RIGHT
        if pt.y() <= m: edge |= Edge.TOP
        elif pt.y() >= h - m: edge |= Edge.BOTTOM
        return edge

    def get_cursor_for_edge(self, edge):
        # Always return normal arrow cursor so border hovering and resizing is undetectable
        return QtGui.QCursor(QtCore.Qt.CursorShape.ArrowCursor)

    def eventFilter(self, watched, event):
        if event.type() == QtCore.QEvent.Type.ContextMenu:
            return True  # Consume context menu event
        if watched == self.card:
            if event.type() == QtCore.QEvent.Type.MouseMove:
                gp = event.globalPosition().toPoint()
                if self.resizing_edge != Edge.NONE and (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
                    self.perform_resize(gp); return True
                elif not (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
                    self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
            elif event.type() == QtCore.QEvent.Type.MouseButtonPress:
                if event.button() == QtCore.Qt.MouseButton.LeftButton:
                    gp = event.globalPosition().toPoint()
                    edge = self.get_edge(gp)
                    if edge != Edge.NONE:
                        self.resizing_edge = edge
                        self.resize_start_pos = gp
                        self.resize_start_geom = QtCore.QRect(self.geometry())
                        return True
            elif event.type() == QtCore.QEvent.Type.MouseButtonRelease:
                if self.resizing_edge != Edge.NONE:
                    self.resizing_edge = Edge.NONE
                    self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
                    self.save_window_size(); return True
            elif event.type() == QtCore.QEvent.Type.Leave:
                self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
        return super().eventFilter(watched, event)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            edge = self.get_edge(event.globalPosition().toPoint())
            if edge != Edge.NONE:
                self.resizing_edge = edge
                self.resize_start_pos = event.globalPosition().toPoint()
                self.resize_start_geom = QtCore.QRect(self.geometry())
                event.accept(); return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        gp = event.globalPosition().toPoint()
        if self.resizing_edge != Edge.NONE and (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            self.perform_resize(gp); event.accept(); return
        elif not (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self.resizing_edge != Edge.NONE:
            self.resizing_edge = Edge.NONE
            self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
            self.save_window_size(); event.accept(); return
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event):
        self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
        super().leaveEvent(event)

    def perform_resize(self, global_pos):
        delta = global_pos - self.resize_start_pos
        x, y = self.resize_start_geom.x(), self.resize_start_geom.y()
        w, h = self.resize_start_geom.width(), self.resize_start_geom.height()
        min_w, min_h = self.minimumWidth(), self.minimumHeight()
        if self.resizing_edge & Edge.RIGHT:  w = max(min_w, w + delta.x())
        if self.resizing_edge & Edge.BOTTOM: h = max(min_h, h + delta.y())
        if self.resizing_edge & Edge.LEFT:
            rw = max(min_w, w - delta.x()); x += w - rw; w = rw
        if self.resizing_edge & Edge.TOP:
            rh = max(min_h, h - delta.y()); y += h - rh; h = rh
        self.setGeometry(x, y, w, h)

    def save_window_size(self):
        if not self.is_maximized_custom and self.width() >= 600 and self.height() >= 380:
            cfg = load_config()
            cfg["window_width"] = self.width()
            cfg["window_height"] = self.height()
            self.config = cfg
            save_config(cfg)

    def toggle_maximize(self):
        if self.is_maximized_custom:
            self.is_maximized_custom = False
            self.max_btn.setIcon(svg_icon("maximize", 12))
            if self.normal_geom:
                self.setGeometry(self.normal_geom)
            else:
                self.resize(self.config.get("window_width", 820), self.config.get("window_height", 560))
        else:
            self.normal_geom = QtCore.QRect(self.geometry())
            self.is_maximized_custom = True
            self.max_btn.setIcon(svg_icon("restore", 12))
            screen = QtGui.QGuiApplication.screenAt(self.geometry().center()) or QtWidgets.QApplication.primaryScreen()
            self.setGeometry(screen.availableGeometry())
        enable_stealth(int(self.winId()))

    # ── UI Construction ───────────────────────
    def init_ui(self):
        opacity_val = self.config.get("opacity", 95) / 100.0
        self.setWindowOpacity(opacity_val)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        self.card = QtWidgets.QFrame()
        self.card.setObjectName("card")
        self.card.setMouseTracking(True)
        self.card.installEventFilter(self)
        self.card.setStyleSheet(f"""
            QFrame#card {{
                background: {C['surface']};
                border: 1px solid {C['border']};
                border-radius: 12px;
            }}
        """)

        card_vbox = QtWidgets.QVBoxLayout(self.card)
        card_vbox.setContentsMargins(0, 0, 0, 0)
        card_vbox.setSpacing(0)

        # Unified single-row Super Header (Height 44px)
        self._build_unified_super_header(card_vbox)

        content_area = QtWidgets.QWidget()
        content_area.setStyleSheet("background: transparent;")
        content_h = QtWidgets.QHBoxLayout(content_area)
        content_h.setContentsMargins(0, 0, 0, 0)
        content_h.setSpacing(0)

        # Collapsible history drawer (hidden by default to maximize code space!)
        self._build_collapsible_history_drawer(content_h)

        right_panel = QtWidgets.QWidget()
        right_panel.setStyleSheet("background: transparent;")
        right_vbox = QtWidgets.QVBoxLayout(right_panel)
        right_vbox.setContentsMargins(0, 0, 0, 0)
        right_vbox.setSpacing(0)

        self._build_contextual_cards(right_vbox)
        self._build_active_question_bar(right_vbox)
        self._build_solution_hub(right_vbox)
        self._build_answer_area(right_vbox)
        self._build_footer(right_vbox)

        content_h.addWidget(right_panel, stretch=1)
        card_vbox.addWidget(content_area, stretch=1)
        root.addWidget(self.card)

        # Floating toast notification overlay
        self.toast = ToastOverlay(self.card)

        self.show_welcome_message()

    def show_toast(self, message: str, icon_key: str = "check", duration_ms: int = 1800, icon_color: str = None):
        if hasattr(self, 'toast') and self.toast:
            self.toast.show_toast(message, icon_key=icon_key, duration_ms=duration_ms, icon_color=icon_color)

    # ── Unified Single-Row Super Header ────────
    def _build_unified_super_header(self, parent_layout):
        """Single sleek 44px header combining Brand, Mode, Language, Capture Tools, and Window Controls."""
        self.header_frame = DraggableFrame(self)
        self.header_frame.setFixedHeight(38)
        self.header_frame.setStyleSheet(f"""
            DraggableFrame {{
                background: {C['bg']};
                border-bottom: 1px solid {C['border']};
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
            }}
        """)
        hbox = QtWidgets.QHBoxLayout(self.header_frame)
        hbox.setContentsMargins(8, 0, 8, 0)
        hbox.setSpacing(5)

        # Brand icon & Title
        ghost_lbl = QtWidgets.QLabel()
        ghost_lbl.setPixmap(svg_to_pixmap(SVG["ghost"], 18))
        ghost_lbl.setFixedSize(20, 20)
        hbox.addWidget(ghost_lbl)

        # Title
        self.brand_title = QtWidgets.QLabel("Ghost AI")
        self.brand_title.setStyleSheet(f"color: {C['bright']}; font-size: 13px; font-weight: 800; letter-spacing: 0.2px;")
        hbox.addWidget(self.brand_title)

        # Divider
        def _sep():
            s = QtWidgets.QFrame()
            s.setFrameShape(QtWidgets.QFrame.Shape.VLine)
            s.setFixedHeight(18)
            s.setStyleSheet(f"color: {C['border']}; border: none; border-left: 1px solid {C['border']}; margin: 0 2px;")
            return s

        hbox.addWidget(_sep())

        # Mode Switcher (MCQ, Code/LeetCode, Interview)
        self.mode_group = QtWidgets.QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.mode_buttons = {}
        modes = [("MCQ", "mcq"), ("Code", "code"), ("Interview", "interview")]
        for label, mid in modes:
            b = QtWidgets.QPushButton(label)
            b.setCheckable(True)
            b.setChecked(mid == self.current_mode)
            b.setProperty("mode_id", mid)
            b.setStyleSheet(f"""
                QPushButton {{
                    background: {C['surface2']}; color: {C['muted']};
                    border: 1px solid {C['border']}; border-radius: 4px;
                    padding: 3px 7px; font-size: 10px; font-weight: 700;
                }}
                QPushButton:checked {{
                    background: {C['accent2']}; color: #ffffff;
                    border-color: {C['accent']}; font-weight: 800;
                }}
                QPushButton:hover:!checked {{ color: {C['bright']}; background: {C['surface3']}; }}
            """)
            b.clicked.connect(lambda checked, m=mid: self.set_mode(m))
            self.mode_group.addButton(b)
            self.mode_buttons[mid] = b
            hbox.addWidget(b)

        hbox.addWidget(_sep())

        # Multi-Language Selector: QPushButton + QMenu (no focus steal, unlike QComboBox)
        self.lang_label = QtWidgets.QLabel("Lang:")
        self.lang_label.setStyleSheet(f"color: {C['muted']}; font-size: 10px; font-weight: 700;")
        hbox.addWidget(self.lang_label)

        self._lang_options = [
            ("Python", "python"),
            ("C++", "cpp"),
            ("Java", "java"),
            ("JavaScript", "javascript"),
            ("TypeScript", "typescript"),
        ]
        _cur_label = dict(self._lang_options).get(self.current_language, "Python")
        self.lang_btn = QtWidgets.QPushButton(_cur_label + " ▾")
        self.lang_btn.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        self.lang_btn.setToolTip("Target programming language for code solutions")
        self.lang_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface2']}; color: {C['accent']};
                border: 1px solid {C['border2']}; border-radius: 4px;
                padding: 2px 9px; font-size: 10px; font-weight: 700;
                min-width: 72px;
            }}
            QPushButton:hover {{ border-color: {C['accent']}; color: {C['bright']}; }}
        """)

        def _show_lang_menu():
            """Show a QMenu positioned below the button without stealing focus."""
            menu = QtWidgets.QMenu(self)
            menu.setWindowFlags(
                menu.windowFlags()
                | QtCore.Qt.WindowType.NoDropShadowWindowHint
            )
            # WA_ShowWithoutActivating so browser keeps focus
            menu.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
            menu.setStyleSheet(f"""
                QMenu {{
                    background: {C['surface']}; color: {C['bright']};
                    border: 1px solid {C['border2']}; border-radius: 6px;
                    padding: 4px 0;
                }}
                QMenu::item {{
                    padding: 5px 16px; font-size: 10px; font-weight: 600;
                }}
                QMenu::item:selected {{
                    background: {C['accent2']}; color: #ffffff; border-radius: 4px;
                }}
                QMenu::item:checked {{
                    color: {C['accent']};
                }}
            """)
            for lbl, data in self._lang_options:
                action = menu.addAction(lbl)
                action.setCheckable(True)
                action.setChecked(data == self.current_language)
                action.setData(data)
            chosen = menu.exec(self.lang_btn.mapToGlobal(
                QtCore.QPoint(0, self.lang_btn.height())))
            if chosen and chosen.data():
                self.on_language_changed_from_menu(chosen.data())

        self.lang_btn.clicked.connect(_show_lang_menu)
        hbox.addWidget(self.lang_btn)

        hbox.addStretch()

        # Capture Tools (Snip, Clip, Listen, Ask, CV)
        def _tool_btn(svg_key, label, tip, fn, primary=False):
            b = QtWidgets.QPushButton(label)
            b.setIcon(svg_icon(svg_key, 12, "#ffffff" if primary else C["text"]))
            b.setIconSize(QtCore.QSize(12, 12))
            b.setToolTip(tip)
            if primary:
                b.setStyleSheet(f"""
                    QPushButton {{
                        background: {C['accent2']}; color: #ffffff;
                        border: 1px solid {C['accent']}; border-radius: 4px;
                        padding: 3px 8px; font-size: 10px; font-weight: 700;
                    }}
                    QPushButton:hover {{ background: {C['accent']}; }}
                """)
            else:
                b.setStyleSheet(f"""
                    QPushButton {{
                        background: {C['surface2']}; color: {C['text']};
                        border: 1px solid {C['border']}; border-radius: 4px;
                        padding: 3px 7px; font-size: 10px; font-weight: 600;
                    }}
                    QPushButton:hover {{ background: {C['surface3']}; color: {C['bright']}; border-color: {C['border2']}; }}
                """)
            b.clicked.connect(fn)
            return b

        self.snip_btn = _tool_btn("camera", "Snip", "Snip question on screen (Alt+S)", self.trigger_snip, primary=True)
        hbox.addWidget(self.snip_btn)

        self.clip_btn = _tool_btn("clipboard", "Clip", "Solve from clipboard (Alt+C)", self.solve_clipboard)
        hbox.addWidget(self.clip_btn)

        self.listen_btn = _tool_btn("mic", "Listen", "Listen to speech in real-time (Alt+L)", self.toggle_listen)
        hbox.addWidget(self.listen_btn)

        self.ask_btn = _tool_btn("chat", "Ask", "Custom prompt / paste code (Alt+A)", self.toggle_ask_input)
        hbox.addWidget(self.ask_btn)

        self.cv_btn = _tool_btn("file", "CV", "Upload resume context", self.open_cv_dialog)
        hbox.addWidget(self.cv_btn)
        self.update_cv_button_state()

        self.shield_btn = _tool_btn("shield", "Shield", "Anti-Proctor Shield: Copy zero-blur script to neutralize cheat detection", self.copy_anti_proctor_script)
        hbox.addWidget(self.shield_btn)

        self._tool_btns = [self.snip_btn, self.clip_btn, self.listen_btn, self.ask_btn, self.cv_btn, self.shield_btn]
        self._tool_labels = {
            self.snip_btn: "Snip",
            self.clip_btn: "Clip",
            self.listen_btn: "Listen",
            self.ask_btn: "Ask",
            self.cv_btn: "CV",
            self.shield_btn: "Shield"
        }

        hbox.addWidget(_sep())

        # History Drawer Toggle
        self.history_toggle_btn = QtWidgets.QPushButton()
        self.history_toggle_btn.setIcon(svg_icon("history", 12))
        self.history_toggle_btn.setIconSize(QtCore.QSize(12, 12))
        self.history_toggle_btn.setFixedSize(24, 24)
        self.history_toggle_btn.setToolTip("Toggle Response History")
        self.history_toggle_btn.setStyleSheet(f"""
            QPushButton {{ background: {C['surface2']}; border: 1px solid {C['border']}; border-radius: 4px; }}
            QPushButton:hover {{ background: {C['surface3']}; }}
        """)
        self.history_toggle_btn.clicked.connect(self.toggle_history_drawer)
        hbox.addWidget(self.history_toggle_btn)

        # Runtime Minutes Pill
        self.wallet_btn = QtWidgets.QPushButton()
        self.wallet_btn.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        self.wallet_btn.setToolTip("Remaining Runtime Minutes (Click for details)")
        self.wallet_btn.clicked.connect(lambda: self.open_recharge_dialog())
        hbox.addWidget(self.wallet_btn)
        self._update_wallet_pill()

        # Opacity slider
        self.opacity_slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(30, 100)
        cur_op = self.config.get("opacity", 95)
        self.opacity_slider.setValue(cur_op)
        self.opacity_slider.setFixedWidth(54)
        self.opacity_slider.setToolTip("Window Opacity")
        self.opacity_slider.valueChanged.connect(self.on_opacity_change)
        self.opacity_slider.setStyleSheet(f"""
            QSlider::groove:horizontal {{ height: 3px; background: {C['border2']}; border-radius: 1px; }}
            QSlider::handle:horizontal {{ background: {C['accent']}; width: 8px; margin: -3px 0; border-radius: 4px; }}
        """)
        hbox.addWidget(self.opacity_slider)

        # Window Action Buttons (Pin, Minimize, Settings, Close)
        def _win_btn(svg_key, tip, fn, danger=False):
            b = QtWidgets.QPushButton()
            b.setIcon(svg_icon(svg_key, 12, C["danger"] if danger else C["muted"]))
            b.setIconSize(QtCore.QSize(12, 12))
            b.setFixedSize(22, 22)
            b.setToolTip(tip)
            if danger:
                b.setStyleSheet(f"""
                    QPushButton {{ background: transparent; border: none; border-radius: 3px; }}
                    QPushButton:hover {{ background: rgba(244, 63, 94, 0.2); }}
                """)
            else:
                b.setStyleSheet(f"""
                    QPushButton {{ background: transparent; border: none; border-radius: 3px; }}
                    QPushButton:hover {{ background: {C['surface3']}; }}
                """)
            b.clicked.connect(fn)
            return b

        self.pin_btn = _win_btn("pin_active" if self.is_pinned else "pin", "Always on Top", self.toggle_pin)
        hbox.addWidget(self.pin_btn)

        min_btn = _win_btn("minimize", "Minimize to bubble (Alt+M)", self.minimize_to_floating_icon)
        hbox.addWidget(min_btn)

        self.max_btn = _win_btn("maximize", "Maximize / Restore", self.toggle_maximize)
        hbox.addWidget(self.max_btn)

        self.settings_btn = _win_btn("settings", "Settings (Alt+K)", self.open_settings)
        hbox.addWidget(self.settings_btn)

        close_btn = _win_btn("close", "Close completely (Alt+Q)", self.quit_completely, danger=True)
        hbox.addWidget(close_btn)

        parent_layout.addWidget(self.header_frame)

    def on_language_changed(self, index: int):
        """Legacy slot kept for compatibility. Uses lang_btn if available."""
        if hasattr(self, '_lang_options') and hasattr(self, 'lang_btn'):
            try:
                lang = self._lang_options[index][1]
                self.on_language_changed_from_menu(lang)
            except (IndexError, Exception):
                pass

    def on_language_changed_from_menu(self, lang: str):
        """Called when user selects a language from the focus-neutral QMenu popup."""
        self.current_language = lang
        self.config["code_language"] = lang
        save_config(self.config)
        lang_disp = "C++" if lang == "cpp" else lang.capitalize()
        # Update button label to reflect selected language
        if hasattr(self, 'lang_btn'):
            lbl = {d: l for l, d in self._lang_options}.get(lang, lang_disp)
            self.lang_btn.setText(lbl + " \u25be")
        self._update_copy_code_btn_text()
        self.show_toast(f"\u2713 Target Language: {lang_disp}", icon_key="code")
        self.set_status(f"Target language set to {lang_disp}", state="ready")

    # ── Pay-As-You-Go Wallet & Runtime Billing ────
    def _update_wallet_pill(self):
        """Updates the header wallet status pill with current balance and minutes at ₹2.5/min."""
        if not hasattr(self, 'wallet_btn'):
            return
        user = wallet_manager.get_active_session()
        if user:
            self.active_user = user
        w = wallet_manager.load_wallet()
        rem_secs = w.get("remaining_seconds", 0)
        formatted_time = w.get("formatted_time", "00:00:00")
        allowed = w.get("allowed_by_admin", True)

        if not allowed or rem_secs <= 0:
            self.wallet_btn.setText("⚠️ 00:00:00" if self.width() < 650 else "⚠️ 00:00:00 (Expired)")
            self.wallet_btn.setToolTip("Available time has ended. Please contact the administrator to extend your access.")
            self.wallet_btn.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(244, 63, 94, 0.18);
                    color: {C['danger']};
                    border: 1px solid rgba(244, 63, 94, 0.4);
                    border-radius: 4px;
                    padding: 2px 7px;
                    font-size: 10px;
                    font-weight: 800;
                    font-family: 'JetBrains Mono', monospace;
                }}
                QPushButton:hover {{ background: rgba(244, 63, 94, 0.3); }}
            """)
        else:
            text = f"⏱️ {formatted_time}" if self.width() >= 650 else f"{formatted_time}"
            self.wallet_btn.setText(text)
            self.wallet_btn.setToolTip(f"{formatted_time} remaining (Server Synchronized)")
            self.wallet_btn.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(16, 185, 129, 0.12);
                    color: {C['success']};
                    border: 1px solid rgba(16, 185, 129, 0.35);
                    border-radius: 4px;
                    padding: 2px 7px;
                    font-size: 10px;
                    font-weight: 700;
                    font-family: 'JetBrains Mono', monospace;
                }}
                QPushButton:hover {{ background: rgba(16, 185, 129, 0.22); }}
            """)

    def _on_ui_clock_tick(self):
        """Updates local second countdown while copilot is running."""
        session = wallet_manager.get_active_session() or self.active_user
        if not session:
            return
        rem = session.get("remaining_seconds", 0)
        if rem > 0:
            rem -= 1
            session["remaining_seconds"] = rem
            session["minutesRemaining"] = rem // 60
            session["balanceRupees"] = round((rem / 60) * wallet_manager.RATE_PER_MINUTE, 2)
            self._unsynced_elapsed_seconds += 1
            self.active_user = session
            wallet_manager.save_active_session(session)
            self._update_wallet_pill()
            if rem <= 0:
                self.set_status("Access Expired — 00:00:00 Remaining", state="error")
                self.show_toast("⚠️ Access Expired — Please contact administrator.", icon_key="shield", icon_color=C["danger"])
                self.show_access_expired_popup()

    def _on_wallet_minute_tick(self):
        """Legacy compatibility wrapper."""
        self._on_db_sync_tick()

    def _on_db_sync_tick(self):
        """Server-Side Synchronization: reconciles runtime with backend and checks for Admin top-ups."""
        user_id = self.active_user.get("id") if self.active_user else None
        elapsed = self._unsynced_elapsed_seconds
        self._unsynced_elapsed_seconds = 0

        success, new_secs, status = wallet_manager.sync_with_server(user_id=user_id, elapsed_seconds=elapsed)
        latest = wallet_manager.get_active_session()
        if latest:
            old_secs = self.active_user.get("remaining_seconds", 0) if self.active_user else 0
            self.active_user = latest
            self._update_wallet_pill()

            # If time was credited while expired
            if old_secs <= 0 and new_secs > 0:
                if self._access_expired_dlg:
                    try:
                        self._access_expired_dlg.accept()
                    except Exception:
                        pass
                    self._access_expired_dlg = None
                self.set_status("Ready (Alt+S Snip • Alt+C Solve)", state="ready")
                self.show_toast(f"✓ Admin added time ({wallet_manager.format_seconds_hms(new_secs)})! Copilot unlocked.", icon_key="check", icon_color=C["success"], duration_ms=4500)
            elif old_secs > 0 and new_secs <= 0:
                self.set_status("Access Expired — 00:00:00 Remaining", state="error")
                self.show_toast("⚠️ Access Expired — Please contact the administrator to extend your access.", icon_key="shield", icon_color=C["danger"], duration_ms=6000)
                self.show_access_expired_popup()

    def show_access_expired_popup(self):
        """Shows clean Requirement #10 popup when remaining time ends."""
        if self._access_expired_dlg and self._access_expired_dlg.isVisible():
            return
        try:
            self._access_expired_dlg = AccessExpiredDialog(self)
            self._access_expired_dlg.exec()
            self._access_expired_dlg = None
        except Exception:
            self._access_expired_dlg = None

    def open_recharge_dialog(self, reason=None):
        """Opens access expired dialog."""
        self.show_access_expired_popup()



    # ── Collapsible History Drawer ────────────
    def _build_collapsible_history_drawer(self, parent_layout):
        """Collapsible drawer on the left side that stays hidden by default to maximize code space."""
        self.history_drawer = QtWidgets.QWidget()
        self.history_drawer.setFixedWidth(180)
        self.history_drawer.setStyleSheet(f"background: {C['bg']}; border-right: 1px solid {C['border']};")
        self.history_drawer.setVisible(False)  # Hidden by default!

        vbox = QtWidgets.QVBoxLayout(self.history_drawer)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)

        hdr = QtWidgets.QWidget()
        hdr.setFixedHeight(34)
        hdr.setStyleSheet(f"background: {C['bg']}; border-bottom: 1px solid {C['border']};")
        hdr_h = QtWidgets.QHBoxLayout(hdr)
        hdr_h.setContentsMargins(8, 0, 6, 0)
        hdr_h.setSpacing(4)

        hist_lbl = QtWidgets.QLabel("History")
        hist_lbl.setStyleSheet(f"color: {C['muted']}; font-size: 11px; font-weight: 700;")
        hdr_h.addWidget(hist_lbl, stretch=1)

        clear_btn = QtWidgets.QPushButton()
        clear_btn.setIcon(svg_icon("trash", 11))
        clear_btn.setIconSize(QtCore.QSize(11, 11))
        clear_btn.setFixedSize(20, 20)
        clear_btn.setToolTip("Clear History")
        clear_btn.setStyleSheet(f"QPushButton {{ background: transparent; border: none; border-radius: 3px; }} QPushButton:hover {{ background: {C['surface2']}; }}")
        clear_btn.clicked.connect(self.clear_history)
        hdr_h.addWidget(clear_btn)
        vbox.addWidget(hdr)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet(f"QScrollArea {{ border: none; background: {C['bg']}; }} QScrollBar:vertical {{ background: {C['bg']}; width: 4px; }} QScrollBar::handle:vertical {{ background: {C['border2']}; }}")

        self.history_container = QtWidgets.QWidget()
        self.history_container.setStyleSheet(f"background: {C['bg']};")
        self.history_vbox = QtWidgets.QVBoxLayout(self.history_container)
        self.history_vbox.setContentsMargins(4, 4, 4, 4)
        self.history_vbox.setSpacing(2)

        self.history_empty_lbl = QtWidgets.QLabel("No history yet.")
        self.history_empty_lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.history_empty_lbl.setStyleSheet(f"color: {C['muted']}; font-size: 10px;")
        self.history_vbox.addWidget(self.history_empty_lbl)
        self.history_vbox.addStretch()

        scroll.setWidget(self.history_container)
        vbox.addWidget(scroll, stretch=1)
        parent_layout.addWidget(self.history_drawer)

    def toggle_history_drawer(self):
        visible = not self.history_drawer.isVisible()
        self.history_drawer.setVisible(visible)
        if visible:
            self.show_toast("History drawer opened", icon_key="history")
        else:
            self.show_toast("History drawer closed", icon_key="check")

    # ── Contextual HUD & Input Strips ──────────
    def _build_contextual_cards(self, parent_layout):
        # Ask input strip
        self.ask_container = QtWidgets.QWidget()
        self.ask_container.setStyleSheet(f"background: {C['surface']}; border-bottom: 1px solid {C['border']};")
        ask_row = QtWidgets.QHBoxLayout(self.ask_container)
        ask_row.setContentsMargins(10, 5, 10, 5)
        ask_row.setSpacing(6)

        self.ask_input = QtWidgets.QLineEdit()
        self.ask_input.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        self.ask_input.setPlaceholderText("Type a question, LeetCode problem, or paste code (Enter to solve)…")
        self.ask_input.setStyleSheet(f"""
            QLineEdit {{
                background: {C['bg']}; border: 1px solid {C['border2']};
                border-radius: 5px; padding: 5px 9px;
                color: {C['bright']}; font-size: 11px;
            }}
            QLineEdit:focus {{ border-color: {C['accent']}; }}
        """)
        self.ask_input.returnPressed.connect(self.solve_custom_text)
        def _on_ask_click(ev):
            QtWidgets.QLineEdit.mousePressEvent(self.ask_input, ev)
            cur_hwnd = stealth_core.get_foreground_window()
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.start_typing(self.ask_input, cur_hwnd)
        self.ask_input.mousePressEvent = _on_ask_click
        ask_row.addWidget(self.ask_input)

        send_btn = QtWidgets.QPushButton()
        send_btn.setIcon(svg_icon("send", 12))
        send_btn.setIconSize(QtCore.QSize(12, 12))
        send_btn.setFixedSize(28, 28)
        send_btn.setToolTip("Send (Enter)")
        send_btn.setStyleSheet(f"""
            QPushButton {{ background: {C['accent2']}; border: 1px solid {C['accent']}; border-radius: 4px; }}
            QPushButton:hover {{ background: {C['accent']}; }}
        """)
        send_btn.clicked.connect(self.solve_custom_text)
        ask_row.addWidget(send_btn)

        ask_badge = QtWidgets.QLabel("🛡️ Stealth Typing (0 Blurs)")
        ask_badge.setStyleSheet("background: #06281e; color: #34d399; border: 1px solid #059669; border-radius: 4px; padding: 2px 7px; font-size: 9px; font-weight: 700;")
        ask_row.addWidget(ask_badge)

        self.ask_container.setVisible(False)
        parent_layout.addWidget(self.ask_container)

        # Live speech strip
        self.live_speech_card = QtWidgets.QWidget()
        self.live_speech_card.setStyleSheet(f"background: {C['surface2']}; border-bottom: 1px solid {C['border']};")
        live_row = QtWidgets.QHBoxLayout(self.live_speech_card)
        live_row.setContentsMargins(12, 4, 12, 4)
        live_row.setSpacing(8)

        self.live_mic_icon = QtWidgets.QLabel()
        self.live_mic_icon.setPixmap(svg_to_pixmap(SVG["mic_active"], 14))
        self.live_mic_icon.setFixedSize(14, 14)
        live_row.addWidget(self.live_mic_icon)

        self.live_badge = QtWidgets.QLabel("Listening Live")
        self.live_badge.setStyleSheet(f"color: {C['danger']}; font-size: 10px; font-weight: 800;")
        live_row.addWidget(self.live_badge)

        self.live_text_label = QtWidgets.QLabel("Waiting for interviewer speech…")
        self.live_text_label.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-style: italic;")
        live_row.addWidget(self.live_text_label, stretch=1)

        self.waveform = AudioLevelWidget()
        live_row.addWidget(self.waveform)
        self.live_speech_card.setVisible(False)
        parent_layout.addWidget(self.live_speech_card)

        # Question confirm card
        self.question_confirm_card = QtWidgets.QWidget()
        self.question_confirm_card.setStyleSheet(f"background: {C['surface2']}; border-bottom: 1px solid {C['border']};")
        confirm_vbox = QtWidgets.QVBoxLayout(self.question_confirm_card)
        confirm_vbox.setContentsMargins(10, 6, 10, 6)
        confirm_vbox.setSpacing(4)

        c_header = QtWidgets.QHBoxLayout()
        confirm_title = QtWidgets.QLabel("Question Captured — Review before AI solves:")
        confirm_title.setStyleSheet(f"color: {C['accent']}; font-size: 10px; font-weight: 700;")
        c_header.addWidget(confirm_title)
        c_header.addStretch()
        confirm_vbox.addLayout(c_header)

        self.confirm_text_input = QuestionInputEdit()
        self.confirm_text_input.setFixedHeight(44)
        self.confirm_text_input.setStyleSheet(f"""
            QPlainTextEdit {{
                background: {C['bg']}; border: 1px solid {C['border2']};
                border-radius: 4px; padding: 4px 8px;
                color: {C['bright']}; font-size: 11px;
            }}
        """)
        self.confirm_text_input.submit_requested.connect(self.confirm_and_generate_answer)
        self.confirm_text_input.cancel_requested.connect(self.discard_audio_question)
        confirm_vbox.addWidget(self.confirm_text_input)

        act_row = QtWidgets.QHBoxLayout()
        gen_btn = QtWidgets.QPushButton("Generate Answer")
        gen_btn.setIcon(svg_icon("lightning", 12))
        gen_btn.setStyleSheet(f"QPushButton {{ background: {C['accent2']}; color: white; border-radius: 4px; padding: 3px 10px; font-size: 10px; font-weight: 700; }}")
        gen_btn.clicked.connect(self.confirm_and_generate_answer)
        act_row.addWidget(gen_btn)

        discard_btn = QtWidgets.QPushButton("Discard")
        discard_btn.setStyleSheet(f"QPushButton {{ background: transparent; color: {C['muted']}; border: 1px solid {C['border']}; border-radius: 4px; padding: 3px 8px; font-size: 10px; }}")
        discard_btn.clicked.connect(self.discard_audio_question)
        act_row.addWidget(discard_btn)
        act_row.addStretch()
        confirm_vbox.addLayout(act_row)

        self.question_confirm_card.setVisible(False)
        parent_layout.addWidget(self.question_confirm_card)

    def _build_active_question_bar(self, parent_layout):
        self.question_bar = QtWidgets.QFrame()
        self.question_bar.setStyleSheet(f"""
            QFrame {{
                background: {C['surface2']};
                border-bottom: 1px solid {C['border']};
                padding: 4px 10px;
            }}
        """)
        q_row = QtWidgets.QHBoxLayout(self.question_bar)
        q_row.setContentsMargins(8, 2, 8, 2)
        q_row.setSpacing(6)

        self.qbar_icon = QtWidgets.QLabel()
        self.qbar_icon.setFixedSize(13, 13)
        q_row.addWidget(self.qbar_icon)

        self.qbar_text = QtWidgets.QLabel("")
        self.qbar_text.setStyleSheet(f"color: {C['bright']}; font-size: 11px; font-weight: 600;")
        q_row.addWidget(self.qbar_text, stretch=1)

        self.copy_q_btn = QtWidgets.QPushButton("Copy Q")
        self.copy_q_btn.setIcon(svg_icon("copy", 10))
        self.copy_q_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface3']}; color: {C['text']};
                border: 1px solid {C['border2']}; border-radius: 3px;
                padding: 1px 6px; font-size: 9px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {C['accent2']}; color: white; }}
        """)
        self.copy_q_btn.clicked.connect(self.copy_question)
        q_row.addWidget(self.copy_q_btn)

        self.question_bar.setVisible(False)
        parent_layout.addWidget(self.question_bar)

    def _build_solution_hub(self, parent_layout):
        """Action hub above the code: Segmented tabs & Prominent LeetCode copy buttons."""
        self.solution_hub = QtWidgets.QFrame()
        self.solution_hub.setStyleSheet(f"""
            QFrame {{
                background: {C['bg']};
                border-bottom: 1px solid {C['border']};
            }}
        """)
        hub_layout = QtWidgets.QHBoxLayout(self.solution_hub)
        hub_layout.setContentsMargins(10, 5, 10, 5)
        hub_layout.setSpacing(6)

        # Left: Segmented View Switcher
        self.tab_group = QtWidgets.QButtonGroup(self)
        self.tab_group.setExclusive(True)

        tabs = [
            ("All", "all", "Complete answer with code & explanation"),
            ("Code Only", "code", "Pure runnable code"),
            ("Approach", "explanation", "Intuition & edge cases"),
            ("Complexity", "complexity", "Time & Space complexity"),
        ]

        self.tab_buttons = {}
        for label, tid, tip in tabs:
            tb = QtWidgets.QPushButton(label)
            tb.setCheckable(True)
            tb.setChecked(tid == self.active_tab)
            tb.setProperty("tab_id", tid)
            tb.setToolTip(tip)
            tb.setStyleSheet(f"""
                QPushButton {{
                    background: {C['surface2']}; color: {C['muted']};
                    border: 1px solid {C['border']}; border-radius: 4px;
                    padding: 3px 9px; font-size: 10px; font-weight: 700;
                }}
                QPushButton:checked {{
                    background: {C['accent2']}; color: #ffffff;
                    border-color: {C['accent']}; font-weight: 800;
                }}
                QPushButton:hover:!checked {{ color: {C['bright']}; background: {C['surface3']}; }}
            """)
            tb.clicked.connect(lambda checked, t=tid: self.set_solution_tab(t))
            self.tab_group.addButton(tb)
            self.tab_buttons[tid] = tb
            hub_layout.addWidget(tb)

        self.tab_all_btn = self.tab_buttons["all"]
        self.tab_code_btn = self.tab_buttons["code"]
        self.tab_exp_btn = self.tab_buttons["explanation"]
        self.tab_comp_btn = self.tab_buttons["complexity"]

        hub_layout.addStretch()

        # Right: Prominent LeetCode Copy & Typer Buttons
        # 1. Primary Copy LeetCode Code
        self.copy_code_btn = QtWidgets.QPushButton("Copy Code")
        self.copy_code_btn.setIcon(svg_icon("code", 12, "#ffffff"))
        self.copy_code_btn.setToolTip("Extract and copy clean LeetCode runnable code (Alt+Shift+C)")
        self.copy_code_btn.setEnabled(False)
        self.copy_code_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['success']}; color: #ffffff;
                border: 1px solid {C['success']}; border-radius: 4px;
                padding: 3px 10px; font-size: 10px; font-weight: 800;
            }}
            QPushButton:hover {{ background: #059669; }}
            QPushButton:disabled {{ background: {C['surface2']}; color: {C['muted']}; border-color: {C['border']}; }}
        """)
        self.copy_code_btn.clicked.connect(self.copy_pure_code)
        hub_layout.addWidget(self.copy_code_btn)

        # 2. Auto-Type (Human Typer to bypass paste detection)
        self.auto_type_btn = QtWidgets.QPushButton("Auto-Type")
        self.auto_type_btn.setIcon(svg_icon("keyboard", 12))
        self.auto_type_btn.setToolTip("Types code character-by-character into LeetCode/IDE to bypass paste detection")
        self.auto_type_btn.setEnabled(False)
        self.auto_type_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface2']}; color: {C['purple']};
                border: 1px solid {C['purple']}; border-radius: 4px;
                padding: 3px 9px; font-size: 10px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {C['purple']}; color: white; }}
            QPushButton:disabled {{ color: {C['muted']}; border-color: {C['border']}; }}
        """)
        self.auto_type_btn.clicked.connect(self.start_auto_typer)
        hub_layout.addWidget(self.auto_type_btn)

        # 3. Copy All
        self.copy_btn = QtWidgets.QPushButton("Copy All")
        self.copy_btn.setIcon(svg_icon("copy", 11))
        self.copy_btn.setToolTip("Copy complete answer & explanation")
        self.copy_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface2']}; color: {C['text']};
                border: 1px solid {C['border']}; border-radius: 4px;
                padding: 3px 8px; font-size: 10px; font-weight: 600;
            }}
            QPushButton:hover {{ background: {C['surface3']}; color: {C['bright']}; }}
        """)
        self.copy_btn.clicked.connect(self.copy_answer)
        hub_layout.addWidget(self.copy_btn)

        # 4. Edit Response by Adding Note
        self.edit_note_btn = QtWidgets.QPushButton("Note")
        self.edit_note_btn.setIcon(svg_icon("chat", 11, C["accent"]))
        self.edit_note_btn.setToolTip("Refine or fix solution by adding a note (Alt+E)")
        self.edit_note_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface2']}; color: {C['accent']};
                border: 1px solid {C['border']}; border-radius: 4px;
                padding: 3px 8px; font-size: 10px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {C['surface3']}; color: {C['bright']}; border-color: {C['accent']}; }}
        """)
        self.edit_note_btn.clicked.connect(self.toggle_edit_note_bar)
        hub_layout.addWidget(self.edit_note_btn)

        parent_layout.addWidget(self.solution_hub)
        self._build_edit_note_bar(parent_layout)

    def _build_edit_note_bar(self, parent_layout):
        """Collapsible bar allowing user to add a refinement note or 1-click auto-fix to the current solution."""
        self.edit_note_frame = QtWidgets.QFrame()
        self.edit_note_frame.setStyleSheet(f"""
            QFrame {{
                background: {C['surface2']};
                border-bottom: 1px solid {C['border2']};
            }}
        """)
        note_vbox = QtWidgets.QVBoxLayout(self.edit_note_frame)
        note_vbox.setContentsMargins(10, 6, 10, 6)
        note_vbox.setSpacing(5)

        # Row 1: Header + Dynamic Quick Pill Actions
        pill_row = QtWidgets.QHBoxLayout()
        pill_row.setSpacing(5)

        lbl = QtWidgets.QLabel("Refine Note:")
        lbl.setStyleSheet(f"color: {C['muted']}; font-size: 10px; font-weight: 700;")
        pill_row.addWidget(lbl)

        self.pill_container = QtWidgets.QWidget()
        self.pill_layout = QtWidgets.QHBoxLayout(self.pill_container)
        self.pill_layout.setContentsMargins(0, 0, 0, 0)
        self.pill_layout.setSpacing(5)
        pill_row.addWidget(self.pill_container)

        pill_row.addStretch()

        note_stealth_badge = QtWidgets.QLabel("🛡️ Stealth Typing (0 Blurs)")
        note_stealth_badge.setStyleSheet("background: #06281e; color: #34d399; border: 1px solid #059669; border-radius: 4px; padding: 2px 7px; font-size: 9px; font-weight: 700; margin-right: 4px;")
        pill_row.addWidget(note_stealth_badge)

        close_note_btn = QtWidgets.QPushButton("✕")
        close_note_btn.setFixedSize(18, 18)
        close_note_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent; color: {C['muted']};
                border: none; font-size: 11px; font-weight: bold;
            }}
            QPushButton:hover {{ color: {C['bright']}; }}
        """)
        close_note_btn.clicked.connect(lambda: self.edit_note_frame.setVisible(False))
        pill_row.addWidget(close_note_btn)

        note_vbox.addLayout(pill_row)

        # Row 2: Custom Note Input Field + Submit
        input_row = QtWidgets.QHBoxLayout()
        input_row.setSpacing(6)

        self.note_input = QtWidgets.QLineEdit()
        self.note_input.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        self.note_input.setPlaceholderText("Add a note… Press Enter")
        self.note_input.setStyleSheet(f"""
            QLineEdit {{
                background: {C['bg']}; color: {C['bright']};
                border: 1px solid {C['border2']}; border-radius: 4px;
                padding: 4px 8px; font-size: 11px;
            }}
            QLineEdit:focus {{
                border-color: {C['accent']};
            }}
        """)
        self.note_input.returnPressed.connect(self.submit_custom_refine_note)
        def _on_note_click(ev):
            QtWidgets.QLineEdit.mousePressEvent(self.note_input, ev)
            cur_hwnd = stealth_core.get_foreground_window()
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.start_typing(self.note_input, cur_hwnd)
        self.note_input.mousePressEvent = _on_note_click
        input_row.addWidget(self.note_input)

        self.submit_note_btn = QtWidgets.QPushButton("Refine")
        self.submit_note_btn.setIcon(svg_icon("send", 11, "#ffffff"))
        self.submit_note_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C['accent2']}; color: #ffffff;
                border: 1px solid {C['accent']}; border-radius: 4px;
                padding: 4px 10px; font-size: 10px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {C['accent']}; }}
        """)
        self.submit_note_btn.clicked.connect(self.submit_custom_refine_note)
        input_row.addWidget(self.submit_note_btn)

        note_vbox.addLayout(input_row)

        self.edit_note_frame.setVisible(False)
        parent_layout.addWidget(self.edit_note_frame)
        self.update_refine_pills()

    def _build_answer_area(self, parent_layout):
        self.output_browser = QtWidgets.QTextBrowser()
        self.output_browser.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        self.output_browser.viewport().setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        self.output_browser.contextMenuEvent = lambda event: event.accept()
        self.output_browser.setOpenExternalLinks(False)
        self.output_browser.setOpenLinks(False)
        self.output_browser.anchorClicked.connect(self.on_anchor_clicked)
        self._apply_answer_css()
        self.output_browser.setStyleSheet(f"""
            QTextBrowser {{
                background: {C['surface']};
                border: none;
                color: {C['text']};
                font-size: 13px;
                padding: 12px 14px;
                selection-background-color: {C['accent2']};
                selection-color: white;
            }}
            QScrollBar:vertical {{
                background: {C['surface']}; width: 6px; border-radius: 3px;
            }}
            QScrollBar::handle:vertical {{
                background: {C['border2']}; min-height: 20px; border-radius: 3px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {C['muted']}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
            QScrollBar:horizontal {{
                background: {C['surface']}; height: 6px; border-radius: 3px;
            }}
            QScrollBar::handle:horizontal {{
                background: {C['border2']}; min-width: 20px; border-radius: 3px;
            }}
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
        """)
        parent_layout.addWidget(self.output_browser, stretch=1)

    def _build_footer(self, parent_layout):
        footer = QtWidgets.QWidget()
        footer.setFixedHeight(30)
        footer.setStyleSheet(f"""
            QWidget {{
                background: {C['bg']};
                border-top: 1px solid {C['border']};
                border-bottom-right-radius: 12px;
                border-bottom-left-radius: 12px;
            }}
        """)
        fbox = QtWidgets.QHBoxLayout(footer)
        fbox.setContentsMargins(8, 0, 6, 0)
        fbox.setSpacing(6)

        self.status_dot = QtWidgets.QLabel("●")
        self.status_dot.setStyleSheet(f"color: {C['success']}; font-size: 8px;")
        fbox.addWidget(self.status_dot)

        self.status_label = QtWidgets.QLabel("Ready")
        self.status_label.setStyleSheet(f"color: {C['muted']}; font-size: 10px; font-weight: 600;")
        fbox.addWidget(self.status_label)

        fbox.addStretch()

        self.ask_toggle_btn = QtWidgets.QPushButton()
        self.ask_toggle_btn.setFixedHeight(18)
        self.ask_toggle_btn.clicked.connect(self.toggle_ask_before_answer)
        self.update_ask_toggle_btn_state()
        fbox.addWidget(self.ask_toggle_btn)

        def _ftr_icon_btn(svg_key, tip, fn):
            b = QtWidgets.QPushButton()
            b.setIcon(svg_icon(svg_key, 10, C["muted"]))
            b.setIconSize(QtCore.QSize(10, 10))
            b.setFixedSize(20, 18)
            b.setToolTip(tip)
            b.setStyleSheet(f"QPushButton {{ background: transparent; border: none; }} QPushButton:hover {{ background: {C['surface2']}; }}")
            b.clicked.connect(fn)
            return b

        fbox.addWidget(_ftr_icon_btn("minimize", "Decrease font", lambda: self.change_font_size(-1)))
        self.font_size_lbl = QtWidgets.QPushButton(f"{self.current_font_size}pt")
        self.font_size_lbl.setStyleSheet(f"QPushButton {{ background: transparent; border: none; color: {C['muted']}; font-size: 10px; }}")
        self.font_size_lbl.clicked.connect(self.reset_font_size)
        fbox.addWidget(self.font_size_lbl)
        fbox.addWidget(_ftr_icon_btn("maximize", "Increase font", lambda: self.change_font_size(1)))

        clear_btn = QtWidgets.QPushButton("Clear")
        clear_btn.setIcon(svg_icon("trash", 10))
        clear_btn.setToolTip("Clear solution (Alt+X)")
        clear_btn.setStyleSheet(f"QPushButton {{ background: transparent; color: {C['muted']}; border: none; font-size: 10px; }} QPushButton:hover {{ color: {C['danger']}; }}")
        clear_btn.clicked.connect(self.clear_answer)
        fbox.addWidget(clear_btn)

        grip = ModernSizeGrip(self)
        fbox.addWidget(grip, alignment=QtCore.Qt.AlignmentFlag.AlignBottom | QtCore.Qt.AlignmentFlag.AlignRight)

        parent_layout.addWidget(footer)

    # ── Welcome screen ────────────────────────
    def show_welcome_message(self):
        self.current_response_result = None
        if hasattr(self, 'question_bar'):
            self.question_bar.setVisible(False)
        self.output_browser.setHtml(f"""
        <div style="padding: 24px 18px; font-family: 'Segoe UI', system-ui, sans-serif;">
          <div style="color: {C['accent']}; font-size: 11px; font-weight: 800; letter-spacing: 0.6px; margin-bottom: 12px; text-transform: uppercase;">
            Ghost AI &bull; Elite Interview &amp; Copilot
          </div>
          <div style="color: {C['bright']}; font-size: 20px; font-weight: 800; margin-bottom: 6px;">Ready to solve.</div>
          <div style="color: {C['muted']}; font-size: 12px; margin-bottom: 20px;">
            Target Language: <b style="color: {C['accent']};">{self.current_language.upper()}</b> &bull; Direct runnable LeetCode <code>class Solution</code> template generation.
          </div>

          <div style="background: {C['surface2']}; border: 1px solid {C['border']}; border-radius: 8px; padding: 12px 14px; margin-bottom: 14px;">
            <div style="color: {C['success']}; font-size: 10px; font-weight: 800; letter-spacing: 0.5px; margin-bottom: 8px; text-transform: uppercase;">
              ⚡ Hotkeys &amp; Direct Answers
            </div>
            <table style="width: 100%; border-collapse: collapse;">
              <tr><td style="color:{C['bright']}; font-size:11px; padding:3px 0; width:110px; font-weight:700;">Alt + Shift + C</td><td style="color:{C['accent']}; font-size:11px; padding:3px 0; font-weight:600;">Instant Quick Copy and solution</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + S</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Snip any LeetCode problem or exam question</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + L</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Live Listen to interviewer speech via system audio</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + C</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Solve question copied to clipboard</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + E</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Edit response / Add refinement note</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + H</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Panic Hide / Show toggle</td></tr>
              <tr><td style="color:{C['text']}; font-size:11px; padding:3px 0; font-weight:600;">Alt + M</td><td style="color:{C['muted']}; font-size:11px; padding:3px 0;">Minimize into floating bubble</td></tr>
            </table>
          </div>
          <div style="color: {C['success']}; font-size: 11px; font-weight: 700;">
            &#9679; 100% Screen-Share Invisible: Completely hidden on Zoom, Google Meet, Teams, Discord, OBS &amp; Snipping Tool.
          </div>
        </div>
        """)

    # ── Init subsystems ───────────────────────
    def init_snipper(self):
        self.snipper = ScreenSnipper()
        self.snipper.snip_completed.connect(self.on_snip_completed)
        self.snipper.snip_cancelled.connect(self.on_snip_cancelled)

    def init_hotkeys(self):
        self.hotkey_thread = GlobalHotkeyThread()
        self.hotkey_thread.snip_triggered.connect(self.trigger_snip)
        self.hotkey_thread.clipboard_triggered.connect(self.solve_clipboard)
        self.hotkey_thread.toggle_visible_triggered.connect(self.toggle_visibility)
        self.hotkey_thread.minimize_triggered.connect(self.toggle_minimize_floating)
        self.hotkey_thread.clear_triggered.connect(self.clear_answer)
        self.hotkey_thread.settings_triggered.connect(self.open_settings)
        self.hotkey_thread.ask_triggered.connect(self.toggle_ask_input)
        self.hotkey_thread.listen_triggered.connect(self.toggle_listen)
        self.hotkey_thread.quick_copy_triggered.connect(self.quick_copy_hotkey)
        self.hotkey_thread.note_triggered.connect(self.toggle_edit_note_bar)
        self.hotkey_thread.quit_triggered.connect(self.quit_completely)
        # Redirect Win+Shift+S to our own snip tool (blocks Windows Snipping Tool)
        self.hotkey_thread.snip_screen_triggered.connect(self.trigger_snip)
        self.hotkey_thread.start()

        # SnipGuardThread: low-level hook that intercepts Win+Shift+S at kernel level
        # so the Windows Snipping Tool NEVER launches and never steals browser focus
        self.snip_guard = SnipGuardThread(self)
        self.snip_guard.snip_intercepted.connect(self.trigger_snip)
        self.snip_guard.start()

    def _on_snip_screen_hide(self):
        """
        Legacy fallback: redirects to our own snip tool.
        Win+Shift+S is already blocked at kernel level by SnipGuardThread,
        so this is only called if SnipGuardThread fails to load.
        """
        self.trigger_snip()

    def _on_snip_screen_restore(self):
        """No-op: kept for backward compatibility with tests."""
        pass

    def init_audio_listener(self):
        device_name = self.config.get("audio_device", "system_loopback")
        silence_timeout = float(self.config.get("silence_timeout", 1.6))
        self.audio_listener = AudioListener(device_name=device_name, silence_timeout=silence_timeout, parent=self)
        self.audio_listener.audio_captured.connect(self.solve_audio_question)
        self.audio_listener.live_transcript_updated.connect(self.on_live_transcript_updated)
        self.audio_listener.state_changed.connect(self.on_audio_state_changed)
        self.audio_listener.level_changed.connect(self.on_audio_level_changed)

    # ── Status ────────────────────────────────
    def set_status(self, text: str, state="ready"):
        self.status_label.setText(text)
        colors = {"ready": C["success"], "working": C["accent"], "error": C["danger"], "cleared": C["muted"]}
        self.status_dot.setStyleSheet(f"color: {colors.get(state, C['muted'])}; font-size: 8px;")
        if hasattr(self, 'floating_icon') and self.floating_icon:
            self.floating_icon.set_status_state(state)

    # ── Action handlers ───────────────────────
    def trigger_snip(self):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        self._current_question_source = "snip"
        self._current_question_text = ""
        self.set_status("Snipping… drag to select region.", state="working")
        self.snipper.start_snip()

    def on_snip_completed(self, png_bytes: bytes):
        self.set_status("Solving with AI Vision…", state="working")
        self._show_solving_placeholder("Analyzing question image with AI Vision…")
        self._update_active_question_bar("Screen Snip (Vision)", "snip")
        self.solve_with_ai(image_bytes=png_bytes)

    def on_snip_cancelled(self):
        self.set_status("Snip cancelled.", state="ready")

    def solve_clipboard(self):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        self._current_question_source = "clipboard"
        clipboard = QtWidgets.QApplication.clipboard()
        text = clipboard.text().strip()
        if not text:
            self.set_status("Clipboard is empty.", state="ready")
            self.show_toast("Clipboard is empty!", icon_key="discard", icon_color=C["warn"])
            return
        self._current_question_text = text
        self.set_status("Solving clipboard with AI…", state="working")
        self._update_active_question_bar(text, "clipboard")
        snippet = text[:100].replace("<", "&lt;").replace(">", "&gt;")
        self._show_solving_placeholder(f"Solving from clipboard: <em>{snippet}…</em>")
        self.solve_with_ai(text_prompt=text)

    def toggle_ask_input(self):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        visible = not self.ask_container.isVisible()
        self.ask_container.setVisible(visible)
        if visible:
            cur_hwnd = stealth_core.get_foreground_window()
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.start_typing(self.ask_input, cur_hwnd)
            self.show_toast("🛡️ Stealth Typing Active (0 Blurs)", icon_key="shield")
        else:
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.stop_typing()

    def solve_custom_text(self):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        if hasattr(self, 'stealth_typer'):
            self.stealth_typer.stop_typing()
        text = self.ask_input.text().strip()
        if not text: return
        self._current_question_source = "ask"
        self._current_question_text = text
        self.set_status("Solving…", state="working")
        self._update_active_question_bar(text, "ask")
        snippet = text.replace("<", "&lt;").replace(">", "&gt;")
        self._show_solving_placeholder(f"<em>{snippet[:120]}</em>")
        self.solve_with_ai(text_prompt=text)
        self.ask_input.clear()
        self.ask_container.setVisible(False)

    def toggle_listen(self):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        if not self.audio_listener:
            self.init_audio_listener()
        self.audio_listener.toggle_listening()

    def on_live_transcript_updated(self, text: str, is_final: bool):
        if hasattr(self, 'live_text_label') and text:
            display = f'"{text}▌"' if not is_final else f'"{text}"'
            self.live_text_label.setText(display)

    def solve_audio_question(self, wav_bytes: bytes, question_text: str = ""):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        self._current_question_source = "audio"
        self._current_question_text = question_text.strip()
        if hasattr(self, 'live_speech_card'):
            self.live_speech_card.setVisible(False)
        if hasattr(self, 'floating_icon') and self.floating_icon and self.floating_icon.isVisible():
            self.restore_from_floating_icon()
        ask_before = self.config.get("ask_before_answering", False)
        if ask_before:
            self.pending_wav_bytes = wav_bytes
            self.pending_question_text = question_text.strip()
            display = self.pending_question_text or "Spoken question captured — review before solving."
            self.confirm_text_input.setPlainText(display)
            self.question_confirm_card.setVisible(True)
            self.confirm_text_input.setFocus()
            self.confirm_text_input.selectAll()
            self.set_status("Question captured — review & confirm.", state="ready")
        else:
            self._execute_audio_solve(wav_bytes, question_text)

    def confirm_and_generate_answer(self):
        self.question_confirm_card.setVisible(False)
        text = self.confirm_text_input.toPlainText().strip()
        self._current_question_text = text
        wav = self.pending_wav_bytes
        self.pending_wav_bytes = None
        self._execute_audio_solve(wav, text)

    def relisten_audio_question(self):
        self.question_confirm_card.setVisible(False)
        self.pending_wav_bytes = None
        self.toggle_listen()

    def discard_audio_question(self):
        self.question_confirm_card.setVisible(False)
        self.pending_wav_bytes = None
        self.set_status("Question discarded.", state="ready")

    def _execute_audio_solve(self, wav_bytes: bytes, question_text: str = ""):
        self.set_status("Solving with AI…", state="working")
        label = question_text[:120] if question_text else "Spoken audio question"
        self._update_active_question_bar(question_text or "Spoken Audio Question", "audio")
        self._show_solving_placeholder(f'Spoken: <em>"{label}"</em>')
        self.solve_with_ai(audio_bytes=wav_bytes, text_prompt=question_text or None)

    def _update_active_question_bar(self, text: str, source: str):
        if not text:
            self.question_bar.setVisible(False)
            return
        self._current_question_text = text
        self.qbar_icon.setPixmap(svg_to_pixmap(SVG.get(SOURCE_ICONS.get(source, "chat")), 12, C["accent"]))
        display = (text[:80] + "…") if len(text) > 80 else text
        self.qbar_text.setText(f"Q: {display}")
        self.question_bar.setVisible(True)

    def _get_thinking_sentences(self) -> list:
        lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()
        if self.current_mode == "code":
            return [
                f"Synthesizing optimal algorithm in {lang_disp}…",
                "Analyzing problem constraints & edge cases…",
                f"Constructing clean, runnable {lang_disp} solution…",
                "Optimizing memory layout & Big-O bounds…",
                "Verifying correctness & boundary conditions…",
            ]
        elif self.current_mode == "mcq":
            return [
                "Scanning question premise & core logic…",
                "Evaluating candidate options & deductions…",
                "Eliminating distractors & confirming verdict…",
                "Formulating crisp rationale & explanation…",
            ]
        elif self.current_mode == "interview":
            return [
                "Formulating structured interview response…",
                "Outlining high-level strategy & key approach…",
                "Synthesizing technical trade-offs & real-world context…",
                "Refining confident first-person spoken delivery…",
            ]
        else:
            return [
                "Analyzing query & contextual inputs…",
                "Synthesizing detailed technical response…",
                "Structuring clear, comprehensive explanation…",
            ]

    def _show_solving_placeholder(self, detail: str = ""):
        self._thinking_detail = detail
        self._thinking_step = 0
        self._update_thinking_html()
        if hasattr(self, '_thinking_timer') and not self._thinking_timer.isActive():
            self._thinking_timer.start()

    def _start_thinking_animation(self, detail: str = ""):
        self._show_solving_placeholder(detail)

    def _stop_thinking_animation(self):
        if hasattr(self, '_thinking_timer') and self._thinking_timer.isActive():
            self._thinking_timer.stop()

    def _on_thinking_tick(self):
        self._thinking_step += 1
        self._update_thinking_html()

    def _update_thinking_html(self):
        spinners = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        spinner_char = spinners[self._thinking_step % len(spinners)]

        sentences = self._get_thinking_sentences()
        sentence_idx = (self._thinking_step // 3) % len(sentences)
        active_sentence = sentences[sentence_idx]

        pulse_colors = ["#6366f1", "#818cf8", "#38bdf8", "#34d399", "#a855f7"]
        accent_color = pulse_colors[self._thinking_step % len(pulse_colors)]
        progress_pct = min(96, 20 + (self._thinking_step * 7) % 78)

        mode_titles = {
            "code": "CODE ENGINE",
            "mcq": "MCQ VERIFIER",
            "interview": "INTERVIEW COPILOT",
        }
        badge_title = mode_titles.get(self.current_mode, "AI REASONING")

        detail_block = ""
        if self._thinking_detail:
            detail_block = f"""
            <div style="margin-top: 12px; padding: 8px 12px; background-color: rgba(15, 23, 42, 0.6); border: 1px solid rgba(51, 65, 85, 0.5); border-radius: 6px; color: {C['muted']}; font-size: 11px; line-height: 1.4;">
                {self._thinking_detail}
            </div>
            """

        html_content = f"""
        <div style="padding: 24px 18px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
          <div style="background-color: #0b0f19; border: 1px solid {accent_color}; border-radius: 10px; padding: 18px 20px;">
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td>
                  <span style="background-color: rgba(99, 102, 241, 0.15); color: {accent_color}; border: 1px solid {accent_color}; padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: 800; letter-spacing: 0.6px;">
                    ⚡ {badge_title}
                  </span>
                  &nbsp;
                  <span style="color: #64748b; font-size: 11px; font-weight: 600;">Thinking…</span>
                </td>
                <td align="right">
                  <span style="font-family: monospace; font-size: 16px; font-weight: bold; color: {accent_color};">{spinner_char}</span>
                </td>
              </tr>
            </table>

            <div style="margin-top: 14px; font-size: 14px; font-weight: 700; color: #ffffff; line-height: 1.4;">
              <span style="color: {accent_color}; font-size: 16px;">▶</span> {active_sentence}
            </div>

            <div style="margin-top: 14px; background-color: #1e293b; border-radius: 4px; height: 4px; overflow: hidden;">
              <div style="background-color: {accent_color}; width: {progress_pct}%; height: 100%; border-radius: 4px;"></div>
            </div>

            {detail_block}
          </div>
        </div>
        """
        self.output_browser.setHtml(html_content)

    def solve_with_ai(self, image_bytes=None, text_prompt=None, audio_bytes=None, previous_answer=None, user_note=None):
        can_run, reason, mins, bal = wallet_manager.can_run_app()
        if not can_run:
            self.set_status("Session Paused — Recharge Required", state="error")
            self.show_toast(f"Session Paused: {reason}", icon_key="shield", icon_color=C["danger"])
            self.open_recharge_dialog(reason)
            return
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait(300)
        self.current_stream_text = ""
        self.extracted_codes = []
        self.current_response_result = None

        if hasattr(self, 'copy_code_btn'):
            self.copy_code_btn.setEnabled(False)
            self.copy_code_btn.setText("Copy Code")
        if hasattr(self, 'auto_type_btn'):
            self.auto_type_btn.setEnabled(False)

        cv_ctx = cv_session.get_prompt_context() if cv_session.has_cv() else None
        self.worker = AISolveWorker(
            mode=self.current_mode,
            language=self.current_language,
            image_bytes=image_bytes,
            text_prompt=text_prompt,
            audio_bytes=audio_bytes,
            cv_context=cv_ctx,
            previous_answer=previous_answer,
            user_note=user_note
        )
        self.worker.chunk_received.connect(self.on_chunk_received)
        self.worker.solve_completed.connect(self.on_solve_completed)
        self.worker.solve_failed.connect(self.on_solve_failed)
        self.worker.start()

    def on_chunk_received(self, chunk: str):
        self._stop_thinking_animation()
        self.current_stream_text += chunk
        self.output_browser.setMarkdown(self.current_stream_text)
        sb = self.output_browser.verticalScrollBar()
        sb.setValue(sb.maximum())

    def on_solve_completed(self, full_text: str):
        self._stop_thinking_animation()
        self.set_status("Answer ready.", state="ready")
        self.current_stream_text = full_text

        try:
            res = format_full_response(full_text, default_lang=self.current_language)
            self.current_response_result = res
            self.extracted_codes = res.extracted_codes

            lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()

            if self.extracted_codes:
                self.copy_code_btn.setEnabled(True)
                self.auto_type_btn.setEnabled(True)
                self._update_copy_code_btn_text()
            else:
                self.copy_code_btn.setEnabled(False)
                self.auto_type_btn.setEnabled(False)
                self.copy_code_btn.setText("Copy Code")

            self._render_active_tab_view()
            self.update_refine_pills(self._current_question_text, self.current_response_result)

            if res.mcq_verdict:
                self.show_toast(f"✓ Option {res.mcq_verdict['letter']} Detected!", icon_key="check")
            elif self.extracted_codes:
                self.show_toast(f"✓ {lang_disp} Solution Ready!", icon_key="check")
            else:
                self.show_toast("✓ Answer Ready!", icon_key="check")

        except Exception as e:
            print(f"[GhostOverlay] Format error: {e}")
            self.output_browser.setMarkdown(full_text)

        self._add_to_history(
            question=self._current_question_text,
            answer=full_text,
            source=self._current_question_source,
            mode=self.current_mode,
            result_obj=self.current_response_result
        )

    def on_solve_failed(self, error_msg: str):
        self._stop_thinking_animation()
        self.set_status("Request failed.", state="error")
        self.output_browser.setHtml(f"""
        <div style="padding: 16px; font-family: 'Segoe UI', system-ui, sans-serif;">
          <div style="color: {C['danger']}; font-weight: 700; margin-bottom: 6px;">Error</div>
          <div style="color: {C['muted']}; font-size: 12px;">{error_msg}</div>
        </div>
        """)
        self.show_toast("Solve failed. Check API key in Settings.", icon_key="discard", icon_color=C["danger"])

    # ── Segmented Solution View Tabs ──────────
    def set_solution_tab(self, tab_id: str):
        self.active_tab = tab_id
        for btn in self.tab_group.buttons():
            btn.setChecked(btn.property("tab_id") == tab_id)
        self._render_active_tab_view()

    def _render_active_tab_view(self):
        if not self.current_response_result:
            if self.current_stream_text:
                self.output_browser.setMarkdown(self.current_stream_text)
            return

        res = self.current_response_result
        if self.active_tab == "code":
            self.output_browser.setHtml(res.code_only_html)
        elif self.active_tab == "explanation":
            self.output_browser.setHtml(res.explanation_only_html)
        elif self.active_tab == "complexity":
            self.output_browser.setHtml(res.complexity_only_html)
        else:
            self.output_browser.setHtml(res.full_html)

    # ── Quick Copy & Auto-Typer Actions ────────
    def copy_answer(self):
        text = self.current_stream_text or self.output_browser.toPlainText()
        if text:
            QtWidgets.QApplication.clipboard().setText(text)
            self.copy_btn.setText("Copied!")
            QtCore.QTimer.singleShot(1500, lambda: self.copy_btn.setText("Copy All"))
            self.show_toast("✓ Complete answer copied to clipboard!", icon_key="check")
            self.set_status("Answer copied!", state="ready")
        else:
            self.show_toast("No answer to copy!", icon_key="discard", icon_color=C["warn"])

    def copy_pure_code(self):
        if self.extracted_codes:
            code_text = "\n\n".join(self.extracted_codes)
            QtWidgets.QApplication.clipboard().setText(code_text)
            orig_text = self.copy_code_btn.text()
            self.copy_code_btn.setText("Copied!")
            QtCore.QTimer.singleShot(1500, lambda: self.copy_code_btn.setText(orig_text))
            lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()
            self.show_toast(f"✓ {lang_disp} code copied to clipboard!", icon_key="check")
            self.set_status(f"{lang_disp} code copied!", state="ready")
        else:
            self.copy_answer()

    def copy_question(self):
        if self._current_question_text:
            QtWidgets.QApplication.clipboard().setText(self._current_question_text)
            self.copy_q_btn.setText("Copied!")
            QtCore.QTimer.singleShot(1500, lambda: self.copy_q_btn.setText("Copy Q"))
            self.show_toast("✓ Question copied to clipboard!", icon_key="check")
            self.set_status("Question copied!", state="ready")

    def quick_copy_hotkey(self):
        """Global Alt+Shift+C: Instantly copies latest code, or full answer."""
        lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()
        if self.extracted_codes:
            self.copy_pure_code()
            self.show_toast(f"✓ (Alt+Shift+C) {lang_disp} code copied!", icon_key="check")
        elif self.current_stream_text:
            self.copy_answer()
            self.show_toast("✓ (Alt+Shift+C) Answer copied to clipboard!", icon_key="check")

    def copy_anti_proctor_script(self):
        """Copies the zero-blur Anti-Proctor JavaScript snippet to clipboard."""
        script = stealth_core.get_anti_proctor_script()
        QtWidgets.QApplication.clipboard().setText(script)
        self.show_toast("🛡️ Anti-Proctor script copied! Paste in browser console (F12) to block all blurs.", icon_key="shield", duration_ms=3000)

    # ── Edit Response / Refinement Note ───────
    def toggle_edit_note_bar(self):
        """Toggle the collapsible refinement note bar (Alt+E)."""
        if not hasattr(self, 'edit_note_frame'):
            return
        should_show = self.edit_note_frame.isHidden()
        if should_show:
            cur_hwnd = stealth_core.get_foreground_window()
            self.update_refine_pills(self._current_question_text, self.current_response_result)
            self.edit_note_frame.setVisible(True)
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.start_typing(self.note_input, cur_hwnd)
            self.show_toast("🛡️ Stealth Typing Active (0 Blurs)", icon_key="shield")
        else:
            self.edit_note_frame.setVisible(False)
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.stop_typing()

    def update_refine_pills(self, question_text: str = "", response_result=None):
        """
        Dynamically generates quick refinement action pills and note input placeholder
        tailored specifically to the active question type (MCQ vs Interview vs Code).
        """
        if not hasattr(self, 'pill_layout') or not hasattr(self, 'note_input'):
            return

        # Clear existing pill buttons
        while self.pill_layout.count():
            item = self.pill_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        res = response_result or self.current_response_result
        q_text = (question_text or self._current_question_text or "").lower()
        full_text = (self.current_stream_text or "").lower()

        # Determine question type
        is_mcq = (
            self.current_mode == "mcq"
            or (res and getattr(res, 'mcq_verdict', None))
            or "**option " in full_text
            or "winning option" in full_text
            or "### 🎯 correct option" in full_text
        )
        is_interview = self.current_mode == "interview"

        quick_pills = []

        if is_mcq:
            self.note_input.setPlaceholderText("Add an MCQ note (e.g. 'Check Option B', 'Why is C wrong?', 'Show math proof')… Press Enter")

            # Detect if question is math/calculation or conceptual
            if any(k in q_text or k in full_text for k in ["calculate", "probability", "matrix", "formula", "sum", "integral", "derivative", "complexity", "o(n", "o(1"]):
                quick_pills = [
                    ("🎯 Re-Verify Option", "Carefully double-check the question calculations and confirm or fix the winning option letter."),
                    ("⚡ Step-by-Step Math", "Show the detailed step-by-step mathematical derivation and proof for the correct option."),
                    ("🔍 Why Others False", "Explain in detail why each of the other three distractor choices is mathematically incorrect."),
                    ("📝 1-Line Verdict", "Provide a concise 1-sentence verdict and immediate reason for the answer."),
                ]
            else:
                quick_pills = [
                    ("🎯 Re-Verify Option", "Carefully re-verify the question and confirm or correct the winning option in bold."),
                    ("🔍 Explain Distractors", "Explain why each of the incorrect options (distractors) is wrong."),
                    ("📚 Key Concepts", "Explain the core underlying concept or theory tested in this question."),
                    ("📝 1-Line Verdict", "State the winning option and a 1-sentence summary of why it is right."),
                ]

        elif is_interview:
            self.note_input.setPlaceholderText("Add an interview note (e.g. 'Make it more senior', 'Include trade-offs', 'STAR format')… Press Enter")
            if any(k in q_text for k in ["tell me about", "conflict", "challenge", "failure", "proud", "leadership", "team", "situation"]):
                quick_pills = [
                    ("🌟 STAR Format", "Structure this answer cleanly using the Situation, Task, Action, and Result framework."),
                    ("👔 Senior Leadership", "Refine this response to demonstrate senior engineering ownership, cross-team impact, and maturity."),
                    ("⏱️ 60s Elevator Pitch", "Condense this response into a concise, punchy spoken answer under 60 seconds."),
                    ("💡 Add Takeaways", "Add key lessons learned and proactive takeaways at the end of the answer."),
                ]
            else:
                quick_pills = [
                    ("🎤 Sound More Senior", "Refine this response to sound like a senior/staff engineer with architecture and trade-off depth."),
                    ("⏱️ 60s Elevator Pitch", "Deliver a crisp, punchy spoken explanation in under 60 seconds."),
                    ("⚖️ Trade-offs & Scale", "Highlight scalability trade-offs, bottlenecks, and alternative designs."),
                    ("💡 Follow-up Hooks", "Add insightful follow-up points that invite positive interviewer engagement."),
                ]

        else:
            # Coding Mode / LeetCode
            self.note_input.setPlaceholderText("Add a coding note (e.g. 'Use two pointers', 'Avoid static_cast', 'Check edge cases')… Press Enter")

            # Detect problem domain
            if any(k in q_text or k in full_text for k in ["dp", "dynamic programming", "memoiz", "recur", "fibonacci", "knapsack"]):
                quick_pills = [
                    ("💾 Space Optimize", "Optimize the space complexity from O(N) or O(N^2) to O(1) space if possible."),
                    ("⚡ Iterative DP", "Convert any top-down recursion into a clean bottom-up iterative DP table or array."),
                    ("⚡ Check & Fix", "Auto-check all base cases, constraints, and balance brackets with zero errors."),
                    ("💬 Add Comments", "Add clear comments explaining state definitions and transitions."),
                ]
            elif any(k in q_text or k in full_text for k in ["two pointer", "sliding window", "binary search", "sorted array"]):
                quick_pills = [
                    ("🚀 Optimize O(N)", "Optimize the solution to strictly linear O(N) or logarithmic O(log N) time."),
                    ("⚡ Check & Fix", "Auto-check boundary conditions, off-by-one errors, and balance all brackets."),
                    ("🧹 Clean Code", "Simplify pointer logic, remove redundant variables, and make code concise."),
                    ("💬 Add Comments", "Add clear comments explaining pointer movements and invariants."),
                ]
            elif any(k in q_text or k in full_text for k in ["tree", "graph", "bfs", "dfs", "topological", "cycle"]):
                quick_pills = [
                    ("🌳 BFS / Iterative", "Provide an iterative BFS or queue-based traversal to prevent recursion stack overflow."),
                    ("⚡ Check & Fix", "Auto-check visited set, null pointers, empty graphs, and balance all brackets."),
                    ("🚀 Optimize", "Optimize adjacency representation and traversal time to optimal O(V + E)."),
                    ("💬 Add Comments", "Add clear comments explaining visited state and graph traversal."),
                ]
            else:
                quick_pills = [
                    ("⚡ Check & Fix", "Auto-check this solution, balance all brackets, verify types and edge cases, and fix any errors."),
                    ("🚀 Optimize", "Optimize the time and space complexity to be as optimal as possible."),
                    ("🧹 Clean Code", "Simplify the implementation, remove redundant variables, and make it concise and clean."),
                    ("💬 Add Comments", "Add clear, line-by-line comments explaining each step of the algorithm."),
                ]

        # Populate pill buttons
        for pill_label, pill_prompt in quick_pills:
            pb = QtWidgets.QPushButton(pill_label)
            pb.setStyleSheet(f"""
                QPushButton {{
                    background: {C['surface3']}; color: {C['text']};
                    border: 1px solid {C['border2']}; border-radius: 9px;
                    padding: 2px 7px; font-size: 9px; font-weight: 600;
                }}
                QPushButton:hover {{
                    background: {C['accent2']}; color: #ffffff; border-color: {C['accent']};
                }}
            """)
            pb.clicked.connect(lambda checked, p=pill_prompt: self.apply_refine_note(p))
            self.pill_layout.addWidget(pb)

    def submit_custom_refine_note(self):
        try:
            note = self.note_input.text().strip()
            if not note:
                self.show_toast("Please enter a note to refine the solution.", icon_key="discard", icon_color=C["warn"])
                return
            self.note_input.clear()
            self.apply_refine_note(note)
        except Exception as e:
            print(f"[GhostOverlay] submit_custom_refine_note error: {e}")

    def apply_refine_note(self, note_text: str):
        """Refines the current solution using the user's note or 1-click quick action."""
        try:
            if hasattr(self, 'stealth_typer'):
                self.stealth_typer.stop_typing()
            if not note_text:
                return

            prev_answer = ""
            if self.current_stream_text:
                prev_answer = self.current_stream_text.strip()
            elif self.current_response_result and getattr(self.current_response_result, 'full_html', None):
                prev_answer = self.output_browser.toPlainText().strip()
            elif self.output_browser:
                prev_answer = self.output_browser.toPlainText().strip()

            if not prev_answer or "Welcome to Ghost AI" in prev_answer or "100% Screen-Share Invisible" in prev_answer:
                self.show_toast("No solution to refine! Solve a problem first.", icon_key="discard", icon_color=C["warn"])
                return

            if hasattr(self, 'edit_note_frame'):
                self.edit_note_frame.setVisible(False)

            short_note = (note_text[:30] + "…") if len(note_text) > 30 else note_text
            self.show_toast(f"Refining: '{short_note}'", icon_key="chat", duration_ms=2500)
            self.set_status(f"Refining solution: {short_note}", state="working")

            self._show_solving_placeholder(f"Refining with note: <em>\"{short_note}\"</em>")
            self.solve_with_ai(
                text_prompt=None,
                previous_answer=prev_answer,
                user_note=note_text
            )
        except Exception as e:
            print(f"[GhostOverlay] apply_refine_note error: {e}")
            self.show_toast(f"Refinement error: {e}", icon_key="discard", icon_color=C["danger"])

    def on_anchor_clicked(self, url: QtCore.QUrl):
        url_str = url.toString()
        if url_str.startswith("copy-code:"):
            try:
                idx = int(url_str.split(":")[1])
                if 0 <= idx < len(self.extracted_codes):
                    snippet = self.extracted_codes[idx]
                    QtWidgets.QApplication.clipboard().setText(snippet)
                    lang_disp = "C++" if self.current_language.lower() == "cpp" else self.current_language.upper()
                    self.show_toast(f"✓ {lang_disp} snippet copied to clipboard!", icon_key="check")
                    self.set_status("Code snippet copied!", state="ready")
                    return
            except Exception as e:
                print(f"[GhostOverlay] copy-code error: {e}")
        elif url_str.startswith("copy-mcq:"):
            try:
                if self.current_response_result and self.current_response_result.mcq_verdict:
                    val = self.current_response_result.mcq_verdict["full"]
                    QtWidgets.QApplication.clipboard().setText(val)
                    self.show_toast(f"✓ {val} copied to clipboard!", icon_key="check")
                    self.set_status("Option copied!", state="ready")
                    return
            except Exception as e:
                print(f"[GhostOverlay] copy-mcq error: {e}")
        QtGui.QDesktopServices.openUrl(url)

    # ── Auto-Typer Simulation ──────────────────
    def start_auto_typer(self):
        if self.auto_typer_thread and self.auto_typer_thread.isRunning():
            self.auto_typer_thread.cancel()
            self.auto_type_btn.setText("Auto-Type")
            self.show_toast("Auto-typing cancelled.", icon_key="discard")
            return

        # Extract pure code blocks rather than conversational markdown
        if self.extracted_codes:
            code_to_type = "\n\n".join(self.extracted_codes)
        elif self.current_response_result and getattr(self.current_response_result, 'clean_code_text', None):
            code_to_type = self.current_response_result.clean_code_text
        else:
            matches = re.findall(r'```(?:[a-zA-Z0-9_+#-]*)\n?(.*?)```', self.current_stream_text, re.DOTALL)
            if matches:
                code_to_type = "\n\n".join([m.strip() for m in matches])
            else:
                code_to_type = self.current_stream_text.strip()

        if not code_to_type:
            self.show_toast("No code available to auto-type!", icon_key="discard", icon_color=C["warn"])
            return

        self.auto_type_btn.setText("Stop (Esc)")
        clean_rep = self.config.get("autotype_clean_replace", True)
        self.auto_typer_thread = AutoTyperThread(code_to_type, countdown_secs=3, clean_replace=clean_rep, parent=self)
        self.auto_typer_thread.countdown_tick.connect(self._on_auto_type_tick)
        self.auto_typer_thread.typing_started.connect(self._on_auto_type_started)
        self.auto_typer_thread.typing_finished.connect(self._on_auto_type_finished)
        self.auto_typer_thread.typing_cancelled.connect(self._on_auto_type_cancelled)
        self.auto_typer_thread.start()

    def _on_auto_type_tick(self, count: int):
        self.show_toast(f"Click into editor! Typing in {count}s… (Esc to cancel)", icon_key="keyboard", duration_ms=1100)
        self.set_status(f"Click into editor! Typing in {count}s…", state="working")

    def _on_auto_type_started(self):
        self.show_toast("⌨️ Auto-typing code… Press Esc to stop.", icon_key="keyboard", duration_ms=2500)
        self.set_status("Typing code… (Press Esc to cancel)", state="working")

    def _on_auto_type_finished(self):
        self.auto_type_btn.setText("Auto-Type")
        self.show_toast("✓ Auto-typing complete!", icon_key="check")
        self.set_status("Auto-typing complete.", state="ready")

    def _on_auto_type_cancelled(self):
        self.auto_type_btn.setText("Auto-Type")
        self.set_status("Auto-typing cancelled.", state="ready")

    def clear_answer(self):
        if self.auto_typer_thread and self.auto_typer_thread.isRunning():
            self.auto_typer_thread.cancel()
        self.extracted_codes = []
        self.current_response_result = None
        self.current_stream_text = ""
        self._current_question_text = ""
        if hasattr(self, 'question_bar'):
            self.question_bar.setVisible(False)
        if hasattr(self, 'edit_note_frame'):
            self.edit_note_frame.setVisible(False)
        if hasattr(self, 'copy_code_btn'):
            self.copy_code_btn.setEnabled(False)
            self.copy_code_btn.setText("Copy Code")
        if hasattr(self, 'auto_type_btn'):
            self.auto_type_btn.setEnabled(False)
        self.output_browser.clear()
        self.show_welcome_message()
        self.set_status("Cleared.", state="cleared")

    # ── Response history ──────────────────────
    def _add_to_history(self, question: str, answer: str, source: str, mode: str, result_obj=None):
        item = HistoryItem(question=question, answer=answer, source=source, mode=mode, result_obj=result_obj)
        self._history.insert(0, item)
        if self.history_empty_lbl.isVisible():
            self.history_empty_lbl.setVisible(False)
        entry = HistoryEntryWidget(item)
        entry.clicked.connect(self._on_history_item_clicked)
        self.history_vbox.insertWidget(0, entry)
        self._select_history_entry(entry)
        while len(self._history) > 30:
            self._history.pop()
            count = self.history_vbox.count()
            for i in range(count - 1, -1, -1):
                w = self.history_vbox.itemAt(i)
                if w and isinstance(w.widget(), HistoryEntryWidget):
                    w.widget().deleteLater()
                    self.history_vbox.removeItem(w)
                    break

    def _on_history_item_clicked(self, item: HistoryItem):
        for i in range(self.history_vbox.count()):
            w = self.history_vbox.itemAt(i)
            if w and isinstance(w.widget(), HistoryEntryWidget):
                ew = w.widget()
                ew.set_selected(ew.item is item)
                if ew.item is item:
                    self._active_history_widget = ew

        self._current_question_text = item.question
        self._current_question_source = item.source
        self.current_stream_text = item.answer

        if item.question:
            self._update_active_question_bar(item.question, item.source)
        else:
            self.question_bar.setVisible(False)

        try:
            res = item.result_obj if item.result_obj else format_full_response(item.answer)
            self.current_response_result = res
            self.extracted_codes = res.extracted_codes
            self.copy_code_btn.setEnabled(bool(res.extracted_codes))
            self.auto_type_btn.setEnabled(bool(res.extracted_codes))
            lang_disp = self.current_language.upper()
            self.copy_code_btn.setText(f"Copy {lang_disp} Code")
            self._render_active_tab_view()
            self.update_refine_pills(item.question, self.current_response_result)
        except Exception:
            self.output_browser.setMarkdown(item.answer)

        self.set_status(f"Viewing: {item.timestamp} · {item.source}", state="ready")

    def _select_history_entry(self, entry: HistoryEntryWidget):
        for i in range(self.history_vbox.count()):
            w = self.history_vbox.itemAt(i)
            if w and isinstance(w.widget(), HistoryEntryWidget):
                w.widget().set_selected(w.widget() is entry)
        self._active_history_widget = entry

    def clear_history(self):
        self._history.clear()
        for i in reversed(range(self.history_vbox.count())):
            item = self.history_vbox.itemAt(i)
            if item and isinstance(item.widget(), HistoryEntryWidget):
                item.widget().deleteLater()
                self.history_vbox.removeItem(item)
        self.history_empty_lbl.setVisible(True)
        self._active_history_widget = None
        self.show_toast("History cleared.", icon_key="trash")

    # ── Controls ──────────────────────────────
    def set_mode(self, mode_id: str):
        self.current_mode = mode_id
        for btn in self.mode_group.buttons():
            btn.setChecked(btn.property("mode_id") == mode_id)
        self.set_status(f"Mode: {mode_id.upper()}", state="ready")
        self.show_toast(f"Mode: {mode_id.upper()}", icon_key="lightning")
        self.update_refine_pills()

    def on_opacity_change(self, val: int):
        self.setWindowOpacity(val / 100.0)
        cfg = load_config()
        cfg["opacity"] = val
        self.config = cfg
        save_config(cfg)

    def _apply_answer_css(self):
        sz = getattr(self, 'current_font_size', 13)
        code_sz = max(10, sz - 1)
        h1_sz = sz + 3
        h2_sz = sz + 1
        answer_css = f"""
            body {{
                color: {C['text']};
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
                font-size: {sz}px;
                line-height: 1.6;
                margin: 0; padding: 0;
            }}
            h1, h2, h3, h4 {{
                color: {C['bright']}; font-weight: 700;
                margin-top: 12px; margin-bottom: 4px;
            }}
            h1 {{ font-size: {h1_sz}px; }} h2 {{ font-size: {h2_sz}px; }} h3 {{ font-size: {sz}px; }}
            p {{ margin-top: 3px; margin-bottom: 7px; font-size: {sz}px; }}
            code {{
                font-family: 'Consolas', 'Cascadia Code', 'Courier New', monospace;
                background: {C['surface2']}; color: {C['accent']};
                padding: 1px 5px; border-radius: 3px; font-size: {code_sz}px;
            }}
            pre {{
                background: {C['bg']};
                border: 1px solid {C['border']};
                border-left: 3px solid {C['accent2']};
                border-radius: 6px; padding: 8px 10px;
                font-family: 'Consolas', 'Cascadia Code', 'Courier New', monospace;
                font-size: {code_sz}px; color: {C['text']};
            }}
            ul, ol {{ margin: 3px 0 7px 0; padding-left: 18px; font-size: {sz}px; }}
            li {{ margin-bottom: 3px; font-size: {sz}px; }}
            strong, b {{ color: {C['bright']}; font-weight: 700; }}
            em {{ color: {C['muted']}; font-style: italic; }}
            blockquote {{
                border-left: 3px solid {C['border2']};
                margin: 4px 0 8px 0; padding-left: 10px; color: {C['muted']}; font-size: {sz}px;
            }}
            a {{ color: {C['accent']}; text-decoration: none; }}
            a:hover {{ text-decoration: underline; }}
            hr {{ border: none; border-top: 1px solid {C['border']}; margin: 8px 0; }}
            table {{ border-collapse: collapse; width: 100%; margin: 6px 0; font-size: {sz}px; }}
            th {{ background: {C['surface2']}; color: {C['bright']}; padding: 5px 8px; border: 1px solid {C['border']}; font-size: {sz}px; }}
            td {{ padding: 4px 8px; border: 1px solid {C['border']}; font-size: {sz}px; }}
        """
        if hasattr(self, 'output_browser'):
            self.output_browser.document().setDefaultStyleSheet(answer_css)

    def change_font_size(self, delta: int):
        new_size = max(9, min(24, self.current_font_size + delta))
        if new_size == self.current_font_size:
            return
        actual_delta = new_size - self.current_font_size
        self.current_font_size = new_size
        if hasattr(self, 'font_size_lbl'):
            self.font_size_lbl.setText(f"{self.current_font_size}pt")
        if actual_delta > 0:
            self.output_browser.zoomIn(actual_delta)
        else:
            self.output_browser.zoomOut(-actual_delta)
        self._apply_answer_css()

    def reset_font_size(self):
        delta = 13 - self.current_font_size
        if delta != 0:
            self.change_font_size(delta)

    def toggle_pin(self):
        self.is_pinned = not self.is_pinned
        cfg = load_config()
        cfg["always_on_top"] = self.is_pinned
        self.config = cfg
        save_config(cfg)
        self.pin_btn.setIcon(svg_icon("pin_active" if self.is_pinned else "pin", 12))
        pos, size = self.pos(), self.size()
        flags = QtCore.Qt.WindowType.FramelessWindowHint | QtCore.Qt.WindowType.Tool
        if self.is_pinned:
            flags |= QtCore.Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.resize(size); self.move(pos); self.show()
        enable_stealth(int(self.winId()))
        state = "Pinned on top" if self.is_pinned else "Unpinned"
        self.show_toast(state, icon_key="pin_active" if self.is_pinned else "pin")

    def toggle_visibility(self):
        if hasattr(self, 'floating_icon') and self.floating_icon and self.floating_icon.isVisible():
            self.floating_icon.hide(); self._hidden_from_floating = True
        elif self.isVisible():
            self.hide(); self._hidden_from_floating = False
        else:
            if getattr(self, '_hidden_from_floating', False):
                self._hidden_from_floating = False
                if self.floating_icon:
                    self.floating_icon.show()
                    enable_stealth(int(self.floating_icon.winId()))
            else:
                self.showNormal(); self.activateWindow()
                enable_stealth(int(self.winId()))

    def update_ask_toggle_btn_state(self):
        if not hasattr(self, 'ask_toggle_btn'): return
        ask_on = self.config.get("ask_before_answering", False)
        if ask_on:
            self.ask_toggle_btn.setText("Confirm: ON")
            self.ask_toggle_btn.setStyleSheet(f"QPushButton {{ background: rgba(16, 185, 129, 0.15); color: {C['success']}; border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 3px; padding: 1px 6px; font-size: 9px; font-weight: 700; }}")
        else:
            self.ask_toggle_btn.setText("Instant: ON")
            self.ask_toggle_btn.setStyleSheet(f"QPushButton {{ background: rgba(56, 189, 248, 0.15); color: {C['accent']}; border: 1px solid rgba(56, 189, 248, 0.4); border-radius: 3px; padding: 1px 6px; font-size: 9px; font-weight: 700; }}")

    def toggle_ask_before_answer(self):
        current = self.config.get("ask_before_answering", False)
        self.config["ask_before_answering"] = not current
        save_config(self.config)
        self.update_ask_toggle_btn_state()
        state_str = "Confirm before answer: " + ("ON" if not current else "OFF")
        self.set_status(state_str, state="ready")
        self.show_toast(state_str, icon_key="check")

    def test_invisibility(self):
        dlg = InvisibilityVerifierDialog(self.geometry(), self)
        dlg.exec()

    def open_settings(self):
        dlg = SettingsDialog(self)
        dlg.config_updated.connect(self.on_settings_updated)
        dlg.exec()

    def on_settings_updated(self, cfg: dict):
        self.config = cfg
        if hasattr(self, 'audio_listener') and self.audio_listener:
            self.audio_listener.set_device_name(cfg.get("audio_device", "system_loopback"))
            self.audio_listener.silence_timeout = float(cfg.get("silence_timeout", 1.6))
        self.update_ask_toggle_btn_state()
        self.set_status("Settings saved.", state="ready")
        self.show_toast("Settings saved!", icon_key="check")

    def open_cv_dialog(self):
        dlg = CVDialog(self)
        dlg.cv_updated.connect(self.update_cv_button_state)
        dlg.exec()

    def update_cv_button_state(self):
        if not hasattr(self, 'cv_btn'): return
        if cv_session.has_cv():
            filename = cv_session.filename or "Resume"
            short = (filename[:7] + "…") if len(filename) > 7 else filename
            self.cv_btn.setText(short)
            self.cv_btn.setToolTip(f"CV: {cv_session.filename}")
            self.cv_btn.setStyleSheet(f"QPushButton {{ background: {C['accent2']}; color: {C['bright']}; border: 1px solid {C['accent']}; border-radius: 4px; padding: 3px 7px; font-size: 10px; font-weight: 700; }}")
        else:
            self.cv_btn.setText("📄 CV")
            self.cv_btn.setToolTip("Upload resume for context-aware answers")
            self.cv_btn.setStyleSheet(f"QPushButton {{ background: {C['surface2']}; color: {C['text']}; border: 1px solid {C['border']}; border-radius: 4px; padding: 3px 7px; font-size: 10px; font-weight: 600; }}")

    # ── Audio listener state ──────────────────
    def on_audio_state_changed(self, is_listening: bool, msg: str):
        dev = str(self.config.get("audio_device", "system_loopback")).lower()
        is_loopback = "loopback" in dev or "speaker" in dev or dev == "system_loopback"

        if hasattr(self, 'listen_btn'):
            if is_listening:
                self.listen_btn.setIcon(svg_icon("mic_active", 12))
                self.listen_btn.setText("Stop")
                self.listen_btn.setStyleSheet(f"QPushButton {{ background: rgba(244, 63, 94, 0.2); color: {C['danger']}; border: 1px solid rgba(244, 63, 94, 0.5); border-radius: 4px; padding: 3px 8px; font-size: 10px; font-weight: 700; }}")
                src = "System Audio" if is_loopback else "Microphone"
                self.set_status(f"Listening via {src}… (pause or Alt+L to confirm)", state="working")
                self.show_toast(f"Listening via {src}…", icon_key="mic_active", icon_color=C["danger"])
            else:
                self.listen_btn.setIcon(svg_icon("mic", 12))
                self.listen_btn.setText("Listen")
                self.listen_btn.setStyleSheet(f"QPushButton {{ background: {C['surface2']}; color: {C['text']}; border: 1px solid {C['border']}; border-radius: 4px; padding: 3px 7px; font-size: 10px; font-weight: 600; }}")

        if hasattr(self, 'floating_icon') and self.floating_icon:
            self.floating_icon.set_status_state("listening" if is_listening else "ready")

        if hasattr(self, 'live_speech_card'):
            self.live_speech_card.setVisible(is_listening)
            if is_listening:
                src_label = "Listening (System Audio)" if is_loopback else "Listening (Microphone)"
                self.live_badge.setText(src_label)
                self.live_text_label.setText("Waiting for speech…")

    def on_audio_level_changed(self, level: float):
        if hasattr(self, 'waveform'):
            self.waveform.set_level(level)
        if hasattr(self, 'audio_listener') and self.audio_listener and self.audio_listener.is_listening:
            color = C["danger"] if level > 0.05 else C["warn"]
            self.status_dot.setStyleSheet(f"color: {color}; font-size: 8px;")
        if hasattr(self, 'floating_icon') and self.floating_icon:
            self.floating_icon.set_audio_level(level)

    # ── Floating icon lifecycle ───────────────
    def init_floating_icon(self):
        if self.floating_icon: return
        self.floating_icon = FloatingGhostIcon()
        self.floating_icon.expand_requested.connect(self.restore_from_floating_icon)
        self.floating_icon.snip_requested.connect(self.trigger_snip_from_floating)
        self.floating_icon.clip_requested.connect(self.solve_clipboard_from_floating)
        self.floating_icon.listen_requested.connect(self.trigger_listen_from_floating)
        self.floating_icon.settings_requested.connect(self.open_settings)
        self.floating_icon.close_requested.connect(self.quit_completely)

    def minimize_to_floating_icon(self):
        if not self.floating_icon:
            self.init_floating_icon()
        p = self.pos()
        if p.x() > -10000 and not self.isMinimized():
            self.last_normal_pos = p
            self.last_normal_size = self.size()
        self.hide()
        screen = QtWidgets.QApplication.primaryScreen()
        sg = screen.availableGeometry() if screen else QtCore.QRect(0, 0, 1920, 1080)
        iw = self.floating_icon.width() or 58
        ih = self.floating_icon.height() or 58
        if self._floating_icon_pos is None or self._floating_icon_pos.x() < sg.left() or self._floating_icon_pos.x() > sg.right():
            if self.last_normal_pos and self.last_normal_size:
                tx = self.last_normal_pos.x() + self.last_normal_size.width() - iw - 10
                ty = max(sg.top() + 30, self.last_normal_pos.y() + 10)
            else:
                tx = sg.right() - iw - 20; ty = sg.top() + 80
            self._floating_icon_pos = QtCore.QPoint(tx, ty)
        cx = max(sg.left() + 10, min(self._floating_icon_pos.x(), sg.right() - iw - 10))
        cy = max(sg.top() + 10, min(self._floating_icon_pos.y(), sg.bottom() - ih - 10))
        self._floating_icon_pos = QtCore.QPoint(cx, cy)
        self.floating_icon.move(self._floating_icon_pos)
        self.floating_icon.show()
        self.floating_icon.raise_()
        # NOTE: activateWindow() intentionally removed — would steal OS focus from browser
        enable_stealth(int(self.floating_icon.winId()))
        self.set_status("Minimized to floating bubble.", state="ready")

    def restore_from_floating_icon(self):
        if self.floating_icon:
            pos = self.floating_icon.pos()
            if pos.x() > -10000:
                self._floating_icon_pos = pos
            self.floating_icon.hide()
        self.setWindowState(self.windowState() & ~QtCore.Qt.WindowState.WindowMinimized)
        if self.last_normal_pos and self.last_normal_pos.x() > -10000:
            self.move(self.last_normal_pos)
        if self.last_normal_size:
            self.resize(self.last_normal_size)
        self.showNormal()
        self.raise_()
        # NOTE: activateWindow() intentionally removed — would steal OS focus from browser
        enable_stealth(int(self.winId()))
        self.set_status("Assistant active.", state="ready")

    def toggle_minimize_floating(self):
        if self.floating_icon and self.floating_icon.isVisible():
            self.restore_from_floating_icon()
        else:
            self.minimize_to_floating_icon()

    def trigger_snip_from_floating(self):
        self.restore_from_floating_icon()
        QtCore.QTimer.singleShot(150, self.trigger_snip)

    def solve_clipboard_from_floating(self):
        self.restore_from_floating_icon()
        QtCore.QTimer.singleShot(150, self.solve_clipboard)

    def trigger_listen_from_floating(self):
        self.restore_from_floating_icon()
        QtCore.QTimer.singleShot(150, self.toggle_listen)

    def quit_completely(self):
        """Cleanly and completely closes Ghost AI, terminating all background threads and processes."""
        try:
            if hasattr(self, '_unsynced_elapsed_seconds') and self._unsynced_elapsed_seconds > 0:
                user_id = self.active_user.get("id") if self.active_user else None
                wallet_manager.sync_with_server(user_id=user_id, elapsed_seconds=self._unsynced_elapsed_seconds)
                self._unsynced_elapsed_seconds = 0
            wallet_manager.logout_software_session()
        except Exception:
            pass
        try:
            if self.auto_typer_thread and self.auto_typer_thread.isRunning():
                self.auto_typer_thread.cancel()
        except Exception:
            pass
        try:
            if hasattr(self, 'audio_listener') and self.audio_listener:
                self.audio_listener.stop_listening(emit_audio=False)
        except Exception:
            pass
        try:
            if hasattr(self, 'floating_icon') and self.floating_icon:
                self.floating_icon.close()
        except Exception:
            pass
        try:
            if hasattr(self, 'hotkey_thread') and self.hotkey_thread:
                self.hotkey_thread.stop()
        except Exception:
            pass
        self.close()
        app = QtWidgets.QApplication.instance()
        if app:
            app.quit()
        QtCore.QTimer.singleShot(150, lambda: os._exit(0))

    def closeEvent(self, event):
        try:
            if hasattr(self, '_unsynced_elapsed_seconds') and self._unsynced_elapsed_seconds > 0:
                user_id = self.active_user.get("id") if self.active_user else None
                wallet_manager.sync_with_server(user_id=user_id, elapsed_seconds=self._unsynced_elapsed_seconds)
                self._unsynced_elapsed_seconds = 0
            wallet_manager.logout_software_session()
        except Exception:
            pass
        try:
            if self.auto_typer_thread and self.auto_typer_thread.isRunning():
                self.auto_typer_thread.cancel()
            if hasattr(self, 'audio_listener') and self.audio_listener:
                self.audio_listener.stop_listening(emit_audio=False)
            if hasattr(self, 'floating_icon') and self.floating_icon:
                self.floating_icon.close()
            if hasattr(self, 'hotkey_thread') and self.hotkey_thread:
                self.hotkey_thread.stop()
        except Exception:
            pass
        super().closeEvent(event)
        app = QtWidgets.QApplication.instance()
        if app:
            app.quit()
        QtCore.QTimer.singleShot(150, lambda: os._exit(0))
