"""
cv_manager.py - Candidate CV / Resume Parser and Session Context Manager
Extracts text from PDF, DOCX, TXT, and Markdown files, and maintains in-memory
candidate profile context for the duration of the interview session.
"""

import os
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET


def extract_text_from_file(file_path: str) -> tuple[str, str]:
    """
    Extracts plain text from a resume document (.pdf, .docx, .txt, .md).
    Returns (extracted_text, error_message).
    """
    path = Path(file_path)
    if not path.exists():
        return "", f"File not found: {file_path}"

    ext = path.suffix.lower()

    # 1. PDF extraction using pypdf
    if ext == ".pdf":
        try:
            import pypdf
            reader = pypdf.PdfReader(str(path))
            pages_text = []
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    pages_text.append(text.strip())
            full_text = "\n\n".join(pages_text)
            if not full_text.strip():
                return "", "Could not extract text from PDF (it may contain only scanned images)."
            return full_text.strip(), ""
        except Exception as e:
            return "", f"Error reading PDF: {e}"

    # 2. DOCX extraction using zipfile & XML parser (zero extra dependencies)
    elif ext == ".docx":
        try:
            with zipfile.ZipFile(str(path)) as docx:
                xml_content = docx.read("word/document.xml")
                tree = ET.fromstring(xml_content)
                text_pieces = []
                for node in tree.iter():
                    if node.tag.endswith("t") and node.text:
                        text_pieces.append(node.text)
                    elif node.tag.endswith("p"):
                        text_pieces.append("\n")
                raw_text = "".join(text_pieces)
                # Clean up multiple newlines
                cleaned = "\n".join(line.strip() for line in raw_text.splitlines() if line.strip())
                if not cleaned:
                    return "", "Document appears empty."
                return cleaned, ""
        except Exception as e:
            return "", f"Error reading DOCX file: {e}"

    # 3. Plain text / Markdown / other text formats
    else:
        for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
            try:
                with open(path, "r", encoding=enc) as f:
                    return f.read().strip(), ""
            except UnicodeDecodeError:
                continue
            except Exception as e:
                return "", f"Error reading text file: {e}"
        return "", "Could not decode text file with standard encodings."


class CVSessionManager:
    """Singleton session memory manager for holding and formatting candidate CV context."""

    def __init__(self):
        self.filename: str = ""
        self.raw_text: str = ""
        self.word_count: int = 0
        self.is_enabled: bool = True

    def set_cv(self, filename: str, text: str):
        self.filename = filename
        self.raw_text = text.strip()
        self.word_count = len(self.raw_text.split())
        self.is_enabled = True

    def clear_cv(self):
        self.filename = ""
        self.raw_text = ""
        self.word_count = 0
        self.is_enabled = True

    def has_cv(self) -> bool:
        return bool(self.raw_text and self.is_enabled)

    def get_prompt_context(self) -> str:
        """Formats the candidate CV context into a system prompt injection."""
        if not self.has_cv():
            return ""

        return (
            "=== CANDIDATE RESUME & PROFILE CONTEXT ===\n"
            "The user you are assisting is an active interview candidate with the following resume:\n\n"
            f"{self.raw_text}\n\n"
            "=== CANDIDATE PERSONALIZATION INSTRUCTIONS ===\n"
            "1. When answering behavioral, experiential, or project-based questions (e.g., 'Tell me about yourself', "
            "'What is your experience with X?', 'Describe a challenging project you built', 'Why should we hire you?'), "
            "ALWAYS answer in the first person ('I', 'my team') directly aligning with the real projects, companies, "
            "metrics, and tech stack from this candidate's resume.\n"
            "2. Never contradict this candidate's resume. Highlight the real achievements, metrics, and tools mentioned above.\n"
            "3. For technical / coding questions, use the candidate's preferred languages and design paradigms.\n"
        )


# Global session instance
cv_session = CVSessionManager()
