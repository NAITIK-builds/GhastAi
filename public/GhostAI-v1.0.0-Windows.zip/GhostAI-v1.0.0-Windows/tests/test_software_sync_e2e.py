"""
test_software_sync_e2e.py - Complete End-to-End Verification of Desktop Software
and Website Licensing Server Synchronization.
"""

import sys
import os
import json
import time
from pathlib import Path

# Setup paths
_ROOT = Path(__file__).resolve().parent.parent
_SRC = _ROOT / "src"
for _sub in [_SRC, _SRC / "core", _SRC / "engine", _SRC / "ui"]:
    _sub_str = str(_sub)
    if _sub_str not in sys.path:
        sys.path.insert(0, _sub_str)

import wallet_manager
import urllib.request
import urllib.error


def run_e2e_sync_tests():
    print("\n" + "=" * 60)
    print("[START] END-TO-END SOFTWARE & WEBSITE SYNC VERIFICATION")
    print("=" * 60)

    base = "http://127.0.0.1:5173/api"
    test_id = int(time.time())
    test_name = f"Candidate Sync Test {test_id}"
    test_email = f"sync_test_{test_id}@example.com"
    test_password = "password123"

    inst_1 = "test_pc_device_1"
    wallet_manager.get_software_instance_id = lambda: inst_1

    # 1. Register candidate from desktop software
    print("\n[Step 1] Testing software registration via wallet_manager.register_user()...")
    ok, reg_user, msg = wallet_manager.register_user(test_name, test_email, test_password)
    assert ok is True, f"Registration failed: {msg}"
    assert reg_user is not None, "Expected registered user object"
    assert reg_user.get("remaining_seconds", 0) == 0, "New accounts must start with 0 seconds"
    user_id = reg_user.get("id")
    print(f"  [OK] User registered: {reg_user.get('name')} (ID: {user_id})")
    print(f"  [OK] Initial remaining seconds: {reg_user.get('remaining_seconds')}s (00:00:00)")

    # 2. Verify candidate appears in Admin database with 0 balance
    print("\n[Step 2] Verifying candidate in Admin portal API...")
    req_admin = urllib.request.Request(f"{base}/admin/users")
    with urllib.request.urlopen(req_admin) as res:
        users = json.loads(res.read().decode())
        found = next((u for u in users if u.get("id") == user_id), None)
        assert found is not None, "Registered candidate not found in Admin database"
        assert found.get("remaining_seconds", 0) == 0
        print(f"  [OK] Candidate '{found.get('name')}' confirmed in Admin Portal DB with 00:00:00")

    # 3. Test software login and session registration on same instance
    print("\n[Step 3] Testing software login via wallet_manager.authenticate_user()...")
    login_ok, auth_user, login_msg = wallet_manager.authenticate_user(test_email, test_password)
    assert login_ok is True, f"Login failed: {login_msg}"
    print(f"  [OK] Candidate logged in on {inst_1}: {login_msg}")

    # 4. Anti-multi-session check: duplicate concurrent instance must be blocked
    print("\n[Step 4] Testing anti-multi-session lock (blocking concurrent copy)...")
    payload_conflict = json.dumps({
        "email": test_email,
        "password": test_password,
        "software_instance_id": "test_pc_device_2"
    }).encode("utf-8")
    req_conflict = urllib.request.Request(
        f"{base}/software/login",
        data=payload_conflict,
        headers={"Content-Type": "application/json"}
    )
    try:
        urllib.request.urlopen(req_conflict)
        assert False, "Duplicate session was not blocked!"
    except urllib.error.HTTPError as err:
        assert err.code == 409, f"Expected 409 Conflict, got {err.code}"
        err_body = json.loads(err.read().decode())
        print(f"  [OK] Concurrent session blocked: {err_body.get('error')}")

    # 5. Check can_run_app() when balance is 0
    print("\n[Step 5] Checking runtime gate with 0 balance...")
    can_run, reason, mins, bal = wallet_manager.can_run_app()
    assert can_run is False, "Candidate with 0 balance should not be allowed to run"
    print(f"  [OK] AI solve gate correctly blocked: '{reason}'")

    # 6. Admin adds ₹50 (+20 minutes = 1200 seconds) via website Admin API
    print("\n[Step 6] Admin credits Rs 50 (+20 minutes) via /api/admin/add-time...")
    add_payload = json.dumps({
        "userId": user_id,
        "amountRupees": 50,
        "minutes": 20
    }).encode("utf-8")
    req_add = urllib.request.Request(
        f"{base}/admin/add-time",
        data=add_payload,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req_add) as res:
        add_res = json.loads(res.read().decode())
        assert add_res.get("success") is True
        print(f"  [OK] Admin credit applied: {add_res.get('user', {}).get('remaining_seconds')}s added")

    # 7. Software heartbeat sync receives newly credited time
    print("\n[Step 7] Software heartbeat syncs with server...")
    sync_ok, rem_secs, status = wallet_manager.sync_with_server(user_id=user_id, elapsed_seconds=0)
    assert sync_ok is True
    assert rem_secs >= 1200, f"Expected at least 1200 seconds, got {rem_secs}"
    print(f"  [OK] Software received updated balance: {rem_secs}s ({wallet_manager.format_seconds_hms(rem_secs)})")

    # 8. Gating now allows candidate to run
    print("\n[Step 8] Checking runtime gate after top-up...")
    can_run_after, reason_after, mins_after, bal_after = wallet_manager.can_run_app()
    assert can_run_after is True, "Candidate should be allowed to run after admin top-up"
    print(f"  [OK] AI solve gate unlocked: {mins_after}m available (Rs {bal_after})")

    # 9. Heartbeat deducts elapsed active time (e.g. 15 seconds)
    print("\n[Step 9] Simulating 15 seconds runtime deduction via heartbeat...")
    sync_ok, new_secs, _ = wallet_manager.sync_with_server(user_id=user_id, elapsed_seconds=15)
    assert sync_ok is True
    assert new_secs == rem_secs - 15
    print(f"  [OK] Server deducted 15 seconds: {new_secs}s remaining")

    # 10. Software exit and session clean-up
    print("\n[Step 10] Testing clean software logout via wallet_manager.logout_software_session()...")
    wallet_manager.logout_software_session()
    # Now that session is cleared, the candidate can log in again on device 2
    login_ok2, _, _ = wallet_manager.authenticate_user(test_email, test_password)
    assert login_ok2 is True, "User should be able to log in after session was cleanly released"
    print("  [OK] Previous session released: candidate can log in again immediately")

    # Clean up test user
    try:
        del_payload = json.dumps({"userId": user_id}).encode("utf-8")
        req_del = urllib.request.Request(
            f"{base}/admin/delete-candidate",
            data=del_payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req_del)
        wallet_manager.logout_software_session()
        print(f"  [OK] Cleaned up test user: {test_email}")
    except Exception:
        pass

    print("\n" + "=" * 60)
    print("[SUCCESS] ALL END-TO-END SOFTWARE & WEBSITE SYNC TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    run_e2e_sync_tests()
