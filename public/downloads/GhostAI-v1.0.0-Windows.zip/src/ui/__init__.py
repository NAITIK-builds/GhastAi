"""
UI components: overlay, floating icon, snipper, and dialogs.
"""

from .overlay_ui import GhostOverlay, AutoTyperThread
from .floating_icon import FloatingGhostIcon
from .snipper import ScreenSnipper
from .cv_dialog import CVDialog
from .settings_dialog import SettingsDialog
from .login_dialog import LoginDialog

__all__ = [
    "GhostOverlay",
    "AutoTyperThread",
    "FloatingGhostIcon",
    "ScreenSnipper",
    "CVDialog",
    "SettingsDialog",
    "LoginDialog",
]
