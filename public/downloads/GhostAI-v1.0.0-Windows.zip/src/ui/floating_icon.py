"""
floating_icon.py - Compact Draggable Floating Bubble for Ghost AI Assistant
When minimized, the assistant collapses into this sleek, unobtrusive floating ghost icon.
Supports click-to-expand, smooth dragging, right-click quick actions, and WDA stealth.
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth


class FloatingGhostIcon(QtWidgets.QWidget):
    """A sleek floating circular icon widget that stays on top and can be dragged anywhere."""
    expand_requested = QtCore.pyqtSignal()
    snip_requested = QtCore.pyqtSignal()
    clip_requested = QtCore.pyqtSignal()
    listen_requested = QtCore.pyqtSignal()
    settings_requested = QtCore.pyqtSignal()
    close_requested = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        # Use Tool flag so Windows treats it as a persistent floating palette that stays on top
        # and doesn't get hidden or minimized with subwindow hierarchies
        self.setWindowFlags(
            QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.WindowStaysOnTopHint
            | QtCore.Qt.WindowType.Tool
            # CRITICAL: Never steal OS focus from browser when floating icon appears
            | QtCore.Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        # Show without activating — browser stays foreground throughout
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setFixedSize(58, 58)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.setToolTip("\U0001f47b Ghost AI Assistant\n\u2022 Click to expand\n\u2022 Drag to move anywhere\n\u2022 Right-click for quick actions")

        self.drag_position = None
        self.press_pos = None
        self.drag_started = False
        self.is_hovered = False
        self.status_state = "ready"  # "ready", "listening", "working", "error"
        self.audio_level = 0.0

        # Pulse timer for listening/working animation
        self._pulse_val = 0.0
        self._pulse_dir = 1.0
        self.pulse_timer = QtCore.QTimer(self)
        self.pulse_timer.setInterval(40)
        self.pulse_timer.timeout.connect(self._on_pulse_tick)

    def showEvent(self, event):
        super().showEvent(event)
        # Ensure DWM screen-share exclusion is active for floating icon as well
        enable_stealth(int(self.winId()))

    def set_status_state(self, state: str):
        self.status_state = state
        if state in ("listening", "working"):
            if not self.pulse_timer.isActive():
                self.pulse_timer.start()
        else:
            self.pulse_timer.stop()
            self._pulse_val = 0.0
        self.update()

    def set_audio_level(self, level: float):
        self.audio_level = level
        if self.status_state == "listening":
            self.update()

    def _on_pulse_tick(self):
        self._pulse_val += 0.08 * self._pulse_dir
        if self._pulse_val >= 1.0:
            self._pulse_val = 1.0
            self._pulse_dir = -1.0
        elif self._pulse_val <= 0.0:
            self._pulse_val = 0.0
            self._pulse_dir = 1.0
        self.update()

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)

        rect = QtCore.QRectF(self.rect()).adjusted(3.0, 3.0, -3.0, -3.0)

        # Draw outer glowing ring when listening or working
        if self.status_state == "listening":
            glow_strength = max(self.audio_level * 1.5, self._pulse_val * 0.7)
            glow_color = QtGui.QColor(239, 68, 68, int(100 + glow_strength * 130))
            painter.setPen(QtGui.QPen(glow_color, 2.5 + glow_strength * 3.0))
            painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawEllipse(rect.adjusted(-2.0, -2.0, 2.0, 2.0))
        elif self.status_state == "working":
            glow_color = QtGui.QColor(129, 140, 248, int(120 + self._pulse_val * 110))
            painter.setPen(QtGui.QPen(glow_color, 2.0 + self._pulse_val * 2.0))
            painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawEllipse(rect.adjusted(-2.0, -2.0, 2.0, 2.0))

        # Main circular bubble background gradient
        bg_gradient = QtGui.QLinearGradient(QtCore.QPointF(rect.left(), rect.top()), QtCore.QPointF(rect.right(), rect.bottom()))
        if self.is_hovered:
            bg_gradient.setColorAt(0.0, QtGui.QColor(30, 41, 59, 252))
            bg_gradient.setColorAt(1.0, QtGui.QColor(15, 23, 42, 252))
            border_color = QtGui.QColor(129, 140, 248, 240)
            border_width = 2.0
        else:
            bg_gradient.setColorAt(0.0, QtGui.QColor(20, 28, 46, 245))
            bg_gradient.setColorAt(1.0, QtGui.QColor(10, 15, 26, 250))
            border_color = QtGui.QColor(99, 102, 241, 180)
            border_width = 1.6

        painter.setBrush(bg_gradient)
        painter.setPen(QtGui.QPen(border_color, border_width))
        painter.drawEllipse(rect)

        # Draw Ghost emoji in center
        font = QtGui.QFont("Segoe UI Emoji", 21)
        painter.setFont(font)
        painter.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, "👻")

        # Status indicator dot
        if self.status_state == "listening":
            dot_color = QtGui.QColor(239, 68, 68, 255)  # Glowing Red for listening
        elif self.status_state == "working":
            dot_color = QtGui.QColor(251, 191, 36, 255)  # Amber
        elif self.status_state == "error":
            dot_color = QtGui.QColor(239, 68, 68, 255)  # Red
        else:
            dot_color = QtGui.QColor(52, 211, 153, 255)  # Emerald Green for ready

        dot_rect = QtCore.QRectF(rect.right() - 11.0, rect.bottom() - 11.0, 9.5, 9.5)
        painter.setBrush(dot_color)
        painter.setPen(QtGui.QPen(QtGui.QColor(15, 23, 42), 1.6))
        painter.drawEllipse(dot_rect)

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.pos()
            self.press_pos = event.globalPosition().toPoint()
            self.drag_started = False
            event.accept()
        elif event.button() == QtCore.Qt.MouseButton.RightButton:
            self.show_context_menu(event.globalPosition().toPoint())
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        if event.buttons() & QtCore.Qt.MouseButton.LeftButton and self.drag_position is not None:
            if not self.drag_started:
                move_dist = (event.globalPosition().toPoint() - self.press_pos).manhattanLength()
                if move_dist > 6:
                    self.drag_started = True
            if self.drag_started:
                self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            if not self.drag_started:
                # Clean direct click -> expand to full assistant window
                self.expand_requested.emit()
            self.drag_position = None
            self.drag_started = False
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def show_context_menu(self, global_pos: QtCore.QPoint):
        menu = QtWidgets.QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #0f172a;
                color: #e2e8f0;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 4px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 12px;
            }
            QMenu::item {
                padding: 6px 20px 6px 12px;
                border-radius: 5px;
            }
            QMenu::item:selected {
                background-color: #4f46e5;
                color: #ffffff;
            }
            QMenu::separator {
                height: 1px;
                background: #1e293b;
                margin: 4px 6px;
            }
        """)

        expand_act = menu.addAction("🗖 Expand Ghost Assistant")
        expand_act.triggered.connect(self.expand_requested.emit)

        menu.addSeparator()

        snip_act = menu.addAction("📸 Snip Question (Alt+S)")
        snip_act.triggered.connect(self.snip_requested.emit)

        clip_act = menu.addAction("📋 Solve Clipboard (Alt+C)")
        clip_act.triggered.connect(self.clip_requested.emit)

        listen_act = menu.addAction("🎙️ Listen Question (Alt+L)")
        listen_act.triggered.connect(self.listen_requested.emit)

        settings_act = menu.addAction("⚙️ Settings (Alt+K)")
        settings_act.triggered.connect(self.settings_requested.emit)

        menu.addSeparator()

        close_act = menu.addAction("✕ Close Assistant")
        close_act.triggered.connect(self.close_requested.emit)

        menu.exec(global_pos)
