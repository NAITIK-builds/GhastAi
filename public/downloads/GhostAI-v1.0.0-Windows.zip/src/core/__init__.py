"""
Core stealth and system-level audio/capture modules.
"""

from .stealth_core import (
    enable_stealth,
    WDA_EXCLUDEFROMCAPTURE,
    WDA_NONE,
    install_global_stealth_filter,
    strip_taskbar_presence,
    prevent_activation,
)
from .invisibility_verifier import InvisibilityVerifier
from .audio_listener import AudioListener, get_available_audio_devices

__all__ = [
    "enable_stealth",
    "WDA_EXCLUDEFROMCAPTURE",
    "WDA_NONE",
    "install_global_stealth_filter",
    "strip_taskbar_presence",
    "prevent_activation",
    "InvisibilityVerifier",
    "AudioListener",
    "get_available_audio_devices",
]
