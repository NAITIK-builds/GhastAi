"""
recharge_dialog.py - Ghost AI Runtime Billing & Wallet Recharge Dialog
Rate: ₹2.50 per minute.
App execution is strictly controlled by Admin.
Candidates cannot self-credit; Admin enters amount in Admin Dashboard.
Dialog automatically detects Admin credit in real time and unlocks the app.
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth
import wallet_manager

C = {
    "bg":        "#090b10",
    "surface":   "#0e1422",
    "surface2":  "#151c2e",
    "surface3":  "#1c263c",
    "border":    "#1e293d",
    "border2":   "#2d3c58",
    "muted":     "#64748b",
    "text":      "#cbd5e1",
    "bright":    "#f8fafc",
    "accent":    "#38bdf8",
    "accent2":   "#2563eb",
    "success":   "#10b981",
    "danger":    "#f43f5e",
    "warn":      "#f59e0b",
}


class RechargeDialog(QtWidgets.QDialog):
    wallet_updated = QtCore.pyqtSignal(dict)

    def __init__(self, parent=None, reason_msg=None):
        super().__init__(parent)
        self.setWindowTitle("Ghost AI — Runtime Balance Expired")
        self.setFixedSize(500, 520)
        self.setWindowFlags(QtCore.Qt.WindowType.Dialog | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.reason_msg = reason_msg or "Your authorized runtime minutes have finished."

        # Live poll timer: checks every 1.5s if Admin has credited balance
        self.live_poll_timer = QtCore.QTimer(self)
        self.live_poll_timer.setInterval(1500)
        self.live_poll_timer.timeout.connect(self.check_live_admin_credit)

        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        try:
            enable_stealth(int(self.winId()))
        except Exception:
            pass
        self.refresh_wallet_display()
        self.live_poll_timer.start()

    def hideEvent(self, event):
        super().hideEvent(event)
        self.live_poll_timer.stop()

    def init_ui(self):
        self.setStyleSheet(f"""
            QDialog {{
                background: {C['bg']};
                color: {C['text']};
                font-family: 'Segoe UI', -apple-system, sans-serif;
            }}
            QLabel {{
                color: {C['text']};
            }}
            QPushButton {{
                background: {C['surface2']};
                color: {C['text']};
                border: 1px solid {C['border']};
                border-radius: 6px;
                padding: 8px 14px;
                font-size: 12px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background: {C['surface3']};
                color: {C['bright']};
                border-color: {C['border2']};
            }}
        """)

        vbox = QtWidgets.QVBoxLayout(self)
        vbox.setContentsMargins(22, 22, 22, 22)
        vbox.setSpacing(14)

        # Header Title & Rate Badge
        head_h = QtWidgets.QHBoxLayout()
        title_box = QtWidgets.QVBoxLayout()
        
        title_lbl = QtWidgets.QLabel("Runtime Balance Expired")
        title_lbl.setStyleSheet(f"font-size: 16px; font-weight: 800; color: {C['danger']};")
        title_box.addWidget(title_lbl)

        sub_lbl = QtWidgets.QLabel("The AI assistant has stopped responding because your time finished.")
        sub_lbl.setStyleSheet(f"font-size: 11px; color: {C['muted']};")
        title_box.addWidget(sub_lbl)
        head_h.addLayout(title_box)

        head_h.addStretch()

        rate_badge = QtWidgets.QLabel("Runtime Access\nManaged by Admin")
        rate_badge.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        rate_badge.setStyleSheet(f"""
            background: rgba(56, 189, 248, 0.12);
            color: {C['accent']};
            border: 1px solid rgba(56, 189, 248, 0.3);
            border-radius: 6px;
            font-size: 11px;
            font-weight: 800;
            padding: 4px 10px;
        """)
        head_h.addWidget(rate_badge)
        vbox.addLayout(head_h)

        # Alert Banner
        self.banner = QtWidgets.QFrame()
        self.banner.setStyleSheet(f"""
            background: rgba(244, 63, 94, 0.12);
            border: 1px solid rgba(244, 63, 94, 0.35);
            border-radius: 8px;
            padding: 10px;
        """)
        b_layout = QtWidgets.QVBoxLayout(self.banner)
        b_layout.setContentsMargins(10, 8, 10, 8)
        self.b_lbl = QtWidgets.QLabel(f"⚠️ {self.reason_msg}")
        self.b_lbl.setWordWrap(True)
        self.b_lbl.setStyleSheet(f"color: #fecdd3; font-size: 12px; font-weight: 600;")
        b_layout.addWidget(self.b_lbl)
        vbox.addWidget(self.banner)

        # Current Status Card
        card = QtWidgets.QFrame()
        card.setStyleSheet(f"""
            background: {C['surface']};
            border: 1px solid {C['border']};
            border-radius: 8px;
            padding: 12px;
        """)
        c_grid = QtWidgets.QGridLayout(card)
        c_grid.setContentsMargins(12, 10, 12, 10)
        c_grid.setHorizontalSpacing(16)
        c_grid.setVerticalSpacing(8)

        # User Name
        c_grid.addWidget(QtWidgets.QLabel("Candidate Account:"), 0, 0)
        self.lbl_user = QtWidgets.QLabel("Candidate")
        self.lbl_user.setStyleSheet(f"font-weight: 700; color: {C['bright']};")
        c_grid.addWidget(self.lbl_user, 0, 1)

        # User ID
        c_grid.addWidget(QtWidgets.QLabel("Account ID:"), 1, 0)
        self.lbl_user_id = QtWidgets.QLabel("user_id")
        self.lbl_user_id.setStyleSheet(f"font-weight: 700; color: {C['muted']}; font-family: monospace;")
        c_grid.addWidget(self.lbl_user_id, 1, 1)

        # Minutes Left
        c_grid.addWidget(QtWidgets.QLabel("Minutes Remaining:"), 2, 0)
        self.lbl_minutes = QtWidgets.QLabel("0 Minutes Remaining")
        self.lbl_minutes.setStyleSheet(f"font-weight: 800; color: {C['danger']}; font-size: 14px;")
        c_grid.addWidget(self.lbl_minutes, 2, 1)

        vbox.addWidget(card)

        # Admin Top-up Instructions Card
        inst_card = QtWidgets.QFrame()
        inst_card.setStyleSheet(f"""
            background: {C['surface2']};
            border: 1px solid {C['border2']};
            border-radius: 8px;
            padding: 12px;
        """)
        inst_layout = QtWidgets.QVBoxLayout(inst_card)
        inst_layout.setContentsMargins(12, 10, 12, 10)
        inst_layout.setSpacing(6)

        inst_title = QtWidgets.QLabel("📌 How to Add Minutes & Unlock:")
        inst_title.setStyleSheet(f"font-size: 12px; font-weight: 700; color: {C['bright']};")
        inst_layout.addWidget(inst_title)

        inst_text = QtWidgets.QLabel(
            "1. Contact your Administrator with your Account ID / Email.\n"
            "2. The Admin will credit runtime minutes from the Admin Dashboard.\n"
            "3. This screen will automatically detect your new minutes and unlock immediately!"
        )
        inst_text.setStyleSheet(f"font-size: 11px; color: {C['text']}; line-height: 1.5;")
        inst_layout.addWidget(inst_text)

        vbox.addWidget(inst_card)

        # Live Poller Status Banner
        self.poll_banner = QtWidgets.QFrame()
        self.poll_banner.setStyleSheet(f"""
            background: rgba(16, 185, 129, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.25);
            border-radius: 6px;
            padding: 8px 12px;
        """)
        pb_h = QtWidgets.QHBoxLayout(self.poll_banner)
        pb_h.setContentsMargins(6, 4, 6, 4)
        
        self.poll_dot = QtWidgets.QLabel("●")
        self.poll_dot.setStyleSheet(f"color: {C['accent']}; font-size: 10px;")
        pb_h.addWidget(self.poll_dot)

        self.poll_status_lbl = QtWidgets.QLabel("Listening for live Admin recharge in database...")
        self.poll_status_lbl.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-weight: 600;")
        pb_h.addWidget(self.poll_status_lbl)
        pb_h.addStretch()

        vbox.addWidget(self.poll_banner)

        # Action Buttons
        actions_h = QtWidgets.QHBoxLayout()
        actions_h.setSpacing(10)

        # Refresh Manually Button
        btn_refresh = QtWidgets.QPushButton("🔄 Check Now")
        btn_refresh.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        btn_refresh.clicked.connect(self.check_live_admin_credit)
        actions_h.addWidget(btn_refresh)

        # Close
        btn_close = QtWidgets.QPushButton("Dismiss")
        btn_close.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        btn_close.clicked.connect(self.reject)
        actions_h.addWidget(btn_close)

        vbox.addLayout(actions_h)

    def refresh_wallet_display(self):
        w = wallet_manager.load_wallet()
        self.lbl_user.setText(f"{w.get('name', 'Candidate')} ({w.get('email', '')})")
        self.lbl_user_id.setText(str(w.get('user_id', 'N/A')))
        
        mins = w.get("minutes_remaining", 0)

        if mins > 0:
            self.lbl_minutes.setText(f"{mins} Minutes Remaining")
            self.lbl_minutes.setStyleSheet(f"font-weight: 800; color: {C['success']}; font-size: 14px;")
        else:
            self.lbl_minutes.setText("0 Minutes (Expired — Recharge Required)")
            self.lbl_minutes.setStyleSheet(f"font-weight: 800; color: {C['danger']}; font-size: 14px;")

    def check_live_admin_credit(self):
        """Polls database for real-time admin credit updates."""
        w = wallet_manager.load_wallet()
        mins = w.get("minutes_remaining", 0)
        allowed = w.get("allowed_by_admin", False)

        if mins > 0 and allowed:
            self.poll_dot.setStyleSheet(f"color: {C['success']};")
            self.poll_status_lbl.setText(f"✓ Credited by Admin! {mins} mins added. Unlocking copilot...")
            self.poll_status_lbl.setStyleSheet(f"color: {C['success']}; font-weight: 800;")
            self.refresh_wallet_display()
            self.wallet_updated.emit(w)
            self.live_poll_timer.stop()
            QtCore.QTimer.singleShot(800, self.accept)
        else:
            # Pulsing animation dot
            cur_color = self.poll_dot.styleSheet()
            new_color = C['accent'] if C['muted'] in cur_color else C['muted']
            self.poll_dot.setStyleSheet(f"color: {new_color}; font-size: 10px;")
