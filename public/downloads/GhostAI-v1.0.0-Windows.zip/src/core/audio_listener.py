"""
audio_listener.py - Real-Time Audio Capture & Silence Detection for Ghost AI Assistant
Captures Windows WASAPI system loopback audio (interviewer voice from Zoom/Teams/Meet/Browser)
or microphones, computes live volume levels, detects speech endings, and packages WAV data for AI.

Key design decisions:
- Pre-roll buffer: always record audio before speech threshold is crossed, so the very beginning
  of a sentence is never cut off.
- Lower RMS threshold (0.008) catches quieter meeting voices.
- Reduced silence_timeout default (1.0s) for faster response triggering.
- Skips a second blocking Google STT call if live transcript already exists, cutting ~1-3s delay.
"""

import io
import time
import wave
from collections import deque

import numpy as np
import speech_recognition as sr
from PyQt6 import QtCore, QtMultimedia

# Attempt to initialize COM as STA before soundcard can switch it to MTA
try:
    import ctypes
    ctypes.windll.ole32.OleInitialize(None)
except Exception:
    pass

try:
    import soundcard as sc
    HAVE_SOUNDCARD = True
except Exception:
    sc = None
    HAVE_SOUNDCARD = False


def get_available_audio_devices() -> list[dict]:
    """
    Returns a unified list of available audio input sources:
    1. System Audio Loopback (Interviewer voice through speakers/headphones)
    2. Default Microphone (User's room voice)
    3. Specific output loopback devices
    4. Specific microphone input devices
    """
    devices = [
        {
            "id": "system_loopback",
            "name": "🔊 System Audio (Interviewer Voice / Meeting Loopback) [Recommended]",
            "type": "loopback",
            "is_default": True
        },
        {
            "id": "default_mic",
            "name": "🎤 Default Microphone (My Voice)",
            "type": "mic",
            "is_default": False
        },
    ]

    if HAVE_SOUNDCARD:
        try:
            default_spk = sc.default_speaker()
            for spk in sc.all_speakers():
                is_def = (default_spk and spk.id == default_spk.id)
                tag = " (Default Output)" if is_def else ""
                devices.append({
                    "id": f"loopback:{spk.name}",
                    "name": f"🔊 Output Loopback: {spk.name}{tag}",
                    "type": "loopback",
                    "is_default": is_def
                })
        except Exception as e:
            print(f"[AudioListener] Error listing speakers: {e}")

        try:
            default_mic = sc.default_microphone()
            for mic in sc.all_microphones():
                is_def = (default_mic and mic.id == default_mic.id)
                tag = " (Default Mic)" if is_def else ""
                devices.append({
                    "id": f"mic:{mic.name}",
                    "name": f"🎤 Mic: {mic.name}{tag}",
                    "type": "mic",
                    "is_default": is_def
                })
        except Exception as e:
            print(f"[AudioListener] Error listing microphones: {e}")
    else:
        try:
            qt_inputs = QtMultimedia.QMediaDevices.audioInputs()
            for dev in qt_inputs:
                desc = dev.description()
                devices.append({
                    "id": f"qt:{desc}",
                    "name": f"🎤 {desc}{' (Default)' if dev.isDefault() else ''}",
                    "type": "mic",
                    "is_default": dev.isDefault()
                })
        except Exception:
            pass

    return devices


class LiveTranscribeThread(QtCore.QThread):
    """Background thread — sends accumulated audio to Google Web Speech for live STT preview."""
    transcript_ready = QtCore.pyqtSignal(str, bool)  # (text, is_final)

    def __init__(self, wav_bytes: bytes, is_final: bool = False, parent=None):
        super().__init__(parent)
        self.wav_bytes = wav_bytes
        self.is_final = is_final

    def run(self):
        if not self.wav_bytes:
            return
        try:
            r = sr.Recognizer()
            r.energy_threshold = 200
            r.dynamic_energy_threshold = False
            with sr.AudioFile(io.BytesIO(self.wav_bytes)) as source:
                audio = r.record(source)
            text = r.recognize_google(audio)
            if text:
                self.transcript_ready.emit(text.strip(), self.is_final)
        except sr.UnknownValueError:
            pass
        except Exception:
            pass


class SoundcardCaptureThread(QtCore.QThread):
    """
    Dedicated QThread for real-time audio capture with pre-roll buffering.

    Key improvements over v1:
    - Pre-roll buffer: always keep the last ~0.5s of audio before speech is detected,
      so the first syllable of every utterance is captured.
    - Lower RMS threshold (0.008) catches quieter voices and system audio.
    - Live transcription every 1.2s (was 0.8s) to reduce Google STT network pressure.
    - On speech end, reuses the existing live transcript instead of blocking on a new
      Google STT network call — saves 1-3 seconds per question.
    """
    level_changed = QtCore.pyqtSignal(float)
    live_transcript_updated = QtCore.pyqtSignal(str, bool)
    audio_captured = QtCore.pyqtSignal(bytes, str)
    state_changed = QtCore.pyqtSignal(bool, str)

    # ── Tunable constants ─────────────────────
    SAMPLE_RATE     = 16000
    BLOCK_MS        = 60          # 60ms per block (was 100ms) — finer granularity
    BLOCK_FRAMES    = int(SAMPLE_RATE * BLOCK_MS / 1000)  # 960 frames
    SPEECH_THRESH   = 0.008       # RMS threshold (was 0.015) — catches quieter audio
    PREROLL_SEC     = 0.5         # seconds of audio to keep before speech detected
    TRANSCRIBE_INTERVAL = 1.2     # seconds between live STT calls (reduces network load)
    MAX_DURATION    = 90.0        # safety cutoff

    def __init__(self, target_device_id: str = "system_loopback",
                 silence_timeout: float = 1.0, parent=None):
        super().__init__(parent)
        self.target_device_id = target_device_id
        self.silence_timeout = silence_timeout
        self._running = False
        self._should_emit_audio = True

        # Pre-roll ring buffer: holds last PREROLL_SEC of audio before speech
        preroll_blocks = int(self.PREROLL_SEC * 1000 / self.BLOCK_MS) + 2
        self._preroll: deque = deque(maxlen=preroll_blocks)

        self.audio_frames: list = []
        self.speech_detected = False
        self.last_speech_time = 0.0
        self.start_time = 0.0
        self.current_live_transcript = ""
        self.last_transcribe_time = 0.0
        self.transcribe_thread = None

    def stop_capture(self, emit_audio: bool = True):
        self._should_emit_audio = emit_audio
        self._running = False

    # ── Device resolution ─────────────────────
    def _resolve_recorder_device(self):
        if not HAVE_SOUNDCARD:
            return None
        dev_id = self.target_device_id or "system_loopback"
        try:
            if dev_id == "system_loopback":
                spk = sc.default_speaker()
                if spk:
                    return sc.get_microphone(id=str(spk.id), include_loopback=True)
            elif dev_id == "default_mic":
                return sc.default_microphone()
            elif dev_id.startswith("loopback:"):
                spk_name = dev_id[len("loopback:"):]
                for s in sc.all_speakers():
                    if s.name == spk_name:
                        return sc.get_microphone(id=str(s.id), include_loopback=True)
                spk = sc.default_speaker()
                return sc.get_microphone(id=str(spk.id), include_loopback=True) if spk else None
            elif dev_id.startswith("mic:"):
                mic_name = dev_id[len("mic:"):]
                for m in sc.all_microphones():
                    if m.name == mic_name:
                        return m
                return sc.default_microphone()
            else:
                for s in sc.all_speakers():
                    if s.name == dev_id:
                        return sc.get_microphone(id=str(s.id), include_loopback=True)
                for m in sc.all_microphones():
                    if m.name == dev_id:
                        return m
                spk = sc.default_speaker()
                if spk:
                    return sc.get_microphone(id=str(spk.id), include_loopback=True)
        except Exception as e:
            print(f"[SoundcardCapture] Device resolve error for {dev_id}: {e}")

        # Final fallback
        try:
            spk = sc.default_speaker()
            if spk:
                return sc.get_microphone(id=str(spk.id), include_loopback=True)
        except Exception:
            pass
        return sc.default_microphone() if HAVE_SOUNDCARD else None

    def _on_live_transcript(self, text: str, is_final: bool):
        if text:
            self.current_live_transcript = text
            self.live_transcript_updated.emit(text, is_final)

    def _encode_frames_to_wav(self, frames: list) -> bytes:
        """Convert list of numpy float32 chunks into a 16-bit mono WAV bytes object."""
        if not frames:
            return b""
        try:
            all_data = np.concatenate(frames, axis=0)
            # Mix stereo → mono if needed
            if all_data.ndim > 1:
                mono = all_data.mean(axis=1)
            else:
                mono = all_data.squeeze()

            pcm16 = (mono * 32767.0).clip(-32768, 32767).astype(np.int16)
            buf = io.BytesIO()
            with wave.open(buf, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(self.SAMPLE_RATE)
                wf.writeframes(pcm16.tobytes())
            return buf.getvalue()
        except Exception as e:
            print(f"[SoundcardCapture] WAV encode error: {e}")
            return b""

    def run(self):
        recorder_dev = self._resolve_recorder_device()
        if not recorder_dev:
            self.state_changed.emit(False, "No audio capture device found.")
            return

        dev_label = recorder_dev.name
        is_loopback = (
            "loopback" in str(type(recorder_dev)).lower()
            or "speaker" in dev_label.lower()
        )
        mode_desc = "System Audio (Interviewer)" if is_loopback else "Microphone"
        self.state_changed.emit(True, f"Listening to {mode_desc} ({dev_label})...")

        self.audio_frames.clear()
        self._preroll.clear()
        self.speech_detected = False
        self.current_live_transcript = ""
        self.start_time = time.monotonic()
        self.last_speech_time = self.start_time
        self.last_transcribe_time = 0.0
        self._running = True

        try:
            with recorder_dev.recorder(
                samplerate=self.SAMPLE_RATE,
                channels=1,
                blocksize=self.BLOCK_FRAMES
            ) as rec:
                while self._running:
                    chunk = rec.record(numframes=self.BLOCK_FRAMES)
                    if chunk is None or len(chunk) == 0:
                        continue

                    # ── RMS & level ──────────────────────────
                    rms = float(np.sqrt(np.mean(chunk ** 2)))
                    level = min(1.0, rms * 6.0)
                    self.level_changed.emit(level)

                    now = time.monotonic()
                    is_speech = rms >= self.SPEECH_THRESH

                    # ── Pre-roll: always keep recent audio ───
                    if not self.speech_detected:
                        self._preroll.append(chunk.copy())

                    # ── Speech onset ─────────────────────────
                    if is_speech:
                        if not self.speech_detected:
                            # Flush pre-roll into audio_frames so we don't miss the start
                            self.speech_detected = True
                            self.audio_frames.extend(self._preroll)
                            self._preroll.clear()
                        self.last_speech_time = now

                    # ── Accumulate while talking ─────────────
                    if self.speech_detected:
                        self.audio_frames.append(chunk.copy())

                        # ── Live transcription (non-blocking) ────
                        since_last = now - self.last_transcribe_time
                        if (since_last >= self.TRANSCRIBE_INTERVAL
                                and len(self.audio_frames) > 8):
                            running_ok = (
                                self.transcribe_thread is None
                                or not self.transcribe_thread.isRunning()
                            )
                            if running_ok:
                                self.last_transcribe_time = now
                                snap = self._encode_frames_to_wav(self.audio_frames)
                                if snap:
                                    self.transcribe_thread = LiveTranscribeThread(
                                        snap, is_final=False
                                    )
                                    self.transcribe_thread.transcript_ready.connect(
                                        self._on_live_transcript
                                    )
                                    self.transcribe_thread.start()

                        # ── Silence cutoff ───────────────────────
                        silence = now - self.last_speech_time
                        if silence >= self.silence_timeout and len(self.audio_frames) >= 5:
                            self._running = False
                            break

                    # ── Max duration guard ───────────────────
                    if now - self.start_time > self.MAX_DURATION:
                        self._running = False
                        break

        except Exception as e:
            self.state_changed.emit(False, f"Audio capture error: {e}")
            self.level_changed.emit(0.0)
            return

        self.level_changed.emit(0.0)
        self.state_changed.emit(False, "Stopped listening.")

        # ── Emit audio if we captured meaningful speech ──
        if self._should_emit_audio and len(self.audio_frames) >= 4:
            wav_bytes = self._encode_frames_to_wav(self.audio_frames)
            if wav_bytes:
                # Prefer the live transcript (already available, no extra network call).
                # Only fall back to a new Google STT call if we have no transcript at all.
                final_text = self.current_live_transcript.strip()

                if not final_text:
                    # Last-resort blocking transcription — only fires if live STT failed.
                    try:
                        r = sr.Recognizer()
                        r.energy_threshold = 150
                        r.dynamic_energy_threshold = False
                        with sr.AudioFile(io.BytesIO(wav_bytes)) as source:
                            audio = r.record(source)
                        final_text = r.recognize_google(audio).strip()
                    except Exception:
                        final_text = ""

                if final_text:
                    self.live_transcript_updated.emit(final_text, True)

                self.audio_captured.emit(wav_bytes, final_text)

        self.audio_frames.clear()
        self._preroll.clear()


class AudioListener(QtCore.QObject):
    """
    High-level controller for real-time audio capture.
    Wraps SoundcardCaptureThread and exposes simple start/stop/toggle API.
    """
    audio_captured = QtCore.pyqtSignal(bytes, str)          # (wav_bytes, transcribed_text)
    live_transcript_updated = QtCore.pyqtSignal(str, bool)  # (text, is_final)
    level_changed = QtCore.pyqtSignal(float)                # 0.0 – 1.0
    state_changed = QtCore.pyqtSignal(bool, str)            # (is_listening, message)

    def __init__(self, device_name: str = "system_loopback",
                 silence_timeout: float = 1.0, parent=None):
        super().__init__(parent)
        self.device_name = device_name or "system_loopback"
        self.silence_timeout = float(silence_timeout)
        self.is_listening = False
        self.capture_thread = None

    def set_device_name(self, name: str):
        self.device_name = name or "system_loopback"

    def set_silence_timeout(self, timeout: float):
        self.silence_timeout = float(timeout)

    def start_listening(self) -> bool:
        if self.is_listening:
            return True
        self.capture_thread = SoundcardCaptureThread(
            target_device_id=self.device_name,
            silence_timeout=self.silence_timeout,
            parent=self
        )
        self.capture_thread.level_changed.connect(self.level_changed)
        self.capture_thread.live_transcript_updated.connect(self.live_transcript_updated)
        self.capture_thread.audio_captured.connect(self._on_audio_captured)
        self.capture_thread.state_changed.connect(self._on_thread_state_changed)
        self.is_listening = True
        self.capture_thread.start()
        return True

    def stop_listening(self, emit_audio: bool = True):
        if not self.is_listening:
            return
        self.is_listening = False
        if self.capture_thread:
            self.capture_thread.stop_capture(emit_audio=emit_audio)
            self.capture_thread.wait(2000)
            self.capture_thread = None
        self.level_changed.emit(0.0)
        self.state_changed.emit(False, "Stopped listening.")

    def toggle_listening(self):
        if self.is_listening:
            self.stop_listening(emit_audio=True)
        else:
            self.start_listening()

    def _on_thread_state_changed(self, is_active: bool, msg: str):
        if not is_active and self.is_listening:
            self.is_listening = False
        self.state_changed.emit(is_active, msg)

    def _on_audio_captured(self, wav_bytes: bytes, text: str):
        self.is_listening = False
        self.audio_captured.emit(wav_bytes, text)
