"""
snipper.py - Stealth Screen Snipping Tool
Creates an invisible, screen-wide overlay allowing the user to click and drag to select
any region of the screen (question, code, diagram, formula).
The snipping overlay itself has WDA_EXCLUDEFROMCAPTURE applied so nobody on screen share
can see the snipper crosshair or selection box!
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth


class ScreenSnipper(QtWidgets.QWidget):
    # Emits captured image as PNG bytes when snipping completes
    snip_completed = QtCore.pyqtSignal(bytes)
    snip_cancelled = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.WindowStaysOnTopHint
            | QtCore.Qt.WindowType.Tool
            # CRITICAL: Never steal OS focus from the browser — prevents window.onblur
            | QtCore.Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        # Show without activating: the browser stays the active foreground window
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.CrossCursor))

        self.start_pos = None
        self.current_pos = None
        self.is_snipping = False

    def showEvent(self, event):
        super().showEvent(event)
        # Apply stealth to the snipping overlay as well!
        # This prevents viewers on screen share from seeing the selection box
        enable_stealth(int(self.winId()))

    def start_snip(self):
        """Covers all available screens and activates the snipper WITHOUT stealing browser focus."""
        screens = QtWidgets.QApplication.screens()
        total_rect = QtCore.QRect()
        for screen in screens:
            total_rect = total_rect.united(screen.geometry())

        self.setGeometry(total_rect)
        self.start_pos = None
        self.current_pos = None
        self.is_snipping = False
        self.show()
        self.raise_()
        # NOTE: activateWindow() is intentionally NOT called here.
        # Calling activateWindow() would steal OS foreground focus from the browser,
        # triggering window.onblur and being logged by proctoring systems.
        # The snipper uses WA_ShowWithoutActivating + WindowDoesNotAcceptFocus so
        # the browser remains the foreground window throughout the entire snip.

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.start_pos = event.globalPosition().toPoint()
            self.current_pos = self.start_pos
            self.is_snipping = True
            self.update()

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        if self.is_snipping:
            self.current_pos = event.globalPosition().toPoint()
            self.update()

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton and self.is_snipping:
            self.is_snipping = False
            self.hide()

            if not self.start_pos or not self.current_pos:
                self.snip_cancelled.emit()
                return

            # Compute normalized bounding box
            x1 = min(self.start_pos.x(), self.current_pos.x())
            y1 = min(self.start_pos.y(), self.current_pos.y())
            x2 = max(self.start_pos.x(), self.current_pos.x())
            y2 = max(self.start_pos.y(), self.current_pos.y())

            width = x2 - x1
            height = y2 - y1

            # Ignore accidental tiny clicks (< 15x15 pixels)
            if width < 15 or height < 15:
                self.snip_cancelled.emit()
                return

            try:
                # Capture using Qt's native high-performance screen grab
                primary_screen = QtWidgets.QApplication.primaryScreen()
                for screen in QtWidgets.QApplication.screens():
                    if screen.geometry().contains(QtCore.QPoint(x1, y1)):
                        primary_screen = screen
                        break

                pixmap = primary_screen.grabWindow(0, x1, y1, width, height)

                # Convert to PNG bytes
                qbyte_array = QtCore.QByteArray()
                buffer = QtCore.QBuffer(qbyte_array)
                buffer.open(QtCore.QIODevice.OpenModeFlag.WriteOnly)
                pixmap.save(buffer, "PNG")
                png_bytes = bytes(qbyte_array.data())

                self.snip_completed.emit(png_bytes)
            except Exception as e:
                print(f"[ScreenSnipper] Error capturing region: {e}")
                self.snip_cancelled.emit()

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        if event.key() == QtCore.Qt.Key.Key_Escape:
            self.is_snipping = False
            self.hide()
            self.snip_cancelled.emit()
        else:
            super().keyPressEvent(event)

    def paintEvent(self, event: QtGui.QPaintEvent):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)

        # Semi-transparent dark overlay across the entire screen
        painter.fillRect(self.rect(), QtGui.QColor(10, 10, 15, 80))

        # Instructions banner at top center
        font = QtGui.QFont("Segoe UI", 12, QtGui.QFont.Weight.Bold)
        painter.setFont(font)
        text = "🎯 Drag a box over your question to solve | Press ESC to cancel"
        metrics = painter.fontMetrics()
        text_rect = metrics.boundingRect(text)
        banner_w = text_rect.width() + 40
        banner_h = text_rect.height() + 16
        banner_x = (self.width() - banner_w) // 2
        banner_y = 35

        # Draw banner background
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QColor(20, 20, 30, 220))
        painter.drawRoundedRect(banner_x, banner_y, banner_w, banner_h, 8, 8)

        # Draw banner text
        painter.setPen(QtGui.QColor(240, 240, 255))
        painter.drawText(
            QtCore.QRect(banner_x, banner_y, banner_w, banner_h),
            QtCore.Qt.AlignmentFlag.AlignCenter,
            text,
        )

        if self.is_snipping and self.start_pos and self.current_pos:
            p1 = self.mapFromGlobal(self.start_pos)
            p2 = self.mapFromGlobal(self.current_pos)

            rect = QtCore.QRect(
                min(p1.x(), p2.x()),
                min(p1.y(), p2.y()),
                abs(p1.x() - p2.x()),
                abs(p1.y() - p2.y()),
            )

            # Clear out the selection area so it is clear and visible
            painter.setCompositionMode(QtGui.QPainter.CompositionMode.CompositionMode_Clear)
            painter.fillRect(rect, QtCore.Qt.GlobalColor.transparent)
            painter.setCompositionMode(QtGui.QPainter.CompositionMode.CompositionMode_SourceOver)

            # Draw sleek cyber-blue selection border
            pen = QtGui.QPen(QtGui.QColor(99, 102, 241, 240), 2, QtCore.Qt.PenStyle.SolidLine)
            painter.setPen(pen)
            painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawRect(rect)

            # Draw dimension indicator
            dim_text = f"{rect.width()} x {rect.height()}"
            dim_font = QtGui.QFont("Segoe UI", 9)
            painter.setFont(dim_font)
            painter.setPen(QtGui.QColor(165, 180, 252))
            painter.drawText(rect.right() - 70, rect.bottom() + 18, dim_text)
