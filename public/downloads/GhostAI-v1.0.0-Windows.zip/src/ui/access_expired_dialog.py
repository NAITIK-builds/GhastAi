"""
access_expired_dialog.py - Clean Access Expired Popup for Ghost AI Assistant
Displays clean notification when candidate's runtime balance reaches 00:00:00.
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth

C = {
    "bg":        "#090b10",
    "surface":   "#0e1422",
    "surface2":  "#151c2e",
    "border":    "#1e293d",
    "border2":   "#2d3c58",
    "muted":     "#64748b",
    "text":      "#cbd5e1",
    "bright":    "#f8fafc",
    "danger":    "#f43f5e",
    "danger_bg": "rgba(244, 63, 94, 0.12)",
    "emerald":   "#10b981",
}


class AccessExpiredDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Access Expired")
        self.setFixedSize(380, 260)
        self.setWindowFlags(
            QtCore.Qt.WindowType.Dialog
            | QtCore.Qt.WindowType.WindowStaysOnTopHint
            | QtCore.Qt.WindowType.FramelessWindowHint
        )
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        try:
            enable_stealth(int(self.winId()), allow_focus=True)
        except Exception:
            pass
        self.activateWindow()
        self.raise_()

    def init_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)

        card = QtWidgets.QFrame(self)
        card.setStyleSheet(f"""
            QFrame {{
                background: {C['bg']};
                border: 1px solid {C['border2']};
                border-radius: 14px;
            }}
        """)
        card_layout = QtWidgets.QVBoxLayout(card)
        card_layout.setContentsMargins(24, 24, 24, 24)
        card_layout.setSpacing(14)

        # Danger Warning Icon & Title
        icon_lbl = QtWidgets.QLabel("⚠️")
        icon_lbl.setStyleSheet("font-size: 28px;")
        icon_lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(icon_lbl)

        title_lbl = QtWidgets.QLabel("Access Expired")
        title_lbl.setStyleSheet(f"color: {C['bright']}; font-size: 18px; font-weight: 800;")
        title_lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(title_lbl)

        # Message body per Requirement #10
        msg_lbl = QtWidgets.QLabel(
            "Your available time has ended.\n\n"
            "Please contact the administrator to extend your access."
        )
        msg_lbl.setStyleSheet(f"color: {C['text']}; font-size: 13px; line-height: 1.5;")
        msg_lbl.setWordWrap(True)
        msg_lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(msg_lbl)

        card_layout.addStretch()

        # OK Action Button
        btn_ok = QtWidgets.QPushButton("OK")
        btn_ok.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        btn_ok.setStyleSheet(f"""
            QPushButton {{
                background: {C['surface2']};
                color: {C['bright']};
                border: 1px solid {C['border2']};
                border-radius: 8px;
                padding: 10px 24px;
                font-size: 13px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background: {C['danger_bg']};
                border-color: {C['danger']};
                color: {C['danger']};
            }}
        """)
        btn_ok.clicked.connect(self.accept)
        card_layout.addWidget(btn_ok, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        main_layout.addWidget(card)
