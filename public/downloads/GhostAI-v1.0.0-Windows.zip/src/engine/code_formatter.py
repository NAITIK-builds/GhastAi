"""
code_formatter.py - Rich Code, Response, and Tabbed Views Formatter for Ghost AI Assistant
Transforms raw AI responses into beautiful IDE-styled HTML with syntax highlighting,
modern code cards with macOS terminal dots, quick copy buttons, MCQ verdict banners,
complexity badges, and structured view generation (All, Code Only, Explanation, Complexity).
"""

import re
import html
from typing import Tuple, List, Optional, Dict, Any
import pygments
from pygments.lexers import get_lexer_by_name, guess_lexer, PythonLexer
from pygments.formatters import HtmlFormatter


class ResponseResult(tuple):
    """
    Backwards-compatible tuple subclass that unpacks as:
      full_html, extracted_codes = format_full_response(...)
    while also exposing .meta, .code_only_html, .explanation_only_html, .complexity_only_html,
    and structured attributes.
    """
    def __new__(cls, full_html: str, extracted_codes: List[str], meta: Optional[Dict[str, Any]] = None):
        inst = super().__new__(cls, (full_html, extracted_codes))
        inst.full_html = full_html
        inst.extracted_codes = extracted_codes
        inst.meta = meta or {}
        inst.code_only_html = inst.meta.get("code_only_html", "")
        inst.explanation_only_html = inst.meta.get("explanation_only_html", "")
        inst.complexity_only_html = inst.meta.get("complexity_only_html", "")
        inst.mcq_verdict = inst.meta.get("mcq_verdict", None)
        inst.clean_code_text = inst.meta.get("clean_code_text", "")
        inst.explanation_text = inst.meta.get("explanation_text", "")
        return inst


def clean_latex(text: str) -> str:
    """Cleans LaTeX Big-O and math expressions into clean, readable text."""
    text = re.sub(r'\$\\mathcal\{O\}\((.*?)\)\$', r'O(\1)', text)
    text = re.sub(r'\\mathcal\{O\}\((.*?)\)', r'O(\1)', text)
    text = re.sub(r'\$\\mathcal\{(\w+)\}\$', r'\1', text)
    text = re.sub(r'\\mathcal\{(\w+)\}', r'\1', text)
    text = re.sub(r'\$O\((.*?)\)\$', r'O(\1)', text)
    text = re.sub(r'\\mathcal\{O\}', 'O', text)
    # Inline math symbols like $N$ or $arr[i]$ -> N or arr[i]
    text = re.sub(r'\$([a-zA-Z0-9_+\-*/^()., ]+)\$', r'\1', text)
    text = text.replace('$', '')
    return text


def highlight_code_block(code: str, lang: str = "python") -> str:
    """Syntax highlights code with Pygments using a dark IDE theme."""
    lang = (lang or "").strip().lower()
    if lang in ["py", "python3"]:
        lang = "python"
    elif lang in ["c++", "cpp", "cc"]:
        lang = "cpp"
    elif lang in ["js", "javascript"]:
        lang = "javascript"
    elif lang in ["ts", "typescript"]:
        lang = "typescript"
    elif lang in ["rs", "rust"]:
        lang = "rust"
    elif lang in ["java"]:
        lang = "java"
    elif lang in ["go", "golang"]:
        lang = "go"
    elif lang in ["sql"]:
        lang = "sql"

    try:
        if lang:
            lexer = get_lexer_by_name(lang, stripall=True)
        else:
            lexer = PythonLexer(stripall=True)
    except Exception:
        try:
            lexer = guess_lexer(code)
        except Exception:
            lexer = PythonLexer(stripall=True)

    formatter = HtmlFormatter(
        noclasses=True,
        style="dracula",
        nowrap=True
    )
    return pygments.highlight(code.strip(), lexer, formatter)


def build_code_card(code: str, lang: str, code_idx: int) -> str:
    """Builds a modern macOS/IDE-styled code card with terminal dots and a prominent Copy button."""
    display_lang = lang.upper() if lang else "CODE"
    if display_lang == "PYTHON":
        display_lang = "PYTHON 3"
    elif display_lang == "CPP":
        display_lang = "C++"
    elif display_lang == "JAVA":
        display_lang = "JAVA"
    elif display_lang in ("JS", "JAVASCRIPT"):
        display_lang = "JAVASCRIPT"
    elif display_lang in ("TS", "TYPESCRIPT"):
        display_lang = "TYPESCRIPT"

    highlighted = highlight_code_block(code, lang)
    lines_count = len(code.strip().splitlines())
    is_leetcode = "class Solution" in code or "def " in code or "public class Solution" in code

    leetcode_badge = ""
    copy_label = "📋 Copy Code"
    copy_bg = "#2563eb"
    copy_border = "#3b82f6"

    if is_leetcode:
        leetcode_badge = '<span style="background-color: #064e3b; color: #34d399; border: 1px solid #059669; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; margin-left: 6px; letter-spacing: 0.4px;">⚡ LEETCODE READY</span>'
        copy_label = "📋 Copy LeetCode Code"
        copy_bg = "#059669"
        copy_border = "#10b981"

    return f"""
<div style="background-color: #0b0f19; border: 1px solid #1e293b; border-radius: 9px; margin: 12px 0 16px 0; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #141d33; border-bottom: 1px solid #1e293b;">
    <tr>
      <td style="padding: 9px 14px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; font-weight: bold; color: #94a3b8;">
        <span style="color: #ef4444; font-size: 13px;">●</span>
        <span style="color: #f59e0b; font-size: 13px;">●</span>
        <span style="color: #10b981; font-size: 13px;">●</span>
        &nbsp;&nbsp;
        <span style="background-color: #1e293b; color: #38bdf8; border: 1px solid #334155; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 800; letter-spacing: 0.5px;">{html.escape(display_lang)}</span>
        {leetcode_badge}
        <span style="color: #64748b; font-size: 11px; font-weight: 500; margin-left: 6px;">({lines_count} lines)</span>
      </td>
      <td align="right" style="padding: 9px 14px;">
        <a href="copy-code:{code_idx}" style="color: #ffffff; text-decoration: none; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; font-weight: 700; background-color: {copy_bg}; padding: 5px 14px; border-radius: 5px; border: 1px solid {copy_border}; display: inline-block;">{copy_label}</a>
      </td>
    </tr>
  </table>
  <div style="padding: 14px 16px; font-family: 'Consolas', 'Cascadia Code', 'Courier New', monospace; font-size: 12px; line-height: 1.55; overflow-x: auto; background-color: #0b0f19;">
    <pre style="margin: 0; padding: 0; background: transparent; border: none; font-family: 'Consolas', 'Cascadia Code', monospace; color: #e2e8f0;">{highlighted}</pre>
  </div>
</div>
"""


def detect_mcq_verdict(raw_text: str) -> Optional[Dict[str, str]]:
    """Detects if response starts with or contains an MCQ answer, returning option letter and text."""
    lines = raw_text.splitlines()[:6]
    for line in lines:
        s = line.strip()
        # Pattern: Option B: ... or Option (B) ... or **Option B:** ...
        m = re.search(r'(?:\*\*)?(?:Option|Choice)\s+([A-Da-d])(?:\)|\:|\.|\s*[-–—])\s*(.*?)(?:\*\*)?$', s, re.IGNORECASE)
        if m:
            letter = m.group(1).upper()
            detail = m.group(2).strip().strip("*_")
            return {
                "letter": letter,
                "text": detail,
                "full": f"Option {letter}: {detail}" if detail else f"Option {letter}"
            }
        # Pattern: Correct Answer: B ...
        m2 = re.search(r'(?:\*\*)?(?:Correct\s+Answer|Answer)\s*:\s*([A-Da-d])(?:\:|\.|\s*[-–—])?\s*(.*?)(?:\*\*)?$', s, re.IGNORECASE)
        if m2:
            letter = m2.group(1).upper()
            detail = m2.group(2).strip().strip("*_")
            return {
                "letter": letter,
                "text": detail,
                "full": f"Option {letter}: {detail}" if detail else f"Option {letter}"
            }
    return None


def build_mcq_verdict_banner(mcq_info: Dict[str, str]) -> str:
    """Builds a high-contrast verdict banner for instant multiple-choice answering."""
    letter = html.escape(mcq_info["letter"])
    detail = html.escape(mcq_info["text"])
    full_val = html.escape(mcq_info["full"])

    return f"""
<table width="100%" cellpadding="0" cellspacing="0" style="background-color: #06281e; border: 1px solid #059669; border-left: 5px solid #10b981; border-radius: 8px; margin: 8px 0 14px 0;">
  <tr>
    <td style="padding: 10px 14px;">
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; font-weight: 700; color: #34d399; letter-spacing: 0.5px; text-transform: uppercase;">
        ✓ Correct Option Verdict
      </div>
      <div style="margin-top: 4px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 15px; font-weight: 700; color: #ffffff;">
        <span style="background-color: #059669; color: #ffffff; padding: 2px 9px; border-radius: 4px; margin-right: 8px;">OPTION {letter}</span>
        <span>{detail}</span>
      </div>
    </td>
    <td align="right" style="padding: 10px 14px;">
      <a href="copy-mcq:0" style="color: #ffffff; text-decoration: none; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; font-weight: 600; background-color: #047857; padding: 5px 12px; border-radius: 4px; border: 1px solid #10b981; display: inline-block;">📋 Copy Option</a>
    </td>
  </tr>
</table>
"""


def detect_unfenced_code(raw_text: str, default_lang: str = "cpp") -> Tuple[str, str, str, str]:
    """
    Detects if raw_text contains an unfenced code block (e.g. class Solution:, def ..., #include).
    Returns (before_text, code_text, after_text, detected_lang).
    """
    lines = raw_text.splitlines()
    before_lines = []
    code_lines = []
    after_lines = []
    state = "before"
    detected_lang = default_lang or "cpp"

    code_start_keywords = (
        "class Solution", "def ", "import ", "from ",
        "#include", "using namespace", "public class",
        "int main(", "void ", "vector<", "function ",
        "const ", "let ", "var ", "package ", "func "
    )

    stop_headers = (
        "complexity analysis", "time complexity", "space complexity", "complexity",
        "key rationale", "explanation", "approach", "intuition", "notes",
        "edge cases", "walkthrough", "algorithm", "runtime", "memory"
    )

    lower_raw = raw_text.lower()

    for l in lines:
        s_strip = l.strip()
        s_lower = s_strip.lower()

        if state == "before":
            if any(s_strip.startswith(kw) for kw in code_start_keywords):
                state = "code"
                if "class Solution" in s_strip:
                    if any(tok in raw_text for tok in ("public:", "vector<", "std::", "#include", "->", "};")) or any(tok in lower_raw for tok in ("int ", "void ", "bool ", "string ", "treenode*", "listnode*")):
                        detected_lang = "cpp"
                    elif "public class Solution" in raw_text or "public int" in raw_text:
                        detected_lang = "java"
                    elif "def " in raw_text or s_strip.endswith(":"):
                        detected_lang = "python"
                    else:
                        detected_lang = default_lang
                elif s_strip.startswith("def ") or s_strip.startswith("import ") or s_strip.startswith("from "):
                    detected_lang = "python"
                elif s_strip.startswith("#include") or "using namespace" in s_strip or "vector<" in s_strip:
                    detected_lang = "cpp"
                elif "public class" in s_strip:
                    detected_lang = "java"
                code_lines.append(l)
            else:
                before_lines.append(l)
        elif state == "code":
            s_clean = re.sub(r'^[#*\-\s•]+', '', s_lower).strip()
            if any(s_clean.startswith(h) for h in stop_headers):
                state = "after"
                after_lines.append(l)
            else:
                code_lines.append(l)
        else:
            after_lines.append(l)

    return "\n".join(before_lines).strip(), "\n".join(code_lines).strip(), "\n".join(after_lines).strip(), detected_lang


def format_complexity_section(text: str) -> str:
    """Formats Time and Space complexity lines into a modern styled card."""
    time_pat = re.compile(
        r'(?:^|\n)[ \t]*(?:[-*•]\s*)?(?:\*\*)?(?:Time\s+Complexity|Runtime|Time)(?:\*\*)?\s*(?:[:=\-]|is)\s*([^\n]+)',
        re.IGNORECASE
    )
    space_pat = re.compile(
        r'(?:^|\n)[ \t]*(?:[-*•]\s*)?(?:\*\*)?(?:Space\s+Complexity|Memory|Space)(?:\*\*)?\s*(?:[:=\-]|is)\s*([^\n]+)',
        re.IGNORECASE
    )

    time_m = time_pat.search(text)
    space_m = space_pat.search(text)

    if not (time_m or space_m):
        return ""

    def _extract_parts(val: str, default_color: str, default_border: str, bg_color: str):
        clean_val = re.sub(r'^[*\s:_`\-]+', '', val).strip()
        clean_val = re.sub(r'[*\s`]+$', '', clean_val).strip()

        o_match = re.search(r'O\([^)]+\)', clean_val)
        if o_match:
            big_o = o_match.group(0)
            desc = clean_val.replace(big_o, '').strip(',: -')
            if desc:
                return f"""<span style="background-color: {bg_color}; color: {default_color}; border: 1px solid {default_border}; padding: 2px 8px; border-radius: 4px; font-family: 'Consolas', monospace; font-weight: bold;">{html.escape(big_o)}</span> <span style="color: #94a3b8;">&mdash; {html.escape(desc)}</span>"""
            else:
                return f"""<span style="background-color: {bg_color}; color: {default_color}; border: 1px solid {default_border}; padding: 2px 8px; border-radius: 4px; font-family: 'Consolas', monospace; font-weight: bold;">{html.escape(big_o)}</span>"""
        else:
            return f"""<span style="color: #94a3b8;">{html.escape(clean_val)}</span>"""

    time_content = _extract_parts(time_m.group(1), "#38bdf8", "#0284c7", "#0c4a6e") if time_m else '<span style="color: #94a3b8;">Not specified</span>'
    space_content = _extract_parts(space_m.group(1), "#c084fc", "#7c3aed", "#4c1d95") if space_m else '<span style="color: #94a3b8;">Not specified</span>'

    return f"""
<div style="background-color: #0b1120; border: 1px solid #1e293b; border-left: 4px solid #38bdf8; border-radius: 8px; padding: 12px 16px; margin: 12px 0 14px 0; box-shadow: 0 4px 10px rgba(0,0,0,0.25);">
  <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 10px; font-weight: 800; letter-spacing: 0.6px; color: #38bdf8; text-transform: uppercase; margin-bottom: 8px;">
    ⚡ ALGORITHM COMPLEXITY BREAKDOWN
  </div>
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td style="padding: 3px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 12px; color: #f1f5f9; line-height: 1.6;">
        <span style="color: #38bdf8; font-weight: 700;">⏱️ Time Complexity:</span> &nbsp;
        {time_content}
      </td>
    </tr>
    <tr>
      <td style="padding: 3px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 12px; color: #f1f5f9; line-height: 1.6;">
        <span style="color: #c084fc; font-weight: 700;">💾 Space Complexity:</span> &nbsp;
        {space_content}
      </td>
    </tr>
  </table>
</div>
"""


def format_rationale_section(text: str) -> str:
    """Formats Key Rationale & Edge Cases into clean bullet cards."""
    lines = text.splitlines()
    rationale_lines = []
    in_rationale = False
    header_title = "💡 Key Rationale & Edge Cases"

    for l in lines:
        s_lower = l.strip().lower()
        if "key rationale" in s_lower or "edge cases" in s_lower or "explanation" in s_lower or "approach" in s_lower:
            in_rationale = True
            if "edge case" in s_lower and "rationale" not in s_lower:
                header_title = "⚠️ Key Edge Cases"
            elif "explanation" in s_lower or "approach" in s_lower:
                header_title = "💡 Explanation & Approach"
            continue

        if in_rationale:
            if l.strip():
                rationale_lines.append(l.strip())

    if not rationale_lines:
        return ""

    items_html = []
    for line in rationale_lines:
        cleaned_line = re.sub(r'^[*\-•\d.]+\s*', '', line)
        colon_split = cleaned_line.split(":", 1)
        if len(colon_split) == 2 and len(colon_split[0]) < 50:
            item_title = colon_split[0].strip().strip("*")
            item_body = colon_split[1].strip()
            items_html.append(
                f"""<li><b style="color: #93c5fd;">{html.escape(item_title)}:</b> {format_inline_markdown(item_body)}</li>"""
            )
        else:
            items_html.append(f"""<li>{format_inline_markdown(cleaned_line)}</li>""")

    return f"""
<div style="background-color: #0b1120; border: 1px solid #1e293b; border-left: 4px solid #818cf8; border-radius: 8px; padding: 12px 14px; margin: 12px 0;">
  <div style="color: #c7d2fe; font-weight: bold; font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin-bottom: 8px;">
    {header_title}
  </div>
  <ul style="color: #cbd5e1; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 12px; line-height: 1.6; margin: 0; padding-left: 18px;">
    {"".join(items_html)}
  </ul>
</div>
"""


def format_markdown_snippet(text: str) -> str:
    """Formats general non-code markdown text into clean HTML."""
    lines = text.splitlines()
    formatted_lines = []

    for l in lines:
        s = l.strip()
        if not s:
            continue

        if s.startswith("### "):
            header_title = s[4:].strip()
            lower_h = header_title.lower()
            if any(w in lower_h for w in ("approach", "intuition", "algorithm")):
                icon = "💡"
                border_col = "#6366f1"
            elif any(w in lower_h for w in ("edge case", "corner case", "constraints")):
                icon = "⚠️"
                border_col = "#f59e0b"
            elif any(w in lower_h for w in ("distractor", "option", "why")):
                icon = "🔍"
                border_col = "#38bdf8"
            else:
                icon = "📌"
                border_col = "#818cf8"

            formatted_lines.append(f"""
            <div style="background-color: #0b1120; border: 1px solid #1e293b; border-left: 3px solid {border_col}; border-radius: 6px; padding: 6px 12px; margin: 12px 0 6px 0;">
                <span style="font-size: 12px; margin-right: 4px;">{icon}</span>
                <span style="color: #f8fafc; font-size: 12px; font-weight: 700; letter-spacing: 0.2px;">{html.escape(header_title)}</span>
            </div>
            """)
        elif s.startswith("## "):
            formatted_lines.append(f"""<h2 style="color: #818cf8; font-size: 14px; font-weight: 800; margin: 14px 0 6px 0; border-bottom: 1px solid #1e293b; padding-bottom: 4px;">{html.escape(s[3:])}</h2>""")
        elif s.startswith("# "):
            formatted_lines.append(f"""<h1 style="color: #6366f1; font-size: 16px; font-weight: 800; margin: 16px 0 8px 0; border-bottom: 1px solid #334155; padding-bottom: 4px;">{html.escape(s[2:])}</h1>""")
        elif re.search(r'^(?:\*\*)?(?:Option\s+[A-D]|Choice\s+[A-D]|Answer:)', s, re.IGNORECASE):
            clean_s = re.sub(r'[*_]', '', s)
            formatted_lines.append(
                f"""<div style="background-color: #064e3b; border: 1px solid #059669; color: #6ee7b7; padding: 8px 12px; border-radius: 6px; font-weight: bold; margin: 8px 0;">
                    ✓ {html.escape(clean_s)}
                </div>"""
            )
        elif s.startswith("- ") or s.startswith("* "):
            content = s[2:].strip()
            formatted_lines.append(f"""<div style="margin: 3px 0 3px 12px; color: #cbd5e1; font-size: 12px; line-height: 1.6;"><span style="color: #818cf8; font-size: 11px;">▸</span> {format_inline_markdown(content)}</div>""")
        elif re.match(r'^\d+\.\s+', s):
            num_match = re.match(r'^(\d+)\.\s+(.*)$', s)
            num = num_match.group(1)
            content = num_match.group(2)
            formatted_lines.append(f"""<div style="margin: 3px 0 3px 12px; color: #cbd5e1; font-size: 12px; line-height: 1.6;"><span style="background-color: #1e293b; color: #38bdf8; font-weight: 700; font-size: 10px; padding: 1px 5px; border-radius: 3px; margin-right: 4px;">{num}</span> {format_inline_markdown(content)}</div>""")
        else:
            formatted_lines.append(f"""<p style="margin: 4px 0 8px 0; color: #cbd5e1; font-size: 12px; line-height: 1.6;">{format_inline_markdown(s)}</p>""")

    return "".join(formatted_lines)


def format_inline_markdown(text: str) -> str:
    """Converts inline markdown like **bold** and `code` into HTML tags."""
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'`(.*?)`', r'<code style="font-family: Consolas, monospace; background-color: #1e293b; color: #38bdf8; padding: 1px 4px; border-radius: 3px;">\1</code>', text)
    return text


def _wrap_html_document(body_html: str) -> str:
    """Wraps body HTML in standard styles for QTextBrowser."""
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
body {{
    color: #e2e8f0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    font-size: 12px;
    line-height: 1.6;
    background-color: #090d16;
    margin: 0;
    padding: 2px 4px;
}}
p {{
    margin: 4px 0 8px 0;
}}
b, strong {{
    color: #ffffff;
    font-weight: 700;
}}
code {{
    font-family: 'Consolas', 'Cascadia Code', 'Courier New', monospace;
    background-color: #1e293b;
    color: #38bdf8;
    padding: 2px 5px;
    border-radius: 4px;
}}
ul, ol {{
    margin: 4px 0 8px 0;
    padding-left: 20px;
}}
li {{
    margin-bottom: 3px;
}}
a {{
    color: #38bdf8;
    text-decoration: none;
}}
</style>
</head>
<body>
{body_html}
</body>
</html>
"""


def format_full_response(raw_text: str, default_lang: str = "cpp") -> ResponseResult:
    """
    Main formatting pipeline. Converts AI output into rich HTML with syntax highlighted
    code cards, complexity badges, MCQ verdict cards, and generates separate tabbed views:
    (All, Code Only, Explanation, Complexity).

    Returns ResponseResult which unpacks as (full_html, extracted_codes)
    for backwards compatibility, while providing .meta and tab views.
    """
    if not raw_text or not raw_text.strip():
        return ResponseResult("", [], {})

    cleaned = clean_latex(raw_text)
    extracted_codes: List[str] = []
    extracted_langs: List[str] = []
    html_parts: List[str] = []

    # Check for MCQ verdict
    mcq_info = detect_mcq_verdict(cleaned)
    if mcq_info:
        html_parts.append(build_mcq_verdict_banner(mcq_info))

    # Auto-close unclosed markdown code blocks if LLM output was truncated or left open
    if cleaned.count("```") % 2 != 0:
        last_fence_idx = cleaned.rfind("```")
        tail = cleaned[last_fence_idx+3:]
        stop_match = re.search(r'\n(?=[#*\-]+\s*(?:approach|intuition|complexity|explanation|algorithm|time complexity))', tail, re.IGNORECASE)
        if stop_match:
            split_pos = last_fence_idx + 3 + stop_match.start()
            cleaned = cleaned[:split_pos] + "\n```\n" + cleaned[split_pos:]
        else:
            cleaned = cleaned + "\n```\n"

    # Always scan full cleaned response for Time & Space Complexity
    comp_html = format_complexity_section(cleaned)

    def _clean_complexity_text(t: str) -> str:
        if not t:
            return ""
        # Remove lines containing Time Complexity or Space Complexity so they aren't repeated
        t = re.sub(
            r'(?:^|\n)[ \t]*(?:[-*•]\s*)?(?:\*\*)?(?:Time\s+Complexity|Runtime|Space\s+Complexity|Memory)(?:\*\*)?\s*(?:[:=\-]|is)[^\n]*',
            '',
            t,
            flags=re.IGNORECASE
        ).strip()
        # Remove orphaned ### Complexity Analysis header if complexity was extracted
        if comp_html:
            t = re.sub(r'###\s*Complexity\s*(?:Analysis)?\s*', '', t, flags=re.IGNORECASE).strip()
        return t

    # Pattern for fenced code blocks ```lang ... ```
    fenced_pattern = re.compile(r'```([a-zA-Z0-9_+#-]*)\n?(.*?)```', re.DOTALL)
    matches = list(fenced_pattern.finditer(cleaned))

    code_cards_html: List[str] = []
    explanation_parts: List[str] = []

    if matches:
        last_idx = 0
        for m in matches:
            before_text = _clean_complexity_text(cleaned[last_idx:m.start()].strip())
            if before_text:
                snip_html = format_markdown_snippet(before_text)
                html_parts.append(snip_html)
                explanation_parts.append(snip_html)

            raw_tag = m.group(1).strip().lower()
            lang = raw_tag if raw_tag and raw_tag != "code" else default_lang
            code_content = m.group(2).strip()
            code_idx = len(extracted_codes)
            extracted_codes.append(code_content)
            extracted_langs.append(lang)

            card_html = build_code_card(code_content, lang, code_idx)
            html_parts.append(card_html)
            code_cards_html.append(card_html)

            last_idx = m.end()

        # Place the complexity card immediately after the code block
        if comp_html:
            html_parts.append(comp_html)

        after_text = cleaned[last_idx:].strip()
        after_text_clean = _clean_complexity_text(after_text)
        if after_text_clean:
            snip_html = format_markdown_snippet(after_text_clean)
            html_parts.append(snip_html)
            explanation_parts.append(snip_html)

    else:
        # Check if text contains an unfenced code block
        before_text, code_part, after_text, detected_lang = detect_unfenced_code(cleaned, default_lang=default_lang)
        if code_part:
            before_text_clean = _clean_complexity_text(before_text)
            if before_text_clean:
                snip_html = format_markdown_snippet(before_text_clean)
                html_parts.append(snip_html)
                explanation_parts.append(snip_html)

            code_idx = len(extracted_codes)
            extracted_codes.append(code_part)
            extracted_langs.append(detected_lang)

            card_html = build_code_card(code_part, detected_lang, code_idx)
            html_parts.append(card_html)
            code_cards_html.append(card_html)

            if comp_html:
                html_parts.append(comp_html)

            after_text_clean = _clean_complexity_text(after_text)
            if after_text_clean:
                snip_html = format_markdown_snippet(after_text_clean)
                html_parts.append(snip_html)
                explanation_parts.append(snip_html)
        else:
            # Regular markdown answer
            cleaned_text = _clean_complexity_text(cleaned)
            if comp_html:
                html_parts.append(comp_html)
            if cleaned_text:
                snip_html = format_markdown_snippet(cleaned_text)
                html_parts.append(snip_html)
                explanation_parts.append(snip_html)

    full_html = _wrap_html_document("".join(html_parts))

    # Build dedicated tab views
    # 1. Code-Only View
    if code_cards_html:
        code_only_body = "".join(code_cards_html)
        if comp_html:
            code_only_body += comp_html
    else:
        code_only_body = """
        <div style="padding: 30px 16px; text-align: center; color: #64748b;">
          <div style="font-size: 24px; margin-bottom: 8px;">💻</div>
          <div style="font-size: 13px; font-weight: 600; color: #94a3b8;">No code snippet detected in this response</div>
          <div style="font-size: 11px; margin-top: 4px;">Switch to the <b>All</b> or <b>Explanation</b> tab to view the solution.</div>
        </div>
        """
    code_only_html = _wrap_html_document(code_only_body)

    # 2. Explanation-Only View (Approach & Intuition)
    exp_body = ""
    if mcq_info:
        exp_body += build_mcq_verdict_banner(mcq_info)
    if explanation_parts:
        exp_body += "".join(explanation_parts)
    if comp_html and comp_html not in exp_body:
        exp_body += comp_html

    if not exp_body.strip():
        exp_body = """
        <div style="padding: 30px 16px; text-align: center; color: #64748b;">
          <div style="font-size: 24px; margin-bottom: 8px;">💡</div>
          <div style="font-size: 13px; font-weight: 600; color: #94a3b8;">No separate approach explanation provided</div>
          <div style="font-size: 11px; margin-top: 4px;">Switch to the <b>All</b> tab to view the complete solution.</div>
        </div>
        """
    explanation_only_html = _wrap_html_document(exp_body)

    # 3. Complexity-Only View
    if comp_html:
        comp_body = f"""
        <div style="padding: 16px 8px;">
          <div style="font-size: 14px; font-weight: 700; color: #f8fafc; margin-bottom: 12px;">📊 Algorithm Complexity Breakdown</div>
          {comp_html}
        </div>
        """
        if explanation_parts:
            comp_body += f"""
            <div style="padding: 0 8px;">
              {"".join(explanation_parts)}
            </div>
            """
    else:
        comp_body = """
        <div style="padding: 30px 16px; text-align: center; color: #64748b;">
          <div style="font-size: 24px; margin-bottom: 8px;">⏱️</div>
          <div style="font-size: 13px; font-weight: 600; color: #94a3b8;">No complexity analysis provided</div>
          <div style="font-size: 11px; margin-top: 4px;">Complexity is automatically extracted for coding challenges.</div>
        </div>
        """
    complexity_only_html = _wrap_html_document(comp_body)

    clean_code_text = "\n\n".join(extracted_codes)
    explanation_text = "\n".join([re.sub(r'<[^>]+>', '', p) for p in explanation_parts]).strip()

    meta = {
        "codes": extracted_codes,
        "langs": extracted_langs,
        "mcq_verdict": mcq_info,
        "code_only_html": code_only_html,
        "explanation_only_html": explanation_only_html,
        "complexity_only_html": complexity_only_html,
        "clean_code_text": clean_code_text,
        "explanation_text": explanation_text,
        "raw_text": raw_text,
    }

    return ResponseResult(full_html, extracted_codes, meta)
