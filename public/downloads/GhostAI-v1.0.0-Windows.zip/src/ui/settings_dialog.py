"""
settings_dialog.py - Configuration & API Key Dialog
Allows user to set OpenRouter or Gemini API key, select models, default response mode,
and audio input devices.
Protected with WDA_EXCLUDEFROMCAPTURE so settings are never leaked during screen share.
"""

from PyQt6 import QtCore, QtGui, QtWidgets, QtMultimedia
from stealth_core import enable_stealth
from ai_engine import load_config, save_config
from audio_listener import get_available_audio_devices

OPENROUTER_MODELS = [
    "openrouter/auto",
    "google/gemini-2.0-flash-001",
    "meta-llama/llama-3.3-70b-instruct",
    "anthropic/claude-3.5-sonnet",
    "deepseek/deepseek-r1",
    "qwen/qwen-2.5-vl-72b-instruct",
    "inclusionai/ling-3.0-flash-vl:free",
    "nex-agi/nex-n2.5-pro:free",
    "dots-studio/dots-3-note-preview:free",
]

GEMINI_MODELS = [
    "gemini-3.6-flash",
    "gemini-flash-latest",
    "gemini-3.5-flash-lite",
]

NVIDIA_MODELS = [
    "meta/llama-3.2-11b-vision-instruct",
    "google/gemma-3-12b-it",
    "meta/llama-3.2-90b-vision-instruct",
    "mistralai/mistral-large-2-instruct",
    "mistralai/codestral-22b-instruct-v0.1",
    "deepseek-ai/deepseek-v4-flash-0731",
]


class SettingsDialog(QtWidgets.QDialog):
    config_updated = QtCore.pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ghost AI - Settings")
        self.setFixedSize(540, 600)
        self.setWindowFlags(QtCore.Qt.WindowType.Dialog | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        # Ensure settings window is invisible on screen share too!
        enable_stealth(int(self.winId()))

    def init_ui(self):
        cfg = load_config()
        self.cfg = cfg
        self.provider_keys = cfg.get("provider_keys", {})
        if "nvidia" not in self.provider_keys:
            self.provider_keys["nvidia"] = "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"
        if "openrouter" not in self.provider_keys:
            self.provider_keys["openrouter"] = "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"

        cur_key = cfg.get("api_key", "").strip()
        cur_prov = cfg.get("api_provider", "nvidia").lower()
        if cur_key:
            if cur_key.startswith("nvapi-"):
                self.provider_keys["nvidia"] = cur_key
            elif cur_key.startswith("AIza"):
                self.provider_keys["gemini"] = cur_key
            elif cur_key.startswith("sk-"):
                self.provider_keys["openrouter"] = cur_key
            self.provider_keys[cur_prov] = cur_key

        self.setStyleSheet("""
            QDialog {
                background-color: #11131a;
                color: #e2e8f0;
                font-family: 'Segoe UI', sans-serif;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 13px;
            }
            QLineEdit {
                background-color: #1e2230;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 8px 12px;
                color: #f8fafc;
                font-size: 13px;
                selection-background-color: #6366f1;
            }
            QLineEdit:focus {
                border: 1px solid #6366f1;
            }
            QComboBox {
                background-color: #1e2230;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 6px 12px;
                color: #f8fafc;
                font-size: 13px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox QAbstractItemView {
                background-color: #1e2230;
                color: #f8fafc;
                selection-background-color: #6366f1;
            }
            QCheckBox {
                color: #e2e8f0;
                font-size: 13px;
                font-weight: 500;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 4px;
                border: 1px solid #475569;
                background-color: #1e2230;
            }
            QCheckBox::indicator:hover {
                border-color: #6366f1;
            }
            QCheckBox::indicator:checked {
                background-color: #6366f1;
                border-color: #818cf8;
            }
            QPushButton {
                background-color: #6366f1;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 18px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #4f46e5;
            }
            QPushButton#cancelBtn {
                background-color: #334155;
            }
            QPushButton#cancelBtn:hover {
                background-color: #475569;
            }
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 22, 24, 22)

        # Header Title
        title_label = QtWidgets.QLabel("⚙️ Assistant Configuration")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #f8fafc;")
        layout.addWidget(title_label)

        sub_label = QtWidgets.QLabel("Your API key is stored locally on your machine and never shared.")
        sub_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        layout.addWidget(sub_label)

        layout.addSpacing(4)

        # AI Provider Selection
        prov_label = QtWidgets.QLabel("AI Provider:")
        layout.addWidget(prov_label)

        self.prov_combo = QtWidgets.QComboBox()
        self.prov_combo.addItem("🟢 NVIDIA NIM (Llama 3.2 Vision, Gemma, Mistral)", "nvidia")
        self.prov_combo.addItem("🌐 OpenRouter (400+ Models, Fast & Free Tier)", "openrouter")
        self.prov_combo.addItem("✨ Google Gemini Direct", "gemini")

        if cur_prov == "openrouter":
            self.prov_combo.setCurrentIndex(1)
        elif cur_prov == "gemini":
            self.prov_combo.setCurrentIndex(2)
        else:
            self.prov_combo.setCurrentIndex(0)
        self._current_selected_prov = self.prov_combo.currentData()
        self.prov_combo.currentIndexChanged.connect(self._on_provider_changed)
        layout.addWidget(self.prov_combo)

        # API Key Field
        self.key_label = QtWidgets.QLabel("API Key:")
        layout.addWidget(self.key_label)

        self.key_input = QtWidgets.QLineEdit()
        self.key_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.key_input.setPlaceholderText("API key...")
        self.key_input.setText(self.provider_keys.get(self._current_selected_prov, cur_key))
        layout.addWidget(self.key_input)

        self.help_label = QtWidgets.QLabel("")
        self.help_label.setOpenExternalLinks(True)
        self.help_label.setStyleSheet("font-size: 11px;")
        layout.addWidget(self.help_label)

        layout.addSpacing(4)

        # Model Selection
        self.model_label = QtWidgets.QLabel("AI Model:")
        layout.addWidget(self.model_label)
        self.model_combo = QtWidgets.QComboBox()
        self.model_combo.setEditable(True)  # Allow custom OpenRouter model names
        layout.addWidget(self.model_combo)

        # Populate initial models
        self._populate_models(cfg.get("model_name", "openrouter/auto"))

        # Default Response Mode
        mode_label = QtWidgets.QLabel("Default Response Mode:")
        layout.addWidget(mode_label)
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItem("⚡ Fast / MCQ (Direct answers & choices)", "mcq")
        self.mode_combo.addItem("💻 Code Solution (Clean code + complexity)", "code")
        self.mode_combo.addItem("🎙️ Live Interview (Confident first-person conversational answer)", "interview")
        self.mode_combo.addItem("📖 Detailed Explanation (Step-by-step breakdown)", "detailed")

        current_mode = cfg.get("default_mode", "mcq")
        for i in range(self.mode_combo.count()):
            if self.mode_combo.itemData(i) == current_mode:
                self.mode_combo.setCurrentIndex(i)
                break
        layout.addWidget(self.mode_combo)

        layout.addSpacing(4)

        # Audio Input Device (Meeting Audio Loopback / Microphone)
        audio_label = QtWidgets.QLabel("Audio Input Source:")
        layout.addWidget(audio_label)
        self.audio_combo = QtWidgets.QComboBox()

        devices = get_available_audio_devices()
        current_audio = cfg.get("audio_device", "system_loopback")
        selected_audio_idx = 0

        for i, dev in enumerate(devices):
            self.audio_combo.addItem(dev["name"], dev["id"])
            if current_audio and dev["id"] == current_audio:
                selected_audio_idx = i

        self.audio_combo.setCurrentIndex(selected_audio_idx)
        layout.addWidget(self.audio_combo)

        audio_hint = QtWidgets.QLabel(
            "<span style='color: #64748b; font-size: 11px;'>"
            "🔊 System Audio Loopback captures the interviewer's voice from Zoom, Teams, Meet, or browser calls."
            "</span>"
        )
        audio_hint.setWordWrap(True)
        layout.addWidget(audio_hint)

        layout.addSpacing(6)

        # Ask before answering option
        self.ask_check = QtWidgets.QCheckBox("Ask before answering (Confirm question before AI solves)")
        self.ask_check.setChecked(cfg.get("ask_before_answering", True))
        self.ask_check.setToolTip(
            "When enabled, assistant lets you review and edit the interviewer's transcribed question "
            "with a 'Generate Answer' button before calling AI."
        )
        layout.addWidget(self.ask_check)

        layout.addStretch()

        # Action Buttons
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()

        cancel_btn = QtWidgets.QPushButton("Cancel")
        cancel_btn.setObjectName("cancelBtn")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)

        save_btn = QtWidgets.QPushButton("Save Settings")
        save_btn.clicked.connect(self.save_and_close)
        btn_layout.addWidget(save_btn)

        layout.addLayout(btn_layout)
        self._update_provider_ui()

    def _on_provider_changed(self, idx: int):
        old_prov = getattr(self, '_current_selected_prov', None)
        if old_prov and hasattr(self, 'key_input'):
            typed = self.key_input.text().strip()
            if typed:
                self.provider_keys[old_prov] = typed

        new_prov = self.prov_combo.currentData()
        self._current_selected_prov = new_prov

        if hasattr(self, 'key_input'):
            self.key_input.setText(self.provider_keys.get(new_prov, ""))

        self._update_provider_ui()
        self._populate_models()

    def _update_provider_ui(self):
        prov = self.prov_combo.currentData()
        if prov == "nvidia":
            self.key_label.setText("NVIDIA NIM API Key:")
            self.key_input.setPlaceholderText("nvapi-...")
            self.help_label.setText("<a style='color: #818cf8; text-decoration: none;' href='https://build.nvidia.com/'>Get your free NVIDIA NIM API key at build.nvidia.com</a>")
        elif prov == "openrouter":
            self.key_label.setText("OpenRouter API Key:")
            self.key_input.setPlaceholderText("sk-or-v1-...")
            self.help_label.setText("<a style='color: #818cf8; text-decoration: none;' href='https://openrouter.ai/keys'>Get your free OpenRouter API key at openrouter.ai/keys</a>")
        else:
            self.key_label.setText("Google Gemini API Key:")
            self.key_input.setPlaceholderText("AIzaSy...")
            self.help_label.setText("<a style='color: #818cf8; text-decoration: none;' href='https://aistudio.google.com/'>Get a free Gemini API key from Google AI Studio</a>")

    def _populate_models(self, preferred: str = ""):
        prov = self.prov_combo.currentData()
        self.model_combo.clear()
        if prov == "nvidia":
            models = NVIDIA_MODELS
        elif prov == "openrouter":
            models = OPENROUTER_MODELS
        else:
            models = GEMINI_MODELS
        for m in models:
            self.model_combo.addItem(m)

        target = preferred or (models[0] if models else "")
        idx = self.model_combo.findText(target)
        if idx >= 0:
            self.model_combo.setCurrentIndex(idx)
        else:
            self.model_combo.setEditText(target)

    def save_and_close(self):
        prov = self.prov_combo.currentData()
        key = self.key_input.text().strip()
        if key:
            self.provider_keys[prov] = key

        cfg = load_config()
        cfg["api_provider"] = prov
        cfg["api_key"] = key
        cfg["provider_keys"] = self.provider_keys
        cfg["model_name"] = self.model_combo.currentText().strip()
        cfg["default_mode"] = self.mode_combo.currentData()
        cfg["audio_device"] = self.audio_combo.currentData() or "system_loopback"
        cfg["ask_before_answering"] = self.ask_check.isChecked()
        save_config(cfg)
        self.config_updated.emit(cfg)
        self.accept()
