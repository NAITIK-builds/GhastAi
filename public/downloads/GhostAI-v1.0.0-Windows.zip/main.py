"""
main.py - Entry point for Ghost AI Assistant
Run this script to launch the stealth AI copilot.
"""

import sys
import os
import ctypes
from pathlib import Path

# Bootstrap sys.path to include src and subpackages
_ROOT = Path(__file__).resolve().parent
_SRC = _ROOT / "src"
for _sub in [_SRC, _SRC / "core", _SRC / "engine", _SRC / "ui"]:
    _sub_str = str(_sub)
    if _sub_str not in sys.path:
        sys.path.insert(0, _sub_str)

# Initialize Windows COM in STA (Single-Threaded Apartment) mode before any module sets it to MTA
# This prevents: "QWindowsContext: OleInitialize() failed: COM error 0x80010106: Cannot change thread mode after it is set."
try:
    ctypes.windll.ole32.OleInitialize(None)
except Exception:
    pass

from PyQt6 import QtCore, QtGui, QtWidgets
from overlay_ui import GhostOverlay
from login_dialog import LoginDialog
from stealth_core import install_global_stealth_filter
import wallet_manager


def hide_console_window():
    """Hides the Windows CMD/terminal window so Ghost AI runs in pure stealth mode."""
    if sys.platform == "win32" and "--debug" not in sys.argv and "--show-console" not in sys.argv:
        try:
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 0)  # 0 = SW_HIDE
        except Exception:
            pass


def main():
    hide_console_window()

    # Set high-DPI support for crisp rendering on modern Windows displays
    QtWidgets.QApplication.setHighDpiScaleFactorRoundingPolicy(
        QtCore.Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QtWidgets.QApplication(sys.argv)
    install_global_stealth_filter()
    app.setApplicationName("Ghost AI Assistant")
    app.setOrganizationName("GhostAI")

    # Set default dark palette
    palette = QtGui.QPalette()
    palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(15, 17, 23))
    palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtGui.QColor(241, 245, 249))
    app.setPalette(palette)

    # Prompt Candidate Authentication on Startup
    login_dlg = LoginDialog()
    if login_dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted or not login_dlg.authenticated_user:
        print("[Ghost AI] Authentication cancelled or closed. Exiting.")
        sys.exit(0)

    authenticated_user = login_dlg.authenticated_user
    print(f"[Ghost AI] Logged in successfully as: {authenticated_user.get('name')} ({authenticated_user.get('email')})")
    print(f"[Ghost AI] Balance: ₹{authenticated_user.get('balanceRupees', 0)} | Minutes: {authenticated_user.get('minutesRemaining', 0)}m")

    window = GhostOverlay(active_user=authenticated_user)

    # Position on the right side of the screen by default
    screen_geom = app.primaryScreen().availableGeometry()
    win_w = window.width()
    win_h = window.height()
    pos_x = screen_geom.right() - win_w - 30
    pos_y = screen_geom.top() + 60
    window.move(pos_x, pos_y)

    window.show()

    print("[Ghost AI] Assistant launched successfully.")
    print("[Ghost AI] Press Alt + S to snip questions.")
    print("[Ghost AI] Press Alt + C to solve clipboard.")
    print("[Ghost AI] Press Alt + L to speak questions live (Gemini Live speech-to-text).")
    print("[Ghost AI] Press Alt + M to minimize into floating logo / restore.")
    print("[Ghost AI] Press Alt + H to toggle visibility (Panic button).")
    print("[Ghost AI] Screen share exclusion (WDA_EXCLUDEFROMCAPTURE) is ACTIVE.")

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
