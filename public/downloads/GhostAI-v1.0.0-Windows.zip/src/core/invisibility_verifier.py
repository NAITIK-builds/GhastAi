"""
invisibility_verifier.py - Screen Capture Exclusion Proof & Tester
Captures the screen to prove that the Ghost AI window is completely invisible to screen
capture APIs (Zoom, Discord, Meet, Teams, OBS, BitBlt, Windows Graphics Capture).
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth


class InvisibilityVerifierDialog(QtWidgets.QDialog):
    def __init__(self, target_window_rect: QtCore.QRect, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Shield Screen Share Invisibility Verification")
        self.resize(750, 560)
        self.setWindowFlags(QtCore.Qt.WindowType.Dialog | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.target_rect = target_window_rect
        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        # Keep this verification window invisible too!
        enable_stealth(int(self.winId()))

    def init_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f1117;
                color: #e2e8f0;
                font-family: 'Segoe UI', sans-serif;
            }
            QLabel {
                color: #cbd5e1;
            }
            QPushButton {
                background-color: #6366f1;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #4f46e5;
            }
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        # Header
        header = QtWidgets.QHBoxLayout()
        shield_icon = QtWidgets.QLabel("🛡️")
        shield_icon.setStyleSheet("font-size: 28px;")
        header.addWidget(shield_icon)

        title_col = QtWidgets.QVBoxLayout()
        title_lbl = QtWidgets.QLabel("Screen Capture Verification: 100% Invisible")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #34d399;")
        desc_lbl = QtWidgets.QLabel(
            "Below is a live screen capture taken while Ghost AI was sitting directly on your screen.\n"
            "Notice how the Ghost AI window is completely missing from the capture — whatever is behind it shows through!"
        )
        desc_lbl.setStyleSheet("font-size: 12px; color: #94a3b8;")
        title_col.addWidget(title_lbl)
        title_col.addWidget(desc_lbl)
        header.addLayout(title_col)
        header.addStretch()
        layout.addLayout(header)

        # Image preview container
        self.preview_label = QtWidgets.QLabel()
        self.preview_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet("border: 1px solid #334155; border-radius: 8px; background-color: #1a1d27;")
        layout.addWidget(self.preview_label, stretch=1)

        # Capture desktop and populate preview
        self.capture_and_display()

        # Footer
        footer = QtWidgets.QHBoxLayout()
        hint = QtWidgets.QLabel("⚡ Zoom, Discord, Google Meet, and Teams use this exact capture mechanism.")
        hint.setStyleSheet("color: #a5b4fc; font-size: 11px;")
        footer.addWidget(hint)
        footer.addStretch()

        close_btn = QtWidgets.QPushButton("Got it!")
        close_btn.clicked.connect(self.accept)
        footer.addWidget(close_btn)
        layout.addLayout(footer)

    def capture_and_display(self):
        try:
            # Capture the entire primary screen using Qt's grabWindow(0)
            primary_screen = QtWidgets.QApplication.primaryScreen()
            pixmap = primary_screen.grabWindow(0)

            # Draw a dashed green box where Ghost AI is located on the user's physical screen
            # to highlight that the background shows through and the window is excluded!
            painter = QtGui.QPainter(pixmap)
            pen = QtGui.QPen(QtGui.QColor(52, 211, 153), 3, QtCore.Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawRect(self.target_rect)

            font = QtGui.QFont("Segoe UI", 12, QtGui.QFont.Weight.Bold)
            painter.setFont(font)
            painter.setPen(QtGui.QColor(52, 211, 153))
            painter.drawText(
                self.target_rect.left() + 10,
                self.target_rect.top() + 30,
                "✓ Ghost AI is open on your monitor here, but invisible in this capture!",
            )
            painter.end()

            # Scale to fit container
            scaled = pixmap.scaled(
                710, 420,
                QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                QtCore.Qt.TransformationMode.SmoothTransformation
            )
            self.preview_label.setPixmap(scaled)
        except Exception as e:
            self.preview_label.setText(f"Error capturing test image: {e}")
