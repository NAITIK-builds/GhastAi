"""
Ghost AI Assistant - Source Package
Stealth desktop AI assistant for Windows.
"""

import sys
from pathlib import Path

# Ensure src and its subpackages are readily available on sys.path
_SRC_DIR = Path(__file__).resolve().parent
_SUBDIRS = [
    _SRC_DIR,
    _SRC_DIR / "core",
    _SRC_DIR / "engine",
    _SRC_DIR / "ui",
]

for _p in _SUBDIRS:
    _p_str = str(_p)
    if _p_str not in sys.path:
        sys.path.insert(0, _p_str)
