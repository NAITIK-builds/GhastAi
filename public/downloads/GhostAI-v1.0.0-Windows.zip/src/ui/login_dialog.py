"""
login_dialog.py - Ghost AI Assistant — Stealth Authentication & Candidate Access Gate
Prompts candidate for email & password on startup.
Screen-share invisible (WDA_EXCLUDEFROMCAPTURE).
Checks authorized runtime balance in users database.
"""

from PyQt6 import QtCore, QtGui, QtWidgets
from stealth_core import enable_stealth
import wallet_manager

C = {
    "bg":        "#090b10",
    "surface":   "#0e1422",
    "surface2":  "#151c2e",
    "surface3":  "#1c263c",
    "border":    "#1e293d",
    "border2":   "#2d3c58",
    "muted":     "#64748b",
    "text":      "#cbd5e1",
    "bright":    "#f8fafc",
    "accent":    "#38bdf8",
    "accent2":   "#2563eb",
    "emerald":   "#10b981",
    "emerald_bg":"rgba(16, 185, 129, 0.12)",
    "danger":    "#f43f5e",
    "danger_bg": "rgba(244, 63, 94, 0.12)",
    "warn":      "#f59e0b",
}


class LoginDialog(QtWidgets.QDialog):
    user_authenticated = QtCore.pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._allow_keyboard_focus = True
        self.setWindowTitle("Ghost AI — Candidate Authentication")
        self.setFixedSize(460, 520)
        self.setWindowFlags(
            QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.Dialog
            | QtCore.Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.authenticated_user = None
        self.is_register_mode = False
        self._drag_pos = None

        self.init_ui()

    def showEvent(self, event):
        super().showEvent(event)
        try:
            enable_stealth(int(self.winId()), allow_focus=True)
        except Exception:
            pass
        self.activateWindow()
        self.raise_()
        QtCore.QTimer.singleShot(80, self._set_initial_focus)

    def _set_initial_focus(self):
        self.activateWindow()
        self.raise_()
        if hasattr(self, 'txt_email'):
            self.txt_email.setFocus()

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        self._drag_pos = None

    def init_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Card container with obsidian glass style
        self.card = QtWidgets.QFrame(self)
        self.card.setStyleSheet(f"""
            QFrame {{
                background: {C['bg']};
                border: 1px solid {C['border2']};
                border-radius: 14px;
            }}
        """)
        card_layout = QtWidgets.QVBoxLayout(self.card)
        card_layout.setContentsMargins(26, 24, 26, 24)
        card_layout.setSpacing(14)

        # Header with Logo & Close Button
        header_h = QtWidgets.QHBoxLayout()
        header_h.setSpacing(10)

        logo_box = QtWidgets.QHBoxLayout()
        logo_icon = QtWidgets.QLabel("●")
        logo_icon.setStyleSheet(f"color: {C['emerald']}; font-size: 14px;")
        logo_box.addWidget(logo_icon)

        title_lbl = QtWidgets.QLabel("GHOST<span style='color:#10b981;'>AI</span>")
        title_lbl.setStyleSheet(f"font-size: 16px; font-weight: 900; color: {C['bright']}; letter-spacing: 0.05em;")
        logo_box.addWidget(title_lbl)

        pill_lbl = QtWidgets.QLabel("STEALTH GATE")
        pill_lbl.setStyleSheet(f"""
            background: {C['emerald_bg']};
            color: {C['emerald']};
            border: 1px solid rgba(16, 185, 129, 0.35);
            border-radius: 4px;
            padding: 2px 6px;
            font-size: 9px;
            font-weight: 800;
            font-family: monospace;
        """)
        logo_box.addWidget(pill_lbl)
        header_h.addLayout(logo_box)
        header_h.addStretch()

        close_btn = QtWidgets.QPushButton("✕")
        close_btn.setFixedSize(24, 24)
        close_btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                border: none;
                color: {C['muted']};
                font-size: 13px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                color: {C['danger']};
                background: {C['danger_bg']};
                border-radius: 4px;
            }}
        """)
        close_btn.clicked.connect(self.reject)
        header_h.addWidget(close_btn)
        card_layout.addLayout(header_h)

        # Eyebrow / Subtitle
        sub_lbl = QtWidgets.QLabel("Sign in with your candidate account to launch the copilot.")
        sub_lbl.setStyleSheet(f"color: {C['muted']}; font-size: 12px;")
        sub_lbl.setWordWrap(True)
        card_layout.addWidget(sub_lbl)

        # Rate Banner
        rate_banner = QtWidgets.QFrame()
        rate_banner.setStyleSheet(f"""
            background: rgba(56, 189, 248, 0.08);
            border: 1px solid rgba(56, 189, 248, 0.25);
            border-radius: 8px;
            padding: 8px 12px;
        """)
        rb_layout = QtWidgets.QHBoxLayout(rate_banner)
        rb_layout.setContentsMargins(6, 4, 6, 4)
        rb_text = QtWidgets.QLabel("⏱️ Rate: ₹2.50 / Minute • Admin Controlled Access")
        rb_text.setStyleSheet(f"color: {C['accent']}; font-size: 11px; font-weight: 700;")
        rb_layout.addWidget(rb_text)
        card_layout.addWidget(rate_banner)

        # Feedback / Alert message banner
        self.msg_banner = QtWidgets.QFrame()
        self.msg_banner.setVisible(False)
        mb_layout = QtWidgets.QVBoxLayout(self.msg_banner)
        mb_layout.setContentsMargins(8, 6, 8, 6)
        self.msg_lbl = QtWidgets.QLabel("")
        self.msg_lbl.setWordWrap(True)
        mb_layout.addWidget(self.msg_lbl)
        card_layout.addWidget(self.msg_banner)

        # Input Form Container
        self.form_container = QtWidgets.QVBoxLayout()
        self.form_container.setSpacing(10)

        # Name Field (visible only in Register mode)
        self.name_group = QtWidgets.QWidget()
        ng_layout = QtWidgets.QVBoxLayout(self.name_group)
        ng_layout.setContentsMargins(0, 0, 0, 0)
        ng_layout.setSpacing(4)
        lbl_name = QtWidgets.QLabel("Full Name")
        lbl_name.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-weight: 600;")
        ng_layout.addWidget(lbl_name)
        self.txt_name = QtWidgets.QLineEdit()
        self.txt_name.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.txt_name.setPlaceholderText("e.g. Rahul Sharma")
        self.txt_name.setStyleSheet(self._input_style())
        ng_layout.addWidget(self.txt_name)
        self.name_group.setVisible(False)
        self.form_container.addWidget(self.name_group)

        # Email Field
        lbl_email = QtWidgets.QLabel("Email Address")
        lbl_email.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-weight: 600;")
        self.form_container.addWidget(lbl_email)
        self.txt_email = QtWidgets.QLineEdit()
        self.txt_email.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.txt_email.setPlaceholderText("candidate@example.com")
        self.txt_email.setStyleSheet(self._input_style())
        # Pre-fill active session email if available
        last_session = wallet_manager.get_active_session()
        if last_session and last_session.get("email"):
            self.txt_email.setText(last_session.get("email"))
        self.form_container.addWidget(self.txt_email)

        # Password Field
        lbl_pw = QtWidgets.QLabel("Password")
        lbl_pw.setStyleSheet(f"color: {C['text']}; font-size: 11px; font-weight: 600;")
        self.form_container.addWidget(lbl_pw)
        self.txt_password = QtWidgets.QLineEdit()
        self.txt_password.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.txt_password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.txt_password.setPlaceholderText("Enter your password")
        self.txt_password.setStyleSheet(self._input_style())
        self.txt_password.returnPressed.connect(self.handle_submit)
        self.form_container.addWidget(self.txt_password)

        card_layout.addLayout(self.form_container)

        # Submit Action Button
        self.btn_submit = QtWidgets.QPushButton("Sign In & Launch Copilot →")
        self.btn_submit.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.btn_submit.setStyleSheet(f"""
            QPushButton {{
                background: {C['emerald']};
                color: #ffffff;
                border: none;
                border-radius: 8px;
                padding: 10px;
                font-size: 13px;
                font-weight: 800;
            }}
            QPushButton:hover {{
                background: #059669;
            }}
            QPushButton:pressed {{
                background: #047857;
            }}
        """)
        self.btn_submit.clicked.connect(self.handle_submit)
        card_layout.addWidget(self.btn_submit)

        # Toggle Register / Login mode
        self.btn_toggle_mode = QtWidgets.QPushButton("Need an account? Register as New Candidate")
        self.btn_toggle_mode.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.btn_toggle_mode.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                border: none;
                color: {C['accent']};
                font-size: 11px;
                font-weight: 600;
                padding: 4px;
            }}
            QPushButton:hover {{
                color: #7dd3fc;
                text-decoration: underline;
            }}
        """)
        self.btn_toggle_mode.clicked.connect(self.toggle_mode)
        card_layout.addWidget(self.btn_toggle_mode)

        card_layout.addStretch()

        # Footer Notice
        footer_lbl = QtWidgets.QLabel("🔒 100% Screen-Share Invisible • DWM Exclusion Active")
        footer_lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        footer_lbl.setStyleSheet(f"color: {C['muted']}; font-size: 10px;")
        card_layout.addWidget(footer_lbl)

        main_layout.addWidget(self.card)

    def _input_style(self):
        return f"""
            QLineEdit {{
                background: {C['surface2']};
                color: {C['bright']};
                border: 1px solid {C['border']};
                border-radius: 7px;
                padding: 8px 12px;
                font-size: 13px;
            }}
            QLineEdit:focus {{
                border: 1px solid {C['emerald']};
                background: {C['surface3']};
            }}
        """

    def show_alert(self, text: str, is_error: bool = True):
        bg = C['danger_bg'] if is_error else C['emerald_bg']
        color = C['danger'] if is_error else C['emerald']
        self.msg_banner.setStyleSheet(f"""
            background: {bg};
            border: 1px solid {color};
            border-radius: 6px;
            padding: 6px 10px;
        """)
        self.msg_lbl.setStyleSheet(f"color: {color}; font-size: 11px; font-weight: 700;")
        self.msg_lbl.setText(f"{'⚠️' if is_error else '✓'} {text}")
        self.msg_banner.setVisible(True)

    def toggle_mode(self):
        self.is_register_mode = not self.is_register_mode
        self.msg_banner.setVisible(False)
        if self.is_register_mode:
            self.name_group.setVisible(True)
            self.btn_submit.setText("Register & Get Welcome Trial →")
            self.btn_toggle_mode.setText("Already have an account? Sign In")
        else:
            self.name_group.setVisible(False)
            self.btn_submit.setText("Sign In & Launch Copilot →")
            self.btn_toggle_mode.setText("Need an account? Register as New Candidate")

    def handle_submit(self):
        email = self.txt_email.text().strip()
        password = self.txt_password.text().strip()

        if self.is_register_mode:
            name = self.txt_name.text().strip()
            if not name:
                self.show_alert("Please enter your full name.")
                return
            success, user, msg = wallet_manager.register_user(name, email, password)
            if not success:
                self.show_alert(msg)
                return
            self.show_alert(msg, is_error=False)
            self.authenticated_user = user
            self.user_authenticated.emit(user)
            QtCore.QTimer.singleShot(600, self.accept)
        else:
            success, user, msg = wallet_manager.authenticate_user(email, password)
            if not success:
                self.show_alert(msg)
                return
            self.authenticated_user = user
            self.user_authenticated.emit(user)
            self.accept()
