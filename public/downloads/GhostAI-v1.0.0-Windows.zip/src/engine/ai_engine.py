"""
ai_engine.py - Multimodal AI Service (OpenRouter & Gemini Support)
Handles text, code, audio questions, and screenshot question solving with
real-time streaming responses and specialized prompts for fast MCQs,
coding interviews, and detailed explanations.
"""

import json
import os
import io
import base64
from pathlib import Path
from PyQt6 import QtCore
import openai
import google.generativeai as genai
from PIL import Image

CONFIG_PATH = Path(__file__).parent / "config.json"

DEFAULT_SYSTEM_PROMPTS = {
    "mcq": (
        "You are an elite interview and exam assistant. Analyze the question immediately.\n"
        "- If it is a Multiple-Choice Question (MCQ): State the CORRECT OPTION (e.g. '**Option B: ...**') "
        "as the very first line. Then provide a crisp 1-2 sentence reason.\n"
        "- If it is a factual or concept question: Provide the direct, punchy answer in 2-3 sentences.\n"
        "- Be hyper-accurate, concise, and do not include conversational fluff."
    ),
    "code": (
        "You are an elite coding interview and competitive programming copilot.\n"
        "- Always output the optimal, clean, bug-free code solution first, enclosed in a markdown code block.\n"
        "- Under the code, provide Time Complexity: O(...) and Space Complexity: O(...).\n"
        "- Key Rationale & Edge Cases: 2-3 concise bullet points.\n"
    ),
    "detailed": (
        "You are an expert technical tutor.\n"
        "- Provide a thorough, step-by-step breakdown of the solution.\n"
        "- Include theoretical background, proofs/reasoning where relevant, and clear takeaways."
    ),
    "interview": (
        "You are an expert candidate in a high-stakes technical or behavioral job interview.\n"
        "- Respond in a confident, articulate, first-person interview voice ('In my experience...', 'The way I approach this is...').\n"
        "- Structure your answer cleanly for spoken delivery:\n"
        "  1. Direct High-Level Summary / Answer first (1-2 sentences).\n"
        "  2. Core Technical Concepts, Trade-offs, or Approach (crisp bullet points).\n"
        "  3. Practical Real-World Example or Architecture Context.\n"
        "- Keep it punchy, professional, and ready to speak aloud without sounding robotic or verbose."
    ),
}

def get_code_prompt(language: str = "python") -> str:
    lang = (language or "python").strip().lower()
    lang_info = {
        "python": (
            "Python 3",
            "class Solution:\n    def methodName(self, ...):\n        # Your solution code here",
            "python"
        ),
        "cpp": (
            "C++ (C++17 / C++20)",
            "class Solution {\npublic:\n    ReturnType methodName(...) {\n        // Your solution code here\n    }\n};",
            "cpp"
        ),
        "java": (
            "Java (Java 17 / OpenJDK)",
            "class Solution {\n    public ReturnType methodName(...) {\n        // Your solution code here\n    }\n}",
            "java"
        ),
        "javascript": (
            "JavaScript (ES6+)",
            "/**\n * @param ...\n * @return ...\n */\nvar methodName = function(...) {\n    // Your solution code here\n};",
            "javascript"
        ),
        "typescript": (
            "TypeScript",
            "function methodName(...): ReturnType {\n    // Your solution code here\n};",
            "typescript"
        ),
        "c": (
            "C",
            "ReturnType methodName(...) {\n    // Your solution code here\n}",
            "c"
        ),
        "csharp": (
            "C#",
            "public class Solution {\n    public ReturnType MethodName(...) {\n        // Your solution code here\n    }\n}",
            "csharp"
        ),
    }.get(lang, ("Python 3", "class Solution:\n    def methodName(self, ...):", "python"))

    display_name, template_example, code_tag = lang_info

    return f"""You are an elite competitive programmer and FAANG coding interview copilot specializing in LeetCode, HackerRank, and CodeSignal.
MANDATORY TARGET PROGRAMMING LANGUAGE: You MUST write the code strictly in {display_name}. Do NOT output any other programming language.

CRITICAL LEETCODE PRE-MADE FUNCTION RULES:
1. INSPECT THE CODE EDITOR / TEXT BOX IN THE SCREENSHOT:
   - If an image or text includes a code editor / text box (e.g. on LeetCode), carefully read what is already inside that text box:
     * The exact class name (e.g. `class Solution`)
     * The exact method/function signature (e.g. `def reverseDegree(self, s: str) -> int:` or `class Solution`)
     * Parameter types and return types
     * Any partial lines of code already typed in that text box.
   - AUTOMATICALLY DETECT HOW MUCH CODE IS REMAINING TO BE WRITTEN.
   - YOU MUST WRITE THE COMPLETE IMPLEMENTATION OF ALL REMAINING CODE!
   - NEVER JUST OUTPUT THE EMPTY STARTER SIGNATURE, STUB, OR 'pass'! You MUST implement the entire working algorithmic solution inside the method body so that clicking Submit passes 100% of test cases.
2. LEETCODE RUNNABLE STRUCTURE: The user will paste your code DIRECTLY into LeetCode. You MUST format the code inside the exact LeetCode class/function signature expected for this problem:
   Structure to match:
{template_example}
   - Deduce the exact method name and parameter types from the question and text box.
   - The user must be able to copy-paste your code directly into LeetCode and click 'Run' or 'Submit' without modifying anything!
3. NO STANDALONE CODE: DO NOT write `main()`, `if __name__ == '__main__':`, `console.log`, or sample test harness executions unless the question explicitly requires standard input/output (e.g. Codeforces).
4. IMPORTS & HEADERS:
   - For C++: Include `#include <vector>`, `<string>`, `<unordered_map>`, `<unordered_set>`, `<algorithm>`, `<queue>`, `<stack>`, `<climits>`, and `using namespace std;` at the top if needed.
   - For Java: Include necessary `import java.util.*;` at top if needed.
   - For Python: Assume standard LeetCode imports (List, Dict, Optional, Tuple, heapq, collections).
5. MANDATORY SECTIONS TO GENERATE - YOU MUST ALWAYS GENERATE ALL THREE:
   - SECTION 1: Full working runnable code inside a ```{code_tag} code block FIRST.
   - SECTION 2: Approach & Intuition
     ### Approach & Intuition
     Provide a clear step-by-step walkthrough explaining the core algorithmic strategy (e.g. hash map, two pointers, sliding window, DP), why it works, and how edge cases are handled.
   - SECTION 3: Complexity Analysis
     ### Complexity Analysis
     Time Complexity: O(...) - concise reason
     Space Complexity: O(...) - concise reason
     (Always write clean Big-O like O(N), O(log N), O(1) WITHOUT LaTeX dollar signs).
6. Always provide the most optimal, bug-free, time & space efficient algorithm.
7. MANDATORY SELF-VERIFICATION & ERROR CHECKING:
   - Before outputting, mentally dry-run your completed code against problem constraints and examples.
   - Verify that all brackets '{{', '(', '[' are properly closed by matching '}}', ')', ']'.
   - Ensure there are NO duplicate class definitions, duplicate method definitions, or dangling closing braces.
   - If you detect any syntax error, missing semicolon, or logic bug, fix it immediately before returning your solution.
"""

def get_language_display_name(language: str = "python") -> str:
    lang = (language or "python").strip().lower()
    return {
        "python": "Python 3",
        "cpp": "C++ (C++17 / C++20)",
        "java": "Java (Java 17 / OpenJDK)",
        "javascript": "JavaScript (ES6+)",
        "typescript": "TypeScript",
        "c": "C",
        "csharp": "C#",
    }.get(lang, "Python 3")

def get_system_prompt(mode: str, language: str = "python") -> str:
    if mode == "code":
        return get_code_prompt(language)
    base = DEFAULT_SYSTEM_PROMPTS.get(mode, DEFAULT_SYSTEM_PROMPTS["mcq"])
    display_name = get_language_display_name(language)
    return (
        f"{base}\n\n"
        f"MANDATORY PROGRAMMING LANGUAGE RULE: If this question involves writing code or algorithms, "
        f"you MUST write the code strictly in {display_name}. Do NOT default to Python or any other language unless explicitly requested."
    )


# Max tokens per mode — limits response length for faster streaming
MODE_MAX_TOKENS = {
    "mcq": 512,
    "code": 1200,
    "detailed": 2048,
    "interview": 1024,
}


def transcribe_audio_bytes(wav_bytes: bytes) -> str:
    """Fallback helper to transcribe raw WAV bytes into text using SpeechRecognition."""
    if not wav_bytes:
        return ""
    try:
        import speech_recognition as sr
        r = sr.Recognizer()
        with sr.AudioFile(io.BytesIO(wav_bytes)) as source:
            audio = r.record(source)
        return r.recognize_google(audio).strip()
    except Exception:
        return ""


def load_config() -> dict:
    defaults = {
        "api_key": "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",
        "api_provider": "openrouter",
        "model_name": "openrouter/auto",
        "default_mode": "mcq",
        "code_language": "python",
        "opacity": 95,
        "always_on_top": True,
        "window_width": 780,
        "window_height": 560,
        "audio_device": "system_loopback",
        "silence_timeout": 1.0,
        "ask_before_answering": False,
    }
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                cfg.setdefault("code_language", "python")
                key = cfg.get("api_key", "").strip()

                # Sync provider_keys
                p_keys = cfg.get("provider_keys", {})
                if "nvidia" not in p_keys:
                    p_keys["nvidia"] = "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"
                if "openrouter" not in p_keys:
                    p_keys["openrouter"] = "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"

                cur_prov = cfg.get("api_provider", "").lower()
                if key:
                    if key.startswith("nvapi-"):
                        p_keys["nvidia"] = key
                    elif key.startswith("AIza"):
                        p_keys["gemini"] = key
                    elif key.startswith("sk-"):
                        p_keys["openrouter"] = key
                    if cur_prov:
                        p_keys[cur_prov] = key
                cfg["provider_keys"] = p_keys

                # Only assign default provider if not configured
                if not cfg.get("api_provider"):
                    if key.startswith("nvapi-"):
                        cfg["api_provider"] = "nvidia"
                    elif key.startswith("AIza"):
                        cfg["api_provider"] = "gemini"
                    else:
                        cfg["api_provider"] = "openrouter"

                prov = cfg.get("api_provider", "").lower()
                m_name = cfg.get("model_name", "")
                if prov == "nvidia":
                    if not m_name or "nemotron" in m_name or "openrouter" in m_name:
                        cfg["model_name"] = "meta/llama-3.2-11b-vision-instruct"
                elif prov == "openrouter":
                    if not m_name or ("meta/llama" in m_name and "/" in m_name and not m_name.startswith("meta-llama")):
                        cfg["model_name"] = "openrouter/auto"
                elif prov == "gemini":
                    if not m_name or "/" in m_name:
                        cfg["model_name"] = "gemini-3.6-flash"

                if "window_width" not in cfg:
                    cfg["window_width"] = 860
                if "window_height" not in cfg:
                    cfg["window_height"] = 560
                if "audio_device" not in cfg:
                    cfg["audio_device"] = "system_loopback"
                if "silence_timeout" not in cfg:
                    cfg["silence_timeout"] = 1.0
                return cfg
        except Exception:
            pass
    return defaults


def save_config(cfg: dict):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        print(f"[AIEngine] Failed to save config: {e}")


class AISolveWorker(QtCore.QThread):
    chunk_received = QtCore.pyqtSignal(str)
    solve_completed = QtCore.pyqtSignal(str)
    solve_failed = QtCore.pyqtSignal(str)

    def __init__(self, mode="mcq", language="python", image_bytes=None, text_prompt=None, audio_bytes=None, cv_context=None, previous_answer=None, user_note=None, parent=None):
        super().__init__(parent)
        self.mode = mode
        self.language = language or "python"
        self.image_bytes = image_bytes
        self.text_prompt = text_prompt
        self.audio_bytes = audio_bytes
        self.cv_context = cv_context
        self.previous_answer = previous_answer
        self.user_note = user_note
        self._is_cancelled = False
        if not self.cv_context:
            try:
                from cv_manager import cv_session
                self.cv_context = cv_session.get_prompt_context()
            except Exception:
                self.cv_context = ""
        self.config = load_config()
        if not self.language:
            self.language = self.config.get("code_language", "python")

    def cancel(self):
        self._is_cancelled = True

    def _build_vision_prompt(self, target_lang_display: str) -> str:
        code_example = {
            "python": "class Solution:\n    def methodName(self, ...):\n        # full working logic here",
            "cpp": "class Solution {\npublic:\n    ReturnType methodName(...) {\n        // full working logic here\n    }\n};",
            "java": "class Solution {\n    public ReturnType methodName(...) {\n        // full working logic here\n    }\n}",
            "javascript": "var methodName = function(...) {\n    // full working logic here\n};",
            "typescript": "function methodName(...): ReturnType {\n    // full working logic here\n};",
        }.get(self.language.lower(), "class Solution:\n    def methodName(self, ...):")

        if self.mode == "mcq":
            return (
                "You are an expert exam solver and technical assessment copilot.\n"
                "Carefully inspect this screenshot.\n"
                "1. If this screenshot contains a Multiple-Choice Question (MCQ):\n"
                "   - Identify the exact question and all choices (A, B, C, D).\n"
                "   - State the winning option clearly in bold: '**Option X: <Option Text>**'\n"
                "   - Provide a concise 2-3 sentence explanation of why this answer is mathematically / logically correct.\n"
                "2. If this screenshot contains a Coding Challenge (e.g. LeetCode / HackerRank / CodeSignal):\n"
                f"   - Inspect the code editor text box in the screenshot.\n"
                f"   - Read the method signature and any partial code in that text box.\n"
                f"   - AUTOMATICALLY DETECT HOW MUCH CODE IS REMAINING TO BE WRITTEN.\n"
                f"   - Write the COMPLETE runnable solution strictly in {target_lang_display}.\n"
                f"   - Never output just an empty signature or 2-3 line stub. Write the full working logic.\n"
                f"   - Follow with `### Approach & Intuition` and `### Complexity Analysis`.\n"
            )

        if self.mode == "interview":
            return (
                "You are an articulate, senior-level candidate in a technical interview.\n"
                "Carefully inspect the question shown in this screenshot.\n"
                "1. Deliver a confident, structured, first-person spoken response ('The way I solve this is...').\n"
                f"2. If code or algorithm is requested, provide the complete working code in {target_lang_display}.\n"
                "3. Conclude with time and space complexity trade-offs.\n"
            )

        # Default: Code mode (LeetCode / competitive programming)
        return (
            f"You are an elite competitive programmer and FAANG coding interview copilot.\n"
            f"Carefully analyze this screenshot of a coding problem / interview question.\n\n"
            f"CRITICAL INSTRUCTIONS FOR CODE EDITOR TEXT BOX:\n"
            f"1. READ THE PROBLEM STATEMENT:\n"
            f"   - Read the problem title, description, constraints, and example inputs/outputs from the image.\n\n"
            f"2. INSPECT THE CODE EDITOR / TEXT BOX IN THE SCREENSHOT:\n"
            f"   - Carefully inspect the code editor or text box shown in the screenshot (e.g., on LeetCode / HackerRank / IDE).\n"
            f"   - Read the exact class name, method/function signature, parameter types, and return type shown in that text box.\n"
            f"   - Notice any partial code that the user or problem has already typed into that text box.\n"
            f"   - AUTOMATICALLY DETECT HOW MUCH CODE IS REMAINING TO COMPLETE THE SOLUTION.\n\n"
            f"3. IMPLEMENT THE COMPLETE WORKING CODE IN {target_lang_display.upper()}:\n"
            f"   - MANDATORY TARGET LANGUAGE: You MUST write the code strictly in {target_lang_display}.\n"
            f"   - Even if the screenshot or editor text box displays Python or another language, produce the complete runnable code strictly in {target_lang_display}.\n"
            f"   - NEVER OUTPUT AN EMPTY FUNCTION SIGNATURE, A STUB, OR ONLY 2-3 LINES!\n"
            f"   - Complete all remaining code with the full working algorithmic logic inside the method body so it passes 100% of test cases when submitted.\n"
            f"   - Match the runnable LeetCode class/function structure:\n"
            f"```{self.language}\n"
            f"{code_example}\n"
            f"```\n\n"
            f"4. MANDATORY SECTIONS TO GENERATE - YOU MUST ALWAYS INCLUDE ALL THREE SECTIONS:\n"
            f"   - SECTION 1: Full working runnable code inside a ```{self.language} code block FIRST.\n"
            f"   - SECTION 2: Approach & Intuition\n"
            f"     ### Approach & Intuition\n"
            f"     Provide a clear step-by-step walkthrough explaining the core algorithmic strategy (e.g. hash map, two pointers, sliding window, DP), why it works, and how edge cases are handled.\n"
            f"   - SECTION 3: Complexity Analysis\n"
            f"     ### Complexity Analysis\n"
            f"     - Time Complexity: O(...) - concise reason\n"
            f"     - Space Complexity: O(...) - concise reason\n"
            f"5. MANDATORY SELF-VERIFICATION & ERROR CHECKING:\n"
            f"   - Mentally dry-run the completed code against the example inputs and constraints.\n"
            f"   - Check bracket balancing: ensure every '{{' matches a '}}' with NO stranded or duplicate braces.\n"
            f"   - Check types and return statements. If any syntax error or bug is found, fix it automatically.\n"
        )

    def _build_refinement_prompt(self, target_lang_display: str) -> str:
        prev_text = (self.previous_answer or "Previous response").strip()
        user_note_clean = (self.user_note or "").strip()

        # Detect if this is an MCQ task
        is_mcq = (
            self.mode == "mcq"
            or "**Option " in prev_text
            or "Winning Option:" in prev_text
            or "### 🎯 Correct Option" in prev_text
            or "Option A" in prev_text
            or "Option B" in prev_text
            or "Option C" in prev_text
            or "Option D" in prev_text
        )

        is_interview = self.mode == "interview"

        # Check if user explicitly asked for code in their note
        user_wants_code = any(w in user_note_clean.lower() for w in [
            "write code", "provide code", "implement in", "c++", "cpp", "python", "java", "code for", "script", "program", "in code"
        ])

        if is_mcq and not user_wants_code:
            return (
                f"You previously solved this Multiple-Choice Question (MCQ):\n\n"
                f"{prev_text}\n\n"
                f"USER REFINEMENT NOTE / CLARIFICATION REQUEST:\n"
                f"\"{user_note_clean}\"\n\n"
                f"CRITICAL INSTRUCTIONS FOR MCQ REFINEMENT:\n"
                f"1. THIS IS A MULTIPLE-CHOICE QUESTION (MCQ) — NOT A CODING TASK.\n"
                f"2. DO NOT WRITE ANY CODE OR CODE BLOCKS! The user did not ask for code.\n"
                f"3. Intelligently apply the user's note to refine the MCQ response:\n"
                f"   - If verifying the answer, double-check all options (A, B, C, D) and confirm or correct the winning option in bold: '**Option X: <Text>**'.\n"
                f"   - If explaining why options are wrong, provide clear distractor analysis.\n"
                f"   - If calculating math/logic, show the step-by-step derivation.\n"
                f"   - If summarizing, give a crisp, authoritative explanation.\n"
                f"4. Output a clean, structured MCQ verdict and explanation."
            )

        if is_interview and not user_wants_code:
            return (
                f"You previously provided this technical interview answer:\n\n"
                f"{prev_text}\n\n"
                f"USER REFINEMENT NOTE / ADJUSTMENT REQUEST:\n"
                f"\"{user_note_clean}\"\n\n"
                f"CRITICAL INSTRUCTIONS FOR INTERVIEW REFINEMENT:\n"
                f"1. Apply the user's note to refine the interview response.\n"
                f"2. Maintain an articulate, first-person spoken delivery ('The way I approach this is...').\n"
                f"3. Do not generate code blocks unless specifically requested by the user's note.\n"
                f"4. Highlight trade-offs, design rationale, and senior engineering perspective as requested."
            )

        # Default: Coding Challenge / LeetCode
        lang_directive = (
            f"\n\n[MANDATORY TARGET PROGRAMMING LANGUAGE: {target_lang_display}. "
            f"You MUST write all code strictly in {target_lang_display}. "
            f"Even if the question, screenshot, or starter code displays Python or another language, "
            f"you MUST implement the solution strictly in {target_lang_display}.]"
        )
        return (
            f"You previously generated this coding solution:\n\n"
            f"{prev_text}\n\n"
            f"USER REFINEMENT NOTE / FIX REQUEST:\n"
            f"\"{user_note_clean}\"\n\n"
            f"CRITICAL INSTRUCTIONS FOR CODE REFINEMENT:\n"
            f"1. Intelligently understand the user's note and take the optimal decision.\n"
            f"2. Apply the requested changes (e.g. algorithm change, optimization, fixing braces, edge cases, comments).\n"
            f"3. Output the complete, working, runnable solution strictly in {target_lang_display}.\n"
            f"4. Check bracket balancing: ensure all '{{' have matching '}}' with zero leftover braces or duplicate signatures.\n"
            f"5. Follow with updated `### Approach & Intuition` and `### Complexity Analysis`.\n"
            f"{lang_directive}"
        )

    def run(self):
        self.config = load_config()
        provider = self.config.get("api_provider", "").lower()
        api_key = self.config.get("api_key", "").strip() or os.environ.get("OPENROUTER_API_KEY", "").strip() or os.environ.get("GEMINI_API_KEY", "").strip()

        if not provider:
            if api_key.startswith("nvapi-"):
                provider = "nvidia"
            elif api_key.startswith("sk-or-") or api_key.startswith("sk-"):
                provider = "openrouter"
            elif api_key.startswith("AIza"):
                provider = "gemini"
            else:
                provider = "nvidia"

        if not api_key:
            prov_name = {"nvidia": "NVIDIA NIM", "openrouter": "OpenRouter", "gemini": "Google Gemini"}.get(provider, "AI")
            self.solve_failed.emit(
                f"⚠️ **No {prov_name} API Key found!**\n\n"
                f"Please click the **⚙️ Settings** button (or press `Alt + K`) to enter your {prov_name} API key."
            )
            return

        system_instruction = get_system_prompt(self.mode, self.language)
        if self.cv_context:
            system_instruction = f"{system_instruction}\n\n{self.cv_context}"

        target_lang_display = get_language_display_name(self.language)

        # ==========================================
        # ROUTE 1: OPENROUTER API (OpenAI Compatible)
        # ==========================================
        if provider == "openrouter" or api_key.startswith("sk-or-"):
            try:
                client = openai.OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=api_key,
                    default_headers={
                        "HTTP-Referer": "https://github.com/ghost-ai-assistant",
                        "X-Title": "Ghost AI Assistant"
                    }
                )

                model_name = self.config.get("model_name", "openrouter/auto")
                if not model_name or ("gemini-" in model_name and "/" not in model_name):
                    model_name = "openrouter/auto"

                messages = [
                    {"role": "system", "content": system_instruction}
                ]

                lang_directive = (
                    f"\n\n[MANDATORY TARGET PROGRAMMING LANGUAGE: {target_lang_display}. "
                    f"You MUST write all code strictly in {target_lang_display}. "
                    f"Even if the question, screenshot, or starter code displays Python or another language, "
                    f"you MUST implement the solution strictly in {target_lang_display}.]"
                )

                if self.user_note:
                    prompt_text = self._build_refinement_prompt(target_lang_display)
                    messages.append({"role": "user", "content": prompt_text})
                elif self.image_bytes:
                    b64_img = base64.b64encode(self.image_bytes).decode("utf-8")
                    prompt_text = self._build_vision_prompt(target_lang_display)
                    messages.append({
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt_text},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64_img}"}}
                        ]
                    })
                elif self.audio_bytes:
                    spoken_q = self.text_prompt or transcribe_audio_bytes(self.audio_bytes)
                    prompt_text = (
                        "You are listening to an interviewer asking a question during a technical interview or coding exam.\n"
                        f"Spoken Question: \"{spoken_q or 'Interviewer question'}\"\n\n"
                        f"Provide the direct, optimal answer or clean code solution according to your role instructions.{lang_directive}"
                    )
                    messages.append({"role": "user", "content": prompt_text})
                elif self.text_prompt:
                    prompt_text = f"{self.text_prompt}{lang_directive}"
                    messages.append({"role": "user", "content": prompt_text})
                else:
                    self.solve_failed.emit("Nothing to solve (no input provided).")
                    return

                def stream_openrouter(target_model):
                    return client.chat.completions.create(
                        model=target_model,
                        messages=messages,
                        stream=True,
                        max_tokens=2048,
                    )

                try:
                    response_stream = stream_openrouter(model_name)
                except Exception as stream_err:
                    err_text = str(stream_err).lower()
                    if ("429" in err_text or "rate-limited" in err_text or "not found" in err_text) and model_name != "openrouter/auto":
                        response_stream = stream_openrouter("openrouter/auto")
                    else:
                        raise stream_err

                accumulated = []
                for chunk in response_stream:
                    if self._is_cancelled:
                        return
                    if chunk.choices and len(chunk.choices) > 0:
                        delta = chunk.choices[0].delta
                        if delta and delta.content:
                            accumulated.append(delta.content)
                            self.chunk_received.emit(delta.content)

                full_text = "".join(accumulated)
                if not full_text:
                    full_text = "✓ Answer generated."
                self.solve_completed.emit(full_text)

            except Exception as e:
                err_msg = str(e)
                if "401" in err_msg or "invalid api key" in err_msg.lower():
                    self.solve_failed.emit("❌ **Invalid OpenRouter API Key**. Please verify your key in Settings.")
                elif "429" in err_msg or "rate limit" in err_msg.lower():
                    self.solve_failed.emit("⏳ **OpenRouter Rate Limit**. Please retry shortly or select `openrouter/auto` in Settings.")
                elif "402" in err_msg or "credits" in err_msg.lower():
                    self.solve_failed.emit("💳 **OpenRouter Insufficient Credits**. Please check your balance at [openrouter.ai/credits](https://openrouter.ai/credits).")
                else:
                    self.solve_failed.emit(f"❌ **OpenRouter Error:**\n{err_msg}")
            return

        # ==========================================
        # ROUTE 2: NVIDIA NIM (OpenAI Compatible)
        # ==========================================
        if provider == "nvidia" or api_key.startswith("nvapi-"):
            try:
                client = openai.OpenAI(
                    base_url="https://integrate.api.nvidia.com/v1",
                    api_key=api_key,
                    timeout=20
                )

                # Primary model: meta/llama-3.2-11b-vision-instruct (supports text, audio Q&A, and screenshot snips)
                model_name = self.config.get("model_name", "meta/llama-3.2-11b-vision-instruct")
                if not model_name or "nemotron" in model_name or "openrouter" in model_name or ("gemini-" in model_name and "/" not in model_name):
                    model_name = "meta/llama-3.2-11b-vision-instruct"

                messages = [
                    {"role": "system", "content": system_instruction}
                ]

                lang_directive = (
                    f"\n\n[MANDATORY TARGET PROGRAMMING LANGUAGE: {target_lang_display}. "
                    f"You MUST write all code strictly in {target_lang_display}. "
                    f"Even if the question, screenshot, or starter code displays Python or another language, "
                    f"you MUST implement the solution strictly in {target_lang_display}.]"
                )

                if self.user_note:
                    prompt_text = self._build_refinement_prompt(target_lang_display)
                    messages.append({"role": "user", "content": prompt_text})
                elif self.image_bytes:
                    b64_img = base64.b64encode(self.image_bytes).decode("utf-8")
                    prompt_text = self._build_vision_prompt(target_lang_display)
                    messages.append({
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt_text},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64_img}"}}
                        ]
                    })
                elif self.audio_bytes:
                    spoken_q = self.text_prompt or transcribe_audio_bytes(self.audio_bytes)
                    prompt_text = (
                        "You are listening to an interviewer asking a question during a technical interview or coding exam.\n"
                        f"Spoken Question: \"{spoken_q or 'Interviewer question'}\"\n\n"
                        f"Provide the direct, optimal answer or clean code solution according to your role instructions.{lang_directive}"
                    )
                    messages.append({"role": "user", "content": prompt_text})
                elif self.text_prompt:
                    prompt_text = f"{self.text_prompt}{lang_directive}"
                    messages.append({"role": "user", "content": prompt_text})
                else:
                    self.solve_failed.emit("Nothing to solve (no input provided).")
                    return

                max_toks = 2048

                def stream_nvidia(target_model):
                    return client.chat.completions.create(
                        model=target_model,
                        messages=messages,
                        stream=True,
                        max_tokens=max_toks,
                        temperature=0.2,
                    )

                try:
                    response_stream = stream_nvidia(model_name)
                except Exception as stream_err:
                    err_text = str(stream_err).lower()
                    if ("404" in err_text or "410" in err_text or "not found" in err_text or "400" in err_text) and model_name != "meta/llama-3.2-11b-vision-instruct":
                        response_stream = stream_nvidia("meta/llama-3.2-11b-vision-instruct")
                    else:
                        raise stream_err

                accumulated = []
                for chunk in response_stream:
                    if self._is_cancelled:
                        return
                    if chunk.choices and len(chunk.choices) > 0:
                        delta = chunk.choices[0].delta
                        if delta and delta.content:
                            accumulated.append(delta.content)
                            self.chunk_received.emit(delta.content)

                full_text = "".join(accumulated)
                if not full_text:
                    full_text = "✓ Answer generated."
                self.solve_completed.emit(full_text)

            except Exception as e:
                err_msg = str(e)
                if "401" in err_msg or "invalid api key" in err_msg.lower():
                    self.solve_failed.emit("❌ **Invalid NVIDIA API Key**. Please verify your key in Settings.")
                elif "429" in err_msg or "rate limit" in err_msg.lower():
                    self.solve_failed.emit("⏳ **NVIDIA Rate Limit**. Please retry shortly.")
                elif "402" in err_msg or "credits" in err_msg.lower() or "quota" in err_msg.lower():
                    self.solve_failed.emit("💳 **NVIDIA Quota Exceeded**. Please check your account at [build.nvidia.com](https://build.nvidia.com).")
                elif "410" in err_msg or "end of life" in err_msg.lower() or "deprecated" in err_msg.lower():
                    self.solve_failed.emit("⚠️ **Model Deprecated on NVIDIA NIM**.\nSwitching to nemotron-nano automatically next retry.")
                else:
                    self.solve_failed.emit(f"❌ **NVIDIA Error:**\n{err_msg}")
            return

        # ==========================================
        # ROUTE 3: GOOGLE GEMINI DIRECT
        # ==========================================
        try:
            genai.configure(api_key=api_key)
            model_name = self.config.get("model_name", "gemini-3.6-flash")
            if any(old in model_name for old in ["2.0-flash", "1.5-flash", "1.5-pro", "2.5-flash", "2.5-pro"]):
                model_name = "gemini-3.6-flash"

            contents = []
            lang_directive = (
                f"\n\n[MANDATORY TARGET PROGRAMMING LANGUAGE: {target_lang_display}. "
                f"You MUST write all code strictly in {target_lang_display}. "
                f"Even if the question, screenshot, or starter code displays Python or another language, "
                f"you MUST implement the solution strictly in {target_lang_display}.]"
            )

            if self.user_note:
                prompt_instruction = self._build_refinement_prompt(target_lang_display)
                contents.append(prompt_instruction)
            elif self.audio_bytes:
                audio_part = {
                    "mime_type": "audio/wav",
                    "data": self.audio_bytes
                }
                contents.append(audio_part)
                prompt_instruction = (
                    "You are listening to an interviewer asking a question during a technical interview or coding exam.\n"
                    "1. First, state clearly what question was asked: '### 🎙️ Question: <transcribed question>'\n"
                    "2. Then, provide the direct, optimal answer or clean code solution according to your role instructions."
                    f"{lang_directive}"
                )
                if self.text_prompt:
                    prompt_instruction += f"\nAdditional Context: {self.text_prompt}"
                contents.append(prompt_instruction)

            elif self.image_bytes:
                img = Image.open(io.BytesIO(self.image_bytes))
                contents.append(img)
                prompt_instruction = self._build_vision_prompt(target_lang_display)
                contents.append(prompt_instruction)
            elif self.text_prompt:
                contents.append(f"{self.text_prompt}{lang_directive}")
            else:
                self.solve_failed.emit("Nothing to solve (no audio, image, or text provided).")
                return

            def call_generate(name):
                m = genai.GenerativeModel(
                    model_name=name,
                    system_instruction=system_instruction,
                )
                return m.generate_content(contents, stream=True)

            try:
                response = call_generate(model_name)
            except Exception as model_err:
                err_str = str(model_err).lower()
                if "404" in err_str or "not found" in err_str or "no longer available" in err_str:
                    fallback = "gemini-flash-latest" if model_name == "gemini-3.6-flash" else "gemini-3.6-flash"
                    response = call_generate(fallback)
                else:
                    raise model_err

            accumulated = []
            for chunk in response:
                if self._is_cancelled:
                    return
                if chunk.text:
                    accumulated.append(chunk.text)
                    self.chunk_received.emit(chunk.text)

            full_text = "".join(accumulated)
            self.solve_completed.emit(full_text)

        except Exception as e:
            err_msg = str(e)
            if "API_KEY_INVALID" in err_msg or ("400" in err_msg and "key" in err_msg.lower()):
                self.solve_failed.emit("❌ **Invalid Gemini API Key**. Please check your key in Settings.")
            elif "QUOTA" in err_msg.upper() or "RESOURCE_EXHAUSTED" in err_msg:
                self.solve_failed.emit("⏳ **API Quota Exceeded**. Please wait a moment or try another key.")
            elif "404" in err_msg and "no longer available" in err_msg:
                self.solve_failed.emit(f"⚠️ **Model Unavailable**: The selected model is deprecated.\n\n{err_msg}\n\nPlease select **gemini-3.6-flash** in Settings.")
            else:
                self.solve_failed.emit(f"❌ **Error solving question:**\n{err_msg}")
