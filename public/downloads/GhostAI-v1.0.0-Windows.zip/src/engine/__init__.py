"""
Engine modules: AI solvers, syntax formatters, and CV context manager.
"""

from .ai_engine import (
    AISolveWorker,
    load_config,
    save_config,
    get_code_prompt,
    get_system_prompt,
)
from .code_formatter import (
    format_full_response,
    format_complexity_section,
    ResponseResult,
)
from .cv_manager import (
    CVSessionManager,
    cv_session,
    extract_text_from_file,
)

__all__ = [
    "AISolveWorker",
    "load_config",
    "save_config",
    "get_code_prompt",
    "get_system_prompt",
    "format_full_response",
    "format_complexity_section",
    "ResponseResult",
    "CVSessionManager",
    "cv_session",
    "extract_text_from_file",
]
