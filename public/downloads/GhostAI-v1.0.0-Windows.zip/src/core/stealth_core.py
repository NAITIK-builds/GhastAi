"""
stealth_core.py - Windows Display Affinity Manager
Uses Windows 10/11 SetWindowDisplayAffinity API with WDA_EXCLUDEFROMCAPTURE (0x00000011).
This instructs the Desktop Window Manager (DWM) to render the window to the local physical
display, but completely exclude and skip it during any screen capture session (Zoom, Discord,
Google Meet, Teams, OBS, Snipping Tool, Windows Game Bar, etc.).
"""

import ctypes
from ctypes import wintypes
import sys

# Windows Display Affinity constants
WDA_NONE = 0x00000000
WDA_MONITOR = 0x00000001
WDA_EXCLUDEFROMCAPTURE = 0x00000011

user32 = ctypes.windll.user32

# Set function signatures for 64-bit Windows safety
user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.SetWindowDisplayAffinity.restype = wintypes.BOOL

user32.GetWindowDisplayAffinity.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
# Extended Window Style constants for taskbar exclusion & non-activating focus shield
GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_APPWINDOW = 0x00040000
WS_EX_NOACTIVATE = 0x08000000


def hide_from_taskbar(hwnd: int) -> bool:
    """Removes the window completely from the Windows Taskbar and Alt+Tab."""
    if sys.platform != "win32":
        return False
    try:
        style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        new_style = (style | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, new_style)
        return True
    except Exception as e:
        print(f"[StealthCore] hide_from_taskbar error: {e}")
        return False


def apply_noactivate(hwnd: int) -> bool:
    """
    Applies WS_EX_NOACTIVATE extended style so clicking or showing this window
    never transfers OS foreground focus away from the active browser/test window.
    """
    if sys.platform != "win32":
        return False
    try:
        style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style | WS_EX_NOACTIVATE)
        return True
    except Exception as e:
        print(f"[StealthCore] apply_noactivate error: {e}")
        return False


def get_foreground_window() -> int:
    """Returns the HWND of the currently active foreground window."""
    if sys.platform != "win32":
        return 0
    try:
        return user32.GetForegroundWindow()
    except Exception:
        return 0


def restore_foreground_window(hwnd: int) -> bool:
    """Ensures the specified HWND (e.g. browser) retains or regains foreground focus."""
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        return bool(user32.SetForegroundWindow(hwnd))
    except Exception:
        return False


def get_anti_proctor_script() -> str:
    """
    Returns the bulletproof Anti-Proctoring JavaScript snippet that neutralizes all
    browser test sandbox listeners (window.onblur, visibilitychange, mouseleave, paste blocking).
    """
    return (
        "/* Ghost Anti-Proctor Shield - Zero Blur & Tab Switch Blocker */\n"
        "(function() {\n"
        "  const blocked = new Set(['blur', 'focusout', 'visibilitychange', 'mouseleave', 'mouseout', 'pagehide']);\n"
        "  const origWindowAEL = window.addEventListener;\n"
        "  const origDocAEL = document.addEventListener;\n"
        "  window.addEventListener = function(type, listener, options) {\n"
        "    if (blocked.has(type)) { return; }\n"
        "    return origWindowAEL.call(this, type, listener, options);\n"
        "  };\n"
        "  document.addEventListener = function(type, listener, options) {\n"
        "    if (blocked.has(type)) { return; }\n"
        "    return origDocAEL.call(this, type, listener, options);\n"
        "  };\n"
        "  window.onblur = null;\n"
        "  document.onblur = null;\n"
        "  document.onvisibilitychange = null;\n"
        "  try { Object.defineProperty(document, 'hasFocus', { value: () => true, writable: false }); } catch(e){}\n"
        "  try { Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true }); } catch(e){}\n"
        "  try { Object.defineProperty(document, 'hidden', { get: () => false, configurable: true }); } catch(e){}\n"
        "  ['copy', 'cut', 'paste', 'contextmenu'].forEach(evt => {\n"
        "    document.addEventListener(evt, e => e.stopPropagation(), true);\n"
        "  });\n"
        "  console.log('%c[Ghost Shield] Anti-Proctor Activated! 0 Blurs & 0 Tab Switches.', 'color: #10b981; font-weight: bold;');\n"
        "})();"
    )


def enable_stealth(hwnd: int, allow_focus: bool = False) -> bool:
    """
    Enables screen capture exclusion for the given window handle (HWND).
    Also strips the window from the Windows Taskbar.
    If allow_focus is False (e.g. background copilot overlay), applies WS_EX_NOACTIVATE
    so clicks never steal OS focus from the browser.
    If allow_focus is True (e.g. login dialog, settings), WS_EX_NOACTIVATE is NOT applied,
    allowing the user to type normally while maintaining 100% WDA_EXCLUDEFROMCAPTURE screen-share invisibility.
    """
    if sys.platform != "win32":
        print("[StealthCore] Warning: Display affinity is only supported on Windows.")
        return False

    try:
        hide_from_taskbar(hwnd)
        if not allow_focus:
            apply_noactivate(hwnd)
        else:
            # Ensure WS_EX_NOACTIVATE is removed so the user can type!
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            if style & WS_EX_NOACTIVATE:
                user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style & ~WS_EX_NOACTIVATE)
        success = user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE)
        if success:
            print(f"[StealthCore] Stealth enabled successfully for HWND: {hwnd} (allow_focus={allow_focus})")
            return True
        else:
            err = ctypes.GetLastError()
            print(f"[StealthCore] Failed to set display affinity. Windows error code: {err}")
            return False
    except Exception as e:
        print(f"[StealthCore] Exception setting display affinity: {e}")
        return False


def disable_stealth(hwnd: int) -> bool:
    """Restores default capture behavior (window will be captured normally)."""
    if sys.platform != "win32":
        return False
    try:
        success = user32.SetWindowDisplayAffinity(hwnd, WDA_NONE)
        return bool(success)
    except Exception as e:
        print(f"[StealthCore] Exception disabling display affinity: {e}")
        return False


def get_stealth_status(hwnd: int) -> int:
    """Returns the current display affinity value for the window."""
    if sys.platform != "win32":
        return -1
    try:
        affinity = wintypes.DWORD()
        success = user32.GetWindowDisplayAffinity(hwnd, ctypes.byref(affinity))
        if success:
            return affinity.value
        return -1
    except Exception:
        return -1


# ─────────────────────────────────────────────
#  Global Stealth Event Filter (PyQt Integration)
# ─────────────────────────────────────────────
try:
    from PyQt6 import QtCore, QtWidgets

    class GlobalStealthEventFilter(QtCore.QObject):
        """
        Global event filter installed on QApplication:
        1. Completely suppresses all ContextMenu events so right-clicking never spawns
           unwanted popups ('Copy', 'Select All') during screen sharing or interviews.
        2. Automatically applies WDA_EXCLUDEFROMCAPTURE stealth to ANY window, popup,
           combobox dropdown, or dialog created by the application upon being shown.
        """
        def eventFilter(self, watched, event):
            ev_type = event.type()
            if ev_type == QtCore.QEvent.Type.ContextMenu:
                return True  # Block context menu popup completely

            if ev_type == QtCore.QEvent.Type.Show:
                if isinstance(watched, QtWidgets.QWidget) and watched.isWindow():
                    try:
                        allow_focus = getattr(watched, '_allow_keyboard_focus', False)
                        enable_stealth(int(watched.winId()), allow_focus=allow_focus)
                    except Exception:
                        pass

            return super().eventFilter(watched, event)

    _global_stealth_filter = None

    def install_global_stealth_filter():
        """Installs the GlobalStealthEventFilter on QApplication.instance()."""
        global _global_stealth_filter
        app = QtWidgets.QApplication.instance()
        if app and _global_stealth_filter is None:
            _global_stealth_filter = GlobalStealthEventFilter(app)
            app.installEventFilter(_global_stealth_filter)
except ImportError:
    def install_global_stealth_filter():
        pass

